# Discord All-Rounder Bot

## Overview
The Discord All-Rounder Bot is a comprehensive solution designed to enhance Discord server functionality, engagement, and management. It aims to provide a rich user experience through various features, including server administration, an advanced music system, an engaging custom currency and game economy, diverse mini-games, multilingual entertainment options, and a robust AI-themed ticket support system. The project seeks to be a versatile tool for Discord communities, boosting interactivity and streamlining moderation.

## User Preferences
I prefer iterative development, so please propose changes in small, manageable steps. Before making any major architectural changes or introducing new external dependencies, please ask for confirmation. I like clear, concise explanations and prefer to focus on high-level feature implementation rather than getting bogged down in minute details initially. Do not make changes to the `data/` folder directly without explicit instructions.

## Recent Changes (December 2024)
- **Word Filter Command Added**: New `/wordfilter` command for restricting words/phrases:
  - `/wordfilter add <word>` - Add a word/phrase to the filter
  - `/wordfilter remove <word>` - Remove a word/phrase from the filter
  - `/wordfilter list` - View all banned words
  - `/wordfilter enable` / `/wordfilter disable` - Toggle the filter
  - When someone uses a banned word, the message is deleted and they receive a DM: "athokke nende serveril"
  - Requires Manage Messages permission

- **Web Dashboard Added**: Full-featured web dashboard accessible on port 5000 with:
  - Real-time bot statistics (servers, users, commands, uptime, ping)
  - Economy leaderboards and statistics per server
  - User stats leaderboards (levels, messages, voice time, invites)
  - Active giveaways overview
  - Music player status across all servers
  - Server list with quick navigation
  - **Minecraft-themed design** with dirt/grass colors, gold accents, blocky UI elements, and VT323 pixel font
  - Minecraft-style icons (cubes, gems, scrolls, crowns, etc.)

- **Say Exclusive Dashboard Feature**: When sending messages from dashboard, they now include:
  - Footer: "by dev gladi | [Current Day] from Dashboard"
  - Uses Discord small text formatting (-#)
  - Character limit adjusted to account for footer length


- **Control Panel Redesigned (Row Layout)**: The voice channel control panel now uses buttons arranged in rows similar to Container v2 style:
  - Row 1: Lock, Unlock, Kick All
  - Row 2: Edit Name
  - Row 3: Co-Owner, Ban
  - Row 4: Hide, Show
  - Row 5: Access, Limit
- **New Co-Owner Feature**: Added Co-Owner button allowing VC owners to grant management permissions to trusted users.
- **Dynamic Prefix System**: Added `setprefix` command to change the bot prefix per server. Usage: `<prefix>setprefix <new prefix>`. Requires Manage Server permission. Prefix data stored in `data/prefixes.json`.
- **Removed Problematic Games**: Removed numguess and wordscramble commands that were causing issues with message collectors interfering with other bot functions.
- **Join to Create Voice Channels with Control Panel**: When users join designated control panel VCs, they get a personal voice channel with a Container v2 control panel in the VC's built-in chat. Features include:
  - **Channel naming**: "[VC Name]-[Username]" format (e.g., "Solo-John")
  - **Control Panel Buttons** (Row Layout in VC chat):
    - 🔒 Lock / 🔓 Unlock - Control who can join
    - 👁️ Hide / 👀 Show - Toggle channel visibility
    - 🚪 Kick All - Remove all members
    - ✏️ Edit Name - Change channel name via modal
    - 👑 Co-Owner - Add/remove co-owners
    - ⛔ Ban - Block user from channel
    - ✅ Access - Permit specific user
    - 🔢 Limit - Set max users (0-99)
  - VC auto-deletes when empty
  - Control panel channels: 1446204533972668498, 1446204713711177848, 1446204899858845708, 1446204997288067114, 1446205098576445461.
- **Full Components v2 Migration**: All button-based commands now use Discord's new Components v2 system with ContainerBuilder, SectionBuilder, TextDisplayBuilder, and SeparatorBuilder. Buttons appear integrated inside colored containers via SectionBuilder.setButtonAccessory() with MessageFlags.IsComponentsV2 flag.
- **Commands Updated to Components v2**: coinflip, rps, wouldyourather, truthordare, giveaway, help, and ticket commands now use the modern Container v2 style with accent colors and integrated button layout.
- **Coinflip Command Refactored**: Now uses button-based selection for Heads/Tails instead of requiring choice in command. Users only enter bet amount, then click Head or Tail button. Includes "Play Again" functionality.
- **Container v2 UI Style**: Updated ticket system with cleaner embed styling - concise titles, bullet point lists, and integrated button design matching modern Discord bot aesthetics.
- **TTS Voice Message Updated**: Ticket welcome voice now plays a two-part message:
  1. English: "Welcome to the ticket section of Mandhi Spot. The support will be here soon."
  2. English: "This ticket was created by [Username]"
  - Uses Google TTS for natural pronunciation
  - Improved username pronunciation (no longer spells out letters)
- **Admin Voice Channel Announcement**: When a ticket is created, the bot now:
  - Looks for admins who are in voice channels
  - Joins the admin's voice channel using @discordjs/voice
  - Announces: "A new ticket has been created by [username] and needs support from admins. Please check ticket number [id]."
  - Features robust connection handling with 20s timeout and state logging
  - Automatically leaves the voice channel after the announcement (60s max timeout)
  - Pre-flight check skips announcements when Kazagumo music player is active to prevent conflicts
  - Uses discord-tts for natural pronunciation with proper cleanup of temp audio files
- **Welcome Message Updated**: New members now see "Welcome to Mandhi Spot! It's a great place for finding new friends, playing new games, and chill!"
- **Prefix Command Improvements**: Added empty command guard, debug logging, unknown command feedback, and handlers for missing commands (games, music, moderation).

## System Architecture
The bot is built on a modular Container v2 architecture, utilizing Discord.js v14.

**UI/UX Decisions:**
- **Ticket System:** Features AI/futuristic themed HTML transcripts with Glassmorphism design, neon gradients, animated glowing effects, and modern monospace fonts for a tech aesthetic. Transcripts are mobile-responsive.
- **Fun Commands:** Incorporate canvas image generation for commands like `/gay` and `/marriage` for visual engagement.
- **Giveaways:** Button-based entry for intuitive user interaction.
- **Welcome Preview:** A utility to visualize welcome messages.

**Technical Implementations:**
- **Core Bot:** Uses an extended `BotClient` from Discord.js with built-in collections for efficient data handling.
- **Modularity:** Implemented via a `Container` orchestrator that initializes dedicated handlers for commands, events, music, and scheduling.
- **Music System:** Powered by Lavalink (via Kazagumo + Shoukaku) for reliable, high-performance audio streaming. Includes dynamic lyrics fetching from various URLs.
- **AI Chat:** Leverages an OpenAI API for natural, contextual, and multilingual conversational AI, including support for transliterated Indian languages.
- **Data Persistence:** Utilizes JSON files for all data storage, including economy, game states, user statistics, tickets, giveaways, scheduled announcements, and prefix settings.
- **Command Structure:** Supports both Discord Slash Commands and traditional prefix commands with extensive aliases for user flexibility. Prefix is configurable per server.
- **Scheduled Tasks:** A scheduler handler manages timed events like giveaways and announcements.
- **Voice Features:** Includes a voice recorder and TTS welcome messages for tickets.
- **Privileged Gateway Intents:** Requires Presence, Server Members, and Message Content intents for full functionality.

**Feature Specifications:**
- **Server Management:** Standard moderation commands (`kick`, `ban`, `mute`, `clear`, `role management`).
- **Egg Economy:** Custom currency system with daily rewards, gathering, robbing, giving, and leaderboards.
- **Games:** Mini-games including `coinflip`, `dice`, `slots`, `truthordare`, `rps`, `trivia`, `hangman`, and `wouldyourather`, plus a counting game.
- **Jokes & Fun:** Multilingual joke system (14+ languages), dad jokes (API integrated), daily joke feature, meme fetching, and interactive `gay`/`marriage` commands.
- **Channel Restrictions:** Commands can be restricted to specific channels (e.g., economy, stats, marriage, memes).
- **Ticket System:** AI-themed transcripts, custom audio voice welcome messages (with user name appended via TTS), role mentions, channel links, and ticket management.
- **Level System & Stats:** XP-based leveling, user stats, and comprehensive leaderboards (levels, messages, voice time, invites, active time, eggs).
- **Giveaways:** Start, end, and reroll giveaways with button-based entry.
- **Scheduled Announcements:** Schedule announcements with customizable content, timing, and ping options.
- **Voice Recorder:** Records voice channels and saves recordings as MP3s to a log channel.
- **AI Chat System:** Configurable channel for AI interactions with context retention and multilingual support.
- **Marriage Mode Toggle:** Admin-controlled setting to switch between role-based and random user matching.
- **Utility:** General purpose commands like `help`, `ping`, `serverinfo`, `userinfo`, `esay`, `mcstatus`, and `welcomepreview`.
- **Permission System:** Owner-only command restrictions with role-based permission grants via `/permission` command.
- **Welcome Messages:** Auto-detected clickable channel links (announcements, rules, general chat) in welcome embeds.
- **Auto-Reactions:** Automated reactions to owner mentions.
- **Custom Prefix:** Per-server customizable prefix with `setprefix` command.

## External Dependencies
- **Discord.js v14:** Discord API wrapper.
- **Kazagumo + Shoukaku:** Lavalink client for music streaming.
- **meme-api.com:** For fetching random memes.
- **icanhazdadjoke.com:** For dad jokes.
- **opentdb.com:** For trivia questions.
- **Node.js:** Runtime environment.
- **Lavalink Node:** External server for audio processing (requires `LAVALINK_HOST` and `LAVALINK_PASSWORD`).
- **OpenAI API:** For the AI chat feature (requires `OPENAI_API_KEY`).
