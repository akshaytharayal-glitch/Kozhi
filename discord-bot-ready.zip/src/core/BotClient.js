import { Client, Collection, GatewayIntentBits, Partials } from 'discord.js';

export class BotClient extends Client {
  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessageReactions,
      ],
      partials: [Partials.Message, Partials.Channel, Partials.Reaction],
    });
    
    this.commands = new Collection();
    this.cooldowns = new Collection();
    this.kazagumo = null;
    
    this.config = {
      lavalinkNodes: [
        {
          name: 'Primary',
          url: process.env.LAVALINK_HOST || 'lava-v4.ajieblogs.eu.org:443',
          auth: process.env.LAVALINK_PASSWORD || 'https://dsc.gg/ajidevserver',
          secure: true,
        },
      ],
      schedulerInterval: 30000,
    };
  }
  
  setMusicManager(kazagumo) {
    this.kazagumo = kazagumo;
  }
  
  getMusicManager() {
    return this.kazagumo;
  }
  
  getCommand(name) {
    return this.commands.get(name);
  }
  
  getCooldown(commandName, userId) {
    const key = `${commandName}-${userId}`;
    return this.cooldowns.get(key);
  }
  
  setCooldown(commandName, userId, timestamp) {
    const key = `${commandName}-${userId}`;
    this.cooldowns.set(key, timestamp);
  }
  
  clearCooldown(commandName, userId) {
    const key = `${commandName}-${userId}`;
    this.cooldowns.delete(key);
  }
}

export function createBotClient() {
  return new BotClient();
}
