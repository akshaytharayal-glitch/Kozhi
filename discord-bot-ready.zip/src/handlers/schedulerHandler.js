import { getAllActiveGiveaways, getAllPendingAnnouncements, markAnnouncementSent } from '../utils/database.js';
import { endGiveaway } from '../commands/utility/giveaway.js';
import { publishAnnouncement } from '../commands/utility/announce.js';

let schedulerInterval = null;

export function startScheduler(client, intervalMs = 30000) {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
  }
  
  schedulerInterval = setInterval(() => checkScheduledTasks(client), intervalMs);
  console.log(`[Scheduler] Started with ${intervalMs}ms interval`);
  
  return schedulerInterval;
}

export function stopScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
    console.log('[Scheduler] Stopped');
  }
}

async function checkScheduledTasks(client) {
  const now = Date.now();
  
  await checkGiveaways(client, now);
  await checkAnnouncements(client, now);
}

async function checkGiveaways(client, now) {
  try {
    const giveaways = getAllActiveGiveaways();
    
    for (const giveaway of giveaways) {
      if (giveaway.endTime <= now && !giveaway.ended) {
        try {
          const guild = await client.guilds.fetch(giveaway.guildId);
          await endGiveaway(guild, giveaway, client);
          console.log(`[Giveaway] Ended giveaway for ${giveaway.prize} in ${guild.name}`);
        } catch (error) {
          console.error('[Giveaway] Error ending giveaway:', error.message);
        }
      }
    }
  } catch (error) {
    console.error('[Scheduler] Giveaway check error:', error.message);
  }
}

async function checkAnnouncements(client, now) {
  try {
    const announcements = getAllPendingAnnouncements();
    
    for (const announcement of announcements) {
      if (announcement.publishTime <= now && !announcement.sent) {
        try {
          const guild = await client.guilds.fetch(announcement.guildId);
          const success = await publishAnnouncement(guild, announcement, client);
          if (success) {
            markAnnouncementSent(announcement.guildId, announcement.id);
            console.log(`[Announcement] Published scheduled announcement in ${guild.name}`);
          }
        } catch (error) {
          console.error('[Announcement] Error publishing announcement:', error.message);
        }
      }
    }
  } catch (error) {
    console.error('[Scheduler] Announcement check error:', error.message);
  }
}

export function runImmediateCheck(client) {
  return checkScheduledTasks(client);
}
