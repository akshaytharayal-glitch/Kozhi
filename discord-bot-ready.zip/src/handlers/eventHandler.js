import { readdirSync } from 'fs';
import { join } from 'path';

export async function loadEvents(client, eventsPath) {
  const eventFiles = readdirSync(eventsPath).filter(file => file.endsWith('.js'));
  let loadedCount = 0;
  
  for (const file of eventFiles) {
    try {
      const event = await import(`../events/${file}`);
      
      if (!event.default?.name) {
        console.warn(`[Events] Skipping ${file}: Missing event name`);
        continue;
      }
      
      if (event.default.once) {
        client.once(event.default.name, (...args) => event.default.execute(...args, client));
      } else {
        client.on(event.default.name, (...args) => event.default.execute(...args, client));
      }
      
      loadedCount++;
      console.log(`[Events] Loaded: ${event.default.name}${event.default.once ? ' (once)' : ''}`);
    } catch (error) {
      console.error(`[Events] Failed to load ${file}:`, error.message);
    }
  }
  
  console.log(`[Events] Total loaded: ${loadedCount}`);
  return loadedCount;
}
