import { readdirSync } from 'fs';
import { join } from 'path';

export async function loadCommands(client, commandsPath) {
  const commandFolders = readdirSync(commandsPath);
  let loadedCount = 0;
  
  for (const folder of commandFolders) {
    const commandFiles = readdirSync(join(commandsPath, folder)).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
      try {
        const command = await import(`../commands/${folder}/${file}`);
        if (command.default?.data && command.default?.execute) {
          client.commands.set(command.default.data.name, command.default);
          loadedCount++;
          console.log(`[Commands] Loaded: ${command.default.data.name}`);
        }
      } catch (error) {
        console.error(`[Commands] Failed to load ${folder}/${file}:`, error.message);
      }
    }
  }
  
  console.log(`[Commands] Total loaded: ${loadedCount}`);
  return loadedCount;
}

export function getCommand(client, name) {
  return client.commands.get(name);
}

export function getAllCommands(client) {
  return client.commands;
}

export function getCommandsByCategory(client) {
  const categories = new Map();
  
  client.commands.forEach((command, name) => {
    const category = command.category || 'uncategorized';
    if (!categories.has(category)) {
      categories.set(category, []);
    }
    categories.get(category).push({ name, ...command });
  });
  
  return categories;
}
