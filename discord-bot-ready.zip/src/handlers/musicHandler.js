import { Kazagumo, Plugins } from 'kazagumo';
import { Connectors } from 'shoukaku';

export function createMusicManager(client, nodes) {
  const kazagumo = new Kazagumo({
    defaultSearchEngine: 'youtube',
    plugins: [],
    send: (guildId, payload) => {
      const guild = client.guilds.cache.get(guildId);
      if (guild) guild.shard.send(payload);
    }
  }, new Connectors.DiscordJS(client), nodes);
  
  setupMusicEvents(kazagumo, client);
  
  return kazagumo;
}

function setupMusicEvents(kazagumo, client) {
  kazagumo.shoukaku.on('ready', (name) => {
    console.log(`[Lavalink] Node ${name}: Connected and ready!`);
  });
  
  kazagumo.shoukaku.on('error', (name, error) => {
    console.error(`[Lavalink] Node ${name}: Error -`, error.message);
  });
  
  kazagumo.shoukaku.on('close', (name, code, reason) => {
    console.warn(`[Lavalink] Node ${name}: Closed - Code: ${code}, Reason: ${reason || 'Unknown'}`);
  });
  
  kazagumo.shoukaku.on('disconnect', (name, players, moved) => {
    console.log(`[Lavalink] Node ${name}: Disconnected, moved: ${moved}`);
  });
  
  kazagumo.shoukaku.on('reconnecting', (name, left, timeout) => {
    console.log(`[Lavalink] Node ${name}: Reconnecting... (${left} attempts left, timeout: ${timeout}ms)`);
  });
  
  kazagumo.on('playerStart', (player, track) => {
    console.log(`[Music] Started playing: ${track.title}`);
    const channel = client.channels.cache.get(player.textId);
    if (channel) {
      channel.send(`Now playing: **${track.title}** by ${track.author}`);
    }
  });
  
  kazagumo.on('playerEnd', (player) => {
    console.log('[Music] Track ended');
  });
  
  kazagumo.on('playerEmpty', (player) => {
    console.log('[Music] Queue is now empty');
    const channel = client.channels.cache.get(player.textId);
    if (channel) {
      channel.send('Queue finished! No more songs to play.');
    }
    setTimeout(() => {
      if (player && !player.queue.current) {
        player.destroy();
      }
    }, 300000);
  });
  
  kazagumo.on('playerDestroy', (player) => {
    console.log('[Music] Player destroyed');
  });
  
  kazagumo.on('playerError', (player, error) => {
    console.error('[Music] Player error:', error);
    const channel = client.channels.cache.get(player.textId);
    if (channel) {
      channel.send(`Playback error: ${error.message || 'Unknown error'}. Try a different song.`);
    }
  });
  
  kazagumo.on('playerStuck', (player, data) => {
    console.log('[Music] Player stuck, skipping track');
    const channel = client.channels.cache.get(player.textId);
    if (channel) {
      channel.send('Track got stuck, skipping to next...');
    }
    player.skip();
  });
}

export function getPlayer(kazagumo, guildId) {
  return kazagumo.players.get(guildId);
}

export async function createPlayer(kazagumo, options) {
  return await kazagumo.createPlayer(options);
}

export function destroyPlayer(kazagumo, guildId) {
  const player = kazagumo.players.get(guildId);
  if (player) {
    player.destroy();
    return true;
  }
  return false;
}
