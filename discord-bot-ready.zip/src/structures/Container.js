import { createBotClient } from '../core/BotClient.js';
import { loadCommands } from '../handlers/commandHandler.js';
import { loadEvents } from '../handlers/eventHandler.js';
import { createMusicManager } from '../handlers/musicHandler.js';
import { startScheduler, stopScheduler } from '../handlers/schedulerHandler.js';
import { createDashboardServer } from '../dashboard/server.js';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export class Container {
  constructor() {
    this.client = null;
    this.dashboardServer = null;
    this.isReady = false;
    this.startTime = null;
  }
  
  async initialize() {
    console.log('[Container] Initializing bot...');
    this.startTime = Date.now();
    
    this.client = createBotClient();
    
    const commandsPath = join(__dirname, '..', 'commands');
    const eventsPath = join(__dirname, '..', 'events');
    
    await loadCommands(this.client, commandsPath);
    await loadEvents(this.client, eventsPath);
    
    const kazagumo = createMusicManager(this.client, this.client.config.lavalinkNodes);
    this.client.setMusicManager(kazagumo);
    
    const token = process.env.DISCORD_TOKEN;
    if (!token) {
      console.warn('WARNING: DISCORD_TOKEN is not set in environment variables! Bot will not login to Discord.');
      console.warn('Please set DISCORD_TOKEN in your .env file or environment variables.');
    } else {
      await this.client.login(token);
    }
    
    startScheduler(this.client, this.client.config.schedulerInterval);
    
    this.dashboardServer = createDashboardServer(this.client);
    
    this.isReady = true;
    
    const initTime = Date.now() - this.startTime;
    console.log(`[Container] Bot initialized in ${initTime}ms`);
    
    return this.client;
  }
  
  getClient() {
    return this.client;
  }
  
  async shutdown() {
    console.log('[Container] Shutting down...');
    
    stopScheduler();
    
    if (this.dashboardServer) {
      this.dashboardServer.close();
      console.log('[Dashboard] Server closed');
    }
    
    if (this.client?.kazagumo) {
      const players = this.client.kazagumo.players;
      for (const [guildId, player] of players) {
        player.destroy();
      }
    }
    
    if (this.client) {
      this.client.destroy();
    }
    
    this.isReady = false;
    console.log('[Container] Shutdown complete');
  }
  
  getUptime() {
    if (!this.startTime) return 0;
    return Date.now() - this.startTime;
  }
  
  getStatus() {
    return {
      ready: this.isReady,
      uptime: this.getUptime(),
      guilds: this.client?.guilds.cache.size || 0,
      commands: this.client?.commands.size || 0,
      ping: this.client?.ws.ping || 0,
    };
  }
}

export async function createContainer() {
  const container = new Container();
  await container.initialize();
  return container;
}
