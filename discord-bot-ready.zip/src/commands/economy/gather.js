import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { addBalance, getBalance } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('gather')
    .setDescription('Gather eggs from the farm'),
  
  cooldown: 30,
  
  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    
    const eggsCollected = Math.floor(Math.random() * 60) + 1;
    
    const newBalance = addBalance(guildId, userId, eggsCollected);
    
    const container = new ContainerBuilder()
      .setAccentColor(0xFFA500)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Farm Gathering')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`You've collected **${eggsCollected}** eggs from the farm!\n\n**Eggs Collected:** ${eggsCollected}\n**Total Eggs:** ${newBalance.toLocaleString()}\n\n*Keep gathering to get more eggs!*`)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
