import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { addBalance, getDailyReward, setDailyReward } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily egg reward'),
  
  cooldown: 5,
  
  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const dailyData = getDailyReward(guildId, userId);
    
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const twoDays = 48 * 60 * 60 * 1000;
    
    if (dailyData.lastClaim && now - dailyData.lastClaim < oneDay) {
      const timeLeft = oneDay - (now - dailyData.lastClaim);
      const hours = Math.floor(timeLeft / (60 * 60 * 1000));
      const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
      
      return interaction.reply({
        content: `You've already claimed your daily reward! Come back in **${hours}h ${minutes}m**`,
        flags: 64,
      });
    }
    
    let streak = dailyData.streak || 0;
    if (dailyData.lastClaim && now - dailyData.lastClaim > twoDays) {
      streak = 0;
    }
    streak++;
    
    const baseReward = 100;
    const streakBonus = Math.min(streak * 10, 100);
    const totalReward = baseReward + streakBonus;
    
    addBalance(guildId, userId, totalReward);
    setDailyReward(guildId, userId, { lastClaim: now, streak });
    
    const container = new ContainerBuilder()
      .setAccentColor(0x00FF00)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Daily Reward Claimed!')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`You received **${totalReward}** eggs!\n\n**Base Reward:** ${baseReward} eggs\n**Streak Bonus:** +${streakBonus} eggs\n**Current Streak:** ${streak} days\n\n*Come back tomorrow to keep your streak!*`)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
