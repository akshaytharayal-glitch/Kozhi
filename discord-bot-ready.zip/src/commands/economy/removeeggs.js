import { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { removeBalance, getBalance } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('removeeggs')
    .setDescription('Remove eggs from a user (Admin only)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to remove eggs from')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Amount of eggs to remove')
        .setRequired(true)
        .setMinValue(1))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    
    const newBalance = removeBalance(interaction.guild.id, user.id, amount);
    
    const container = new ContainerBuilder()
      .setAccentColor(0xFF6B6B)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Eggs Removed')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`Removed **${amount.toLocaleString()}** eggs from **${user.username}**`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**New Balance:** ${newBalance.toLocaleString()} eggs`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
