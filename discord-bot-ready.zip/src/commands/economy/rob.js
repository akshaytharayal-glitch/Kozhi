import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { addBalance, removeBalance, getBalance } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('rob')
    .setDescription('Rob eggs from another player with help of fox')
    .addUserOption(option =>
      option.setName('target')
        .setDescription('The player to rob eggs from')
        .setRequired(true)),
  
  cooldown: 60,
  
  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const target = interaction.options.getUser('target');
    
    if (target.id === userId) {
      return interaction.reply({ content: 'You cannot rob yourself!', flags: 64 });
    }
    
    if (target.bot) {
      return interaction.reply({ content: 'You cannot rob bots!', flags: 64 });
    }
    
    const targetBalance = getBalance(guildId, target.id);
    
    if (targetBalance < 10) {
      return interaction.reply({ content: `**${target.username}** doesn't have enough eggs to rob!`, flags: 64 });
    }
    
    const successChance = Math.random();
    
    if (successChance < 0.4) {
      const eggsRobbed = Math.floor(Math.random() * 71) + 10;
      const actualRobbed = Math.min(eggsRobbed, targetBalance);
      
      removeBalance(guildId, target.id, actualRobbed);
      const newBalance = addBalance(guildId, userId, actualRobbed);
      
      const container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Fox Heist Success!')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`With the help of fox you've robbed **${actualRobbed}** eggs from **${target.username}**!\n\n**Eggs Stolen:** ${actualRobbed}\n**Your Total Eggs:** ${newBalance.toLocaleString()}\n\n*The fox disappears into the shadows...*`)
            )
        );
      
      await interaction.reply({ content: `<@${target.id}>`, components: [container], flags: MessageFlags.IsComponentsV2 });
    } else {
      const eggsLost = Math.floor(Math.random() * 21) + 10;
      const robberBalance = getBalance(guildId, userId);
      const actualLost = Math.min(eggsLost, robberBalance);
      
      const newBalance = removeBalance(guildId, userId, actualLost);
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Caught Red-Handed!')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`You tried to rob **${target.username}** but got caught! You lost **${actualLost}** eggs as a fine!\n\n**Eggs Lost:** -${actualLost}\n**Your Total Eggs:** ${newBalance.toLocaleString()}\n\n*The fox abandoned you and ran away!*`)
            )
        );
      
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  },
};
