import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { getLeaderboard } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the members with the most eggs in the server'),
  
  async execute(interaction) {
    const leaderboard = getLeaderboard(interaction.guild.id, 10);
    
    if (leaderboard.length === 0) {
      return interaction.reply({ content: 'No one has collected any eggs yet!', flags: 64 });
    }
    
    const medals = ['', '', ''];
    
    const leaderboardText = await Promise.all(
      leaderboard.map(async (entry, index) => {
        try {
          const user = await interaction.client.users.fetch(entry.userId);
          const medal = medals[index] || `**${index + 1}.**`;
          return `${medal} ${user.username} - **${entry.balance.toLocaleString()}** eggs`;
        } catch {
          return `**${index + 1}.** Unknown User - **${entry.balance.toLocaleString()}** eggs`;
        }
      })
    );
    
    const container = new ContainerBuilder()
      .setAccentColor(0xFFD700)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Egg Leaderboard')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(leaderboardText.join('\n'))
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*${interaction.guild.name}*`)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
