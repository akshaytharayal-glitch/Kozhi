import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ButtonBuilder, ButtonStyle, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import axios from 'axios';

const subreddits = [
  'memes', 'dankmemes', 'wholesomememes', 'me_irl', 'funny',
  'ProgrammerHumor', 'gaming', 'AdviceAnimals', 'MemeEconomy',
  'comedyheaven', 'historymemes', 'facepalm', 'PrequelMemes',
  'Starterpacks', 'blursedimages', 'antimeme', 'surrealmemes',
  'bonehurtingjuice', 'technicallythetruth', 'trippinthroughtime',
  'BikiniBottomTwitter', 'lotrmemes'
];

const searchKeywords = [
  'funny', 'sad', 'happy', 'angry', 'love', 'hate', 'cat', 'dog', 'work', 'school',
  'monday', 'friday', 'weekend', 'sleep', 'food', 'coffee', 'gaming', 'anime',
  'programming', 'coding', 'bug', 'debug', 'relationship', 'single', 'dating',
  'friends', 'family', 'parents', 'kids', 'money', 'rich', 'poor', 'broke',
  'gym', 'fitness', 'lazy', 'tired', 'energy', 'mood', 'vibe', 'sus', 'based',
  'cringe', 'wholesome', 'dark', 'dank', 'cursed', 'blessed', 'bruh', 'oof',
  'introvert', 'extrovert', 'anxiety', 'stress', 'chill', 'relax', 'party',
  'studying', 'exam', 'homework', 'teacher', 'boss', 'coworker', 'meeting',
  'winter', 'summer', 'christmas', 'halloween', 'birthday', 'star wars',
  'marvel', 'dc', 'disney', 'netflix', 'movies', 'tv shows', 'music', 'discord'
];

export default {
  data: new SlashCommandBuilder()
    .setName('meme')
    .setDescription('Get random memes from Reddit!')
    .addStringOption(option =>
      option.setName('subreddit')
        .setDescription('Choose a specific subreddit (optional)')
        .setRequired(false)
        .setAutocomplete(true)),
  
  aliases: ['memes', 'reddit', 'funny'],
  cooldown: 3,
  
  async autocomplete(interaction) {
    const focusedValue = interaction.options.getFocused().toLowerCase();
    
    let suggestions;
    if (!focusedValue) {
      suggestions = subreddits.slice(0, 25).map(sub => ({
        name: `r/${sub}`,
        value: sub
      }));
    } else {
      const subMatches = subreddits
        .filter(sub => sub.toLowerCase().includes(focusedValue))
        .slice(0, 25)
        .map(sub => ({ name: `r/${sub}`, value: sub }));
      
      suggestions = subMatches;
      
      if (suggestions.length === 0) {
        suggestions = [{ name: `r/${focusedValue}`, value: focusedValue }];
      }
    }
    
    await interaction.respond(suggestions);
  },
  
  async execute(interaction) {
    await interaction.deferReply();
    
    const subreddit = interaction.options.getString('subreddit') || '';
    
    try {
      const meme = await fetchMemeFromAPI(subreddit);
      
      if (!meme) {
        return interaction.editReply('No memes found! Try a different subreddit.');
      }
      
      const container = createMemeContainer(meme, subreddit);
      
      await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    } catch (error) {
      console.error('Meme fetch error:', error);
      await interaction.editReply('Failed to fetch memes. Please try again later!');
    }
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('meme_')) return;
    
    const parts = interaction.customId.split('_');
    const action = parts[1];
    let subreddit = parts.slice(2).join('_');
    
    if (subreddit === 'random' || action === 'shuffle') {
      subreddit = '';
    }
    
    await interaction.deferUpdate();
    
    try {
      const meme = await fetchMemeFromAPI(subreddit);
      
      if (!meme) {
        return interaction.followUp({ content: 'No more memes found!', ephemeral: true });
      }
      
      const container = createMemeContainer(meme, subreddit);
      
      await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    } catch (error) {
      console.error('Meme button error:', error);
      await interaction.followUp({ content: 'Failed to fetch memes!', ephemeral: true });
    }
  },
};

async function fetchMemeFromAPI(subreddit = '') {
  try {
    const endpoint = subreddit 
      ? `https://meme-api.com/gimme/${subreddit}`
      : 'https://meme-api.com/gimme';
    
    const response = await axios.get(endpoint, {
      timeout: 10000,
      headers: { 'User-Agent': 'DiscordBot/1.0' }
    });
    
    const data = response.data;
    
    if (data.nsfw) {
      return fetchMemeFromAPI(subreddit);
    }
    
    return {
      title: data.title,
      url: data.url,
      subreddit: data.subreddit,
      author: data.author,
      postLink: data.postLink,
      ups: data.ups,
      preview: data.preview
    };
  } catch (error) {
    if (error.response?.status === 400 || error.response?.status === 404) {
      return fetchMemeFromAPI('');
    }
    console.error('Meme API error:', error.message);
    return null;
  }
}

function createMemeContainer(meme, subreddit) {
  const title = meme.title.length > 100 ? meme.title.slice(0, 97) + '...' : meme.title;
  
  return new ContainerBuilder()
    .setAccentColor(0xFF4500)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 😂 Random Meme')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**${title}**`)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`[View Meme Image](${meme.url})`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`👍 ${meme.ups?.toLocaleString() || '0'} | r/${meme.subreddit} | Posted by u/${meme.author}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🔄 **Next Meme**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId(`meme_next_${subreddit || 'random'}`)
            .setLabel('Next')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🎲 **Random Subreddit**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('meme_shuffle_random')
            .setLabel('Random')
            .setStyle(ButtonStyle.Secondary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🔗 **View on Reddit**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setLabel('Reddit')
            .setStyle(ButtonStyle.Link)
            .setURL(meme.postLink)
        )
    );
}
