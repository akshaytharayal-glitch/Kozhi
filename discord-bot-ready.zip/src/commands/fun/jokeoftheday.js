import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ButtonBuilder, ButtonStyle, MessageFlags, SeparatorSpacingSize, PermissionFlagsBits } from 'discord.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';

const JOTD_FILE = './data/jokeoftheday.json';

const dailyJokes = [
  { setup: "Why don't scientists trust atoms?", punchline: "Because they make up everything!", category: "Science" },
  { setup: "What do you call a fake noodle?", punchline: "An impasta!", category: "Food" },
  { setup: "Why did the scarecrow win an award?", punchline: "Because he was outstanding in his field!", category: "Farm" },
  { setup: "Why don't eggs tell jokes?", punchline: "They'd crack each other up!", category: "Food" },
  { setup: "What do you call a bear with no teeth?", punchline: "A gummy bear!", category: "Animals" },
  { setup: "Why did the bicycle fall over?", punchline: "Because it was two-tired!", category: "Transport" },
  { setup: "What did the ocean say to the beach?", punchline: "Nothing, it just waved!", category: "Nature" },
  { setup: "Why can't you give Elsa a balloon?", punchline: "Because she will let it go!", category: "Movies" },
  { setup: "What do you call a sleeping dinosaur?", punchline: "A dino-snore!", category: "Animals" },
  { setup: "Why did the cookie go to the hospital?", punchline: "Because it was feeling crummy!", category: "Food" },
  { setup: "What's the best thing about Switzerland?", punchline: "I don't know, but the flag is a big plus!", category: "Geography" },
  { setup: "I'm reading a book about anti-gravity.", punchline: "It's impossible to put down!", category: "Science" },
  { setup: "How do you organize a space party?", punchline: "You planet!", category: "Space" },
  { setup: "What do you call cheese that isn't yours?", punchline: "Nacho cheese!", category: "Food" },
  { setup: "Why don't skeletons fight each other?", punchline: "They don't have the guts!", category: "Spooky" },
  { setup: "What do you call a fish without eyes?", punchline: "A fsh!", category: "Animals" },
  { setup: "Why did the golfer bring two pairs of pants?", punchline: "In case he got a hole in one!", category: "Sports" },
  { setup: "What do you call a man with no arms and no legs in a pool?", punchline: "Bob!", category: "Classic" },
  { setup: "Why do fathers take an extra pair of socks when they go golfing?", punchline: "In case they get a hole in one!", category: "Sports" },
  { setup: "I used to hate facial hair...", punchline: "But then it grew on me.", category: "Puns" },
  { setup: "What did the buffalo say to his son when he left?", punchline: "Bison!", category: "Animals" },
  { setup: "Why couldn't the bicycle stand up by itself?", punchline: "It was two tired.", category: "Transport" },
  { setup: "I'm afraid for the calendar.", punchline: "Its days are numbered.", category: "Time" },
  { setup: "Why do dads take an extra pair of socks when they play golf?", punchline: "In case they get a hole in one!", category: "Sports" },
  { setup: "What's brown and sticky?", punchline: "A stick!", category: "Classic" },
  { setup: "Did you hear about the claustrophobic astronaut?", punchline: "He just needed a little space.", category: "Space" },
  { setup: "I told my wife she should embrace her mistakes.", punchline: "She hugged me.", category: "Marriage" },
  { setup: "What's the best time to go to the dentist?", punchline: "Tooth-hurty!", category: "Health" },
  { setup: "I'm thinking of taking up meditation.", punchline: "I figure it's better than sitting around doing nothing.", category: "Mindfulness" },
  { setup: "Why do programmers prefer dark mode?", punchline: "Because light attracts bugs!", category: "Tech" },
  { setup: "Why do Java developers wear glasses?", punchline: "Because they don't C#!", category: "Tech" },
];

function getJOTDData() {
  if (!existsSync(JOTD_FILE)) {
    return {};
  }
  try {
    return JSON.parse(readFileSync(JOTD_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function saveJOTDData(data) {
  writeFileSync(JOTD_FILE, JSON.stringify(data, null, 2));
}

function getTodayString() {
  return new Date().toISOString().split('T')[0];
}

function getDailyJoke() {
  const today = getTodayString();
  const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24));
  const jokeIndex = dayOfYear % dailyJokes.length;
  return { joke: dailyJokes[jokeIndex], date: today };
}

export default {
  data: new SlashCommandBuilder()
    .setName('jokeoftheday')
    .setDescription('Get the joke of the day or set up daily jokes!')
    .addSubcommand(subcommand =>
      subcommand
        .setName('get')
        .setDescription('Get today\'s joke'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Set up automatic daily jokes in a channel')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('Channel to post daily jokes')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('time')
            .setDescription('Time to post (HH:MM in 24h format, e.g., 09:00)')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('disable')
        .setDescription('Disable automatic daily jokes')),
  
  aliases: ['jotd', 'dailyjoke', 'todaysjoke'],
  cooldown: 5,
  
  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    
    if (subcommand === 'get') {
      const { joke, date } = getDailyJoke();
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFFD700)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 📅 Joke of the Day')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Question:** ${joke.setup}`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Answer:** ||${joke.punchline}||`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`📁 **Category:** ${joke.category}`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`*Date: ${date} | Click the spoiler to reveal!*`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('📢 **Share with Friends!**')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId('jotd_share')
                .setLabel('Share')
                .setStyle(ButtonStyle.Primary)
            )
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('😂 **Rate: Funny**')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId('jotd_rate_good')
                .setLabel('Funny')
                .setStyle(ButtonStyle.Success)
            )
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('😐 **Rate: Meh**')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId('jotd_rate_bad')
                .setLabel('Meh')
                .setStyle(ButtonStyle.Secondary)
            )
        );
      
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    } else if (subcommand === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ content: 'You need Manage Server permission to set up daily jokes!', ephemeral: true });
      }
      
      const channel = interaction.options.getChannel('channel');
      const time = interaction.options.getString('time') || '09:00';
      
      const timeRegex = /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/;
      if (!timeRegex.test(time)) {
        return interaction.reply({ content: 'Invalid time format! Use HH:MM (e.g., 09:00, 14:30)', ephemeral: true });
      }
      
      const data = getJOTDData();
      data[interaction.guild.id] = {
        channelId: channel.id,
        time: time,
        enabled: true,
        lastPosted: null
      };
      saveJOTDData(data);
      
      const container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Daily Jokes Set Up!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Daily jokes will be posted in ${channel}!`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`📍 **Channel:** <#${channel.id}>`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`⏰ **Time:** ${time}`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('*A new joke will be posted every day!*')
        );
      
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    } else if (subcommand === 'disable') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ content: 'You need Manage Server permission to disable daily jokes!', ephemeral: true });
      }
      
      const data = getJOTDData();
      if (data[interaction.guild.id]) {
        data[interaction.guild.id].enabled = false;
        saveJOTDData(data);
      }
      
      await interaction.reply({ content: 'Daily jokes have been disabled for this server!', ephemeral: true });
    }
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('jotd_')) return;
    
    if (interaction.customId === 'jotd_share') {
      const { joke } = getDailyJoke();
      return interaction.reply({ 
        content: `📢 **Joke of the Day shared by ${interaction.user}!**\n\n❓ ${joke.setup}\n\n😂 ||${joke.punchline}||`,
      });
    }
    
    if (interaction.customId === 'jotd_rate_good') {
      return interaction.reply({ content: 'Glad you liked it!', ephemeral: true });
    }
    
    if (interaction.customId === 'jotd_rate_bad') {
      return interaction.reply({ content: 'We\'ll try better tomorrow!', ephemeral: true });
    }
  },
  
  async checkAndPostDailyJokes(client) {
    const data = getJOTDData();
    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const today = getTodayString();
    
    for (const [guildId, settings] of Object.entries(data)) {
      if (!settings.enabled) continue;
      if (settings.lastPosted === today) continue;
      if (settings.time !== currentTime) continue;
      
      try {
        const channel = await client.channels.fetch(settings.channelId);
        if (!channel) continue;
        
        const { joke } = getDailyJoke();
        
        const container = new ContainerBuilder()
          .setAccentColor(0xFFD700)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 📅 Joke of the Day!')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Question:** ${joke.setup}`)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Answer:** ||${joke.punchline}||`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`📁 **Category:** ${joke.category}`)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*Click the spoiler to reveal! | ${today}*`)
          );
        
        await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        
        data[guildId].lastPosted = today;
        saveJOTDData(data);
      } catch (error) {
        console.error(`Failed to post JOTD in guild ${guildId}:`, error);
      }
    }
  }
};

export { getJOTDData, getDailyJoke };
