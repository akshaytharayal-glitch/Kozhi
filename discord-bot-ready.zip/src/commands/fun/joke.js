import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ButtonBuilder, ButtonStyle, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import axios from 'axios';

const englishJokes = [
  { setup: "Why don't scientists trust atoms?", punchline: "Because they make up everything!" },
  { setup: "What do you call a fake noodle?", punchline: "An impasta!" },
  { setup: "Why did the scarecrow win an award?", punchline: "Because he was outstanding in his field!" },
  { setup: "What do you call a bear with no teeth?", punchline: "A gummy bear!" },
  { setup: "Why don't eggs tell jokes?", punchline: "They'd crack each other up!" },
  { setup: "What did the ocean say to the beach?", punchline: "Nothing, it just waved!" },
  { setup: "Why did the bicycle fall over?", punchline: "Because it was two-tired!" },
  { setup: "What do you call a fish without eyes?", punchline: "A fsh!" },
  { setup: "Why can't you give Elsa a balloon?", punchline: "Because she will let it go!" },
  { setup: "What did one wall say to the other wall?", punchline: "I'll meet you at the corner!" },
  { setup: "Why did the golfer bring two pairs of pants?", punchline: "In case he got a hole in one!" },
  { setup: "What do you call a sleeping dinosaur?", punchline: "A dino-snore!" },
  { setup: "Why did the cookie go to the hospital?", punchline: "Because it was feeling crummy!" },
  { setup: "What do you call a cow with no legs?", punchline: "Ground beef!" },
  { setup: "Why don't skeletons fight each other?", punchline: "They don't have the guts!" },
];

const dadJokes = [
  { setup: "I'm reading a book about anti-gravity.", punchline: "It's impossible to put down!" },
  { setup: "Did you hear about the guy who invented the knock-knock joke?", punchline: "He won the 'no-bell' prize!" },
  { setup: "I used to hate facial hair...", punchline: "But then it grew on me." },
  { setup: "Why don't oysters donate to charity?", punchline: "Because they're shellfish!" },
  { setup: "I'm on a seafood diet.", punchline: "I see food and I eat it!" },
  { setup: "What's the best thing about Switzerland?", punchline: "I don't know, but the flag is a big plus!" },
  { setup: "I used to be a banker...", punchline: "But I lost interest." },
  { setup: "What do you call a man with no arms and no legs in a pool?", punchline: "Bob!" },
  { setup: "I asked my dad for his best dad joke.", punchline: "He said, 'You.'" },
  { setup: "Why did the man fall into a well?", punchline: "Because he couldn't see that well!" },
  { setup: "What do you call a factory that makes okay products?", punchline: "A satisfactory!" },
  { setup: "I've got a great joke about construction...", punchline: "But I'm still working on it!" },
  { setup: "Why do fathers take an extra pair of socks when they go golfing?", punchline: "In case they get a hole in one!" },
  { setup: "I wouldn't buy anything with velcro.", punchline: "It's a total rip-off!" },
  { setup: "What did the janitor say when he jumped out of the closet?", punchline: "Supplies!" },
  { setup: "Why couldn't the bicycle stand up by itself?", punchline: "It was two tired." },
  { setup: "I'm afraid for the calendar.", punchline: "Its days are numbered." },
  { setup: "What do you call cheese that isn't yours?", punchline: "Nacho cheese!" },
  { setup: "I only know 25 letters of the alphabet.", punchline: "I don't know y." },
  { setup: "What's brown and sticky?", punchline: "A stick!" },
];

const malayalamJokes = [
  { joke: "Teacher: നിന്റെ ഹോംവർക്ക് എവിടെ?\nStudent: സാർ, എന്റെ നായ തിന്നു.\nTeacher: നിനക്ക് നായ ഇല്ലല്ലോ!\nStudent: അതാണ് സാർ, കടം വാങ്ങി", language: "Malayalam" },
  { joke: "ഭർത്താവ്: ഇന്നത്തെ ഭക്ഷണം എന്താ?\nഭാര്യ: നിന്റെ ഇഷ്ടം\nഭർത്താവ്: ബിരിയാണി\nഭാര്യ: ഇന്ന് ചോറും സാമ്പാറും", language: "Malayalam" },
  { joke: "Doctor: നിങ്ങൾ എന്താണ് കഴിക്കുന്നത്?\nPatient: ഞാൻ കഴിക്കുന്നത് മാത്രം\nDoctor: ...", language: "Malayalam" },
  { joke: "അമ്മ: മോനേ, പഠിക്കുന്നുണ്ടോ?\nമകൻ: ഉണ്ട്\nഅമ്മ: എന്നാൽ ഫോൺ എവിടെ നിന്ന് വന്നു?\nമകൻ: ...silence", language: "Malayalam" },
  { joke: "ചോദ്യം: ലോകത്തിലെ ഏറ്റവും വലിയ झूठ എന്താണ്?\nഉത്തരം: 'ഞാൻ 5 മിനിറ്റിൽ എത്തും'", language: "Malayalam" },
];

const hindiJokes = [
  { joke: "टीचर: तुम स्कूल क्यों नहीं आए?\nस्टूडेंट: सर, मेरे पापा ने बोला था घर पर रहो।\nटीचर: क्यों?\nस्टूडेंट: वो तो पता नहीं, बस बोला 'तू घर का ही नहीं है'", language: "Hindi" },
  { joke: "पप्पू: पापा, आपने मम्मी को देखते ही प्यार किया था?\nपापा: नहीं बेटा, पहले salary देखी थी।\nमम्मी: ...", language: "Hindi" },
  { joke: "डॉक्टर: आप क्या खाते हो?\nमरीज: जो मिलता है।\nडॉक्टर: तो फिर बीमार क्यों हो?\nमरीज: क्योंकि कुछ मिलता नहीं", language: "Hindi" },
  { joke: "वाइफ: मुझे शॉपिंग जाना है।\nहसबैंड: ठीक है।\nवाइफ: पैसे दो।\nहसबैंड: मैं भी चलता हूं", language: "Hindi" },
];

const spanishJokes = [
  { joke: "¿Qué le dice un jardinero a otro?\n¡Nos vemos cuando podamos!", language: "Spanish" },
  { joke: "¿Por qué los pájaros no usan Facebook?\nPorque ya tienen Twitter", language: "Spanish" },
  { joke: "¿Qué hace una abeja en el gimnasio?\n¡Zum-ba!", language: "Spanish" },
  { joke: "¿Por qué el libro de matemáticas está triste?\nPorque tiene muchos problemas", language: "Spanish" },
];

const frenchJokes = [
  { joke: "Pourquoi les plongeurs plongent-ils toujours en arrière?\nParce que sinon ils tomberaient dans le bateau!", language: "French" },
  { joke: "Qu'est-ce qu'un crocodile qui surveille?\nUn croco-vigile!", language: "French" },
  { joke: "Pourquoi les fantômes sont-ils de mauvais menteurs?\nParce qu'on peut voir à travers eux!", language: "French" },
];

const germanJokes = [
  { joke: "Was macht ein Clown im Büro?\nFaxen!", language: "German" },
  { joke: "Warum können Geister so schlecht lügen?\nWeil man durch sie hindurchsehen kann!", language: "German" },
  { joke: "Was ist grün und steht vor der Tür?\nEin Klopfsalat!", language: "German" },
];

const japaneseJokes = [
  { joke: "パンはパンでも食べられないパンは?\nフライパン!", language: "Japanese" },
  { joke: "布団が吹っ飛んだ!\n(Futon ga futtonda - The futon flew away!)", language: "Japanese" },
  { joke: "猫が寝転んだ\n(Neko ga nekoronda - The cat lay down)", language: "Japanese" },
];

const portugueseJokes = [
  { joke: "Por que o livro de matemática se suicidou?\nPorque tinha muitos problemas!", language: "Portuguese" },
  { joke: "O que o pato disse para a pata?\nVem Quá!", language: "Portuguese" },
];

const koreanJokes = [
  { joke: "왜 수학책이 슬퍼요?\n문제가 많아서요!", language: "Korean" },
  { joke: "개가 사람을 물면? 견인!", language: "Korean" },
  { joke: "세상에서 가장 빠른 닭은? 후딱!", language: "Korean" },
];

const tamilJokes = [
  { joke: "Teacher: உன் homework எங்க?\nStudent: Sir, என் dog சாப்பிட்டுச்சு!\nTeacher: உனக்கு dog இல்லையே!\nStudent: அதான் sir, கடன் வாங்கினேன்", language: "Tamil" },
  { joke: "Doctor: என்ன பிரச்சனை?\nPatient: நான் invisible ஆயிட்டேன் sir!\nDoctor: இப்போ உங்களை பார்க்க முடியாது", language: "Tamil" },
];

const teluguJokes = [
  { joke: "Teacher: నీ homework ఎక్కడ?\nStudent: Sir, మా dog తినేసింది!\nTeacher: నీకు dog లేదుగా!\nStudent: అందుకే sir, అప్పు తీసుకున్నా", language: "Telugu" },
  { joke: "Wife: Shopping కి money కావాలి\nHusband: ATM లో ఉంది\nWife: PIN number?\nHusband: నేను కూడా వస్తా", language: "Telugu" },
];

const arabicJokes = [
  { joke: "ليش الكتاب رايح الدكتور?\nلأنه عنده مشاكل كثير!", language: "Arabic" },
  { joke: "شو قال البحر للشاطئ?\nما قال شي، بس لوّح!", language: "Arabic" },
];

const russianJokes = [
  { joke: "Почему программисты путают Хэллоуин и Рождество?\nПотому что Oct 31 = Dec 25!", language: "Russian" },
  { joke: "Что сказал один стол другому?\nДавай поставимся!", language: "Russian" },
];

const allJokesByLanguage = {
  english: { name: 'English', flag: '🇬🇧', jokes: englishJokes, type: 'setup' },
  dad: { name: 'Dad Jokes', flag: '👨', jokes: dadJokes, type: 'setup' },
  malayalam: { name: 'Malayalam', flag: '🇮🇳', jokes: malayalamJokes, type: 'single' },
  hindi: { name: 'Hindi', flag: '🇮🇳', jokes: hindiJokes, type: 'single' },
  tamil: { name: 'Tamil', flag: '🇮🇳', jokes: tamilJokes, type: 'single' },
  telugu: { name: 'Telugu', flag: '🇮🇳', jokes: teluguJokes, type: 'single' },
  spanish: { name: 'Spanish', flag: '🇪🇸', jokes: spanishJokes, type: 'single' },
  french: { name: 'French', flag: '🇫🇷', jokes: frenchJokes, type: 'single' },
  german: { name: 'German', flag: '🇩🇪', jokes: germanJokes, type: 'single' },
  japanese: { name: 'Japanese', flag: '🇯🇵', jokes: japaneseJokes, type: 'single' },
  portuguese: { name: 'Portuguese', flag: '🇧🇷', jokes: portugueseJokes, type: 'single' },
  arabic: { name: 'Arabic', flag: '🇸🇦', jokes: arabicJokes, type: 'single' },
  russian: { name: 'Russian', flag: '🇷🇺', jokes: russianJokes, type: 'single' },
  korean: { name: 'Korean', flag: '🇰🇷', jokes: koreanJokes, type: 'single' },
};

async function fetchOnlineJoke() {
  try {
    const response = await axios.get('https://official-joke-api.appspot.com/random_joke', { timeout: 5000 });
    return { setup: response.data.setup, punchline: response.data.punchline };
  } catch {
    return null;
  }
}

async function fetchDadJoke() {
  try {
    const response = await axios.get('https://icanhazdadjoke.com/', {
      headers: { 'Accept': 'application/json' },
      timeout: 5000
    });
    return response.data.joke;
  } catch {
    return null;
  }
}

export default {
  data: new SlashCommandBuilder()
    .setName('joke')
    .setDescription('Get a random joke in various languages!')
    .addStringOption(option =>
      option.setName('language')
        .setDescription('Choose a language for the joke')
        .setRequired(false)
        .addChoices(
          { name: '🇬🇧 English', value: 'english' },
          { name: '👨 Dad Jokes', value: 'dad' },
          { name: '🇮🇳 Malayalam', value: 'malayalam' },
          { name: '🇮🇳 Hindi', value: 'hindi' },
          { name: '🇮🇳 Tamil', value: 'tamil' },
          { name: '🇮🇳 Telugu', value: 'telugu' },
          { name: '🇪🇸 Spanish', value: 'spanish' },
          { name: '🇫🇷 French', value: 'french' },
          { name: '🇩🇪 German', value: 'german' },
          { name: '🇯🇵 Japanese', value: 'japanese' },
          { name: '🇧🇷 Portuguese', value: 'portuguese' },
          { name: '🇸🇦 Arabic', value: 'arabic' },
          { name: '🇷🇺 Russian', value: 'russian' },
          { name: '🇰🇷 Korean', value: 'korean' },
          { name: '🎲 Random', value: 'random' }
        )),
  
  aliases: ['jokes', 'funny', 'lol', 'haha'],
  cooldown: 3,
  
  async execute(interaction) {
    await interaction.deferReply();
    
    let language = interaction.options.getString('language') || 'random';
    
    if (language === 'random') {
      const languages = Object.keys(allJokesByLanguage);
      language = languages[Math.floor(Math.random() * languages.length)];
    }
    
    const container = await createJokeContainer(language);
    
    await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('joke_')) return;
    
    await interaction.deferUpdate();
    
    let language;
    if (interaction.customId === 'joke_random') {
      const languages = Object.keys(allJokesByLanguage);
      language = languages[Math.floor(Math.random() * languages.length)];
    } else if (interaction.customId === 'joke_dad') {
      language = 'dad';
    } else {
      language = interaction.customId.replace('joke_next_', '');
    }
    
    if (!allJokesByLanguage[language]) {
      const languages = Object.keys(allJokesByLanguage);
      language = languages[Math.floor(Math.random() * languages.length)];
    }
    
    const container = await createJokeContainer(language);
    
    await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};

async function createJokeContainer(language) {
  const langData = allJokesByLanguage[language];
  let jokeContent;
  let title;
  let color;
  
  if (language === 'english') {
    const onlineJoke = await fetchOnlineJoke();
    const joke = onlineJoke || langData.jokes[Math.floor(Math.random() * langData.jokes.length)];
    jokeContent = `**Question:** ${joke.setup}\n\n**Answer:** ||${joke.punchline}||`;
    title = `${langData.flag} ${langData.name} Joke`;
    color = 0xFFD700;
  } else if (language === 'dad') {
    const onlineDadJoke = await fetchDadJoke();
    if (onlineDadJoke && !onlineDadJoke.includes('?')) {
      jokeContent = onlineDadJoke;
    } else {
      const joke = langData.jokes[Math.floor(Math.random() * langData.jokes.length)];
      jokeContent = `**Question:** ${joke.setup}\n\n**Answer:** ||${joke.punchline}||`;
    }
    title = `${langData.flag} Dad Joke`;
    color = 0x8B4513;
  } else {
    const joke = langData.jokes[Math.floor(Math.random() * langData.jokes.length)];
    jokeContent = joke.joke;
    title = `${langData.flag} ${langData.name} Joke`;
    color = 0x00FF7F;
  }
  
  return new ContainerBuilder()
    .setAccentColor(color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# ${title}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(jokeContent)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('*Click the spoiler to reveal the punchline!*')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🔄 **Another One!**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId(`joke_next_${language}`)
            .setLabel('Next')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🎲 **Random Language**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('joke_random')
            .setLabel('Random')
            .setStyle(ButtonStyle.Secondary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('👨 **Dad Joke**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('joke_dad')
            .setLabel('Dad')
            .setStyle(ButtonStyle.Success)
        )
    );
}
