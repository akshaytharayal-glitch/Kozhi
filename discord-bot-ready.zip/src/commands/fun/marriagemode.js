import { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import { setMarriageMode } from '../../utils/marriageSettings.js';

export default {
  data: new SlashCommandBuilder()
    .setName('marriagemode')
    .setDescription('Toggle marriage matching mode (Admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(option =>
      option.setName('mode')
        .setDescription('Select the matching mode')
        .setRequired(true)
        .addChoices(
          { name: 'Role-Based (Male/Female matching)', value: 'role_based' },
          { name: 'Random (Any person matching)', value: 'random' }
        )),
  
  async execute(interaction) {
    const mode = interaction.options.getString('mode');
    const guildId = interaction.guildId;
    
    setMarriageMode(guildId, mode);
    
    const modeDescription = mode === 'role_based' 
      ? '**Role-Based Mode** is now active!\n\nUsers will be matched with someone of the opposite gender role (male/female).'
      : '**Random Mode** is now active!\n\nUsers will be matched with any random person, regardless of gender roles.';
    
    const container = new ContainerBuilder()
      .setAccentColor(mode === 'role_based' ? 0xFF69B4 : 0x9B59B6)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Marriage Mode Updated')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(modeDescription)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Current Mode:** ${mode === 'role_based' ? 'Role-Based' : 'Random'}`)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Changed By:** ${interaction.user}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('*Use this command again to switch modes*')
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
