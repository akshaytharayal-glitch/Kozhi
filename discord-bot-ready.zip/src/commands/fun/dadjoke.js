import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ButtonBuilder, ButtonStyle, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import axios from 'axios';

const dadJokes = [
  { setup: "I'm reading a book about anti-gravity.", punchline: "It's impossible to put down!" },
  { setup: "Did you hear about the guy who invented the knock-knock joke?", punchline: "He won the 'no-bell' prize!" },
  { setup: "I used to hate facial hair...", punchline: "But then it grew on me." },
  { setup: "Why don't oysters donate to charity?", punchline: "Because they're shellfish!" },
  { setup: "I'm on a seafood diet.", punchline: "I see food and I eat it!" },
  { setup: "What's the best thing about Switzerland?", punchline: "I don't know, but the flag is a big plus!" },
  { setup: "I used to be a banker...", punchline: "But I lost interest." },
  { setup: "What do you call a man with no arms and no legs in a pool?", punchline: "Bob!" },
  { setup: "I asked my dad for his best dad joke.", punchline: "He said, 'You.'" },
  { setup: "Why did the man fall into a well?", punchline: "Because he couldn't see that well!" },
  { setup: "What do you call a factory that makes okay products?", punchline: "A satisfactory!" },
  { setup: "I've got a great joke about construction...", punchline: "But I'm still working on it!" },
  { setup: "Why do fathers take an extra pair of socks when they go golfing?", punchline: "In case they get a hole in one!" },
  { setup: "I wouldn't buy anything with velcro.", punchline: "It's a total rip-off!" },
  { setup: "What did the janitor say when he jumped out of the closet?", punchline: "Supplies!" },
  { setup: "Why couldn't the bicycle stand up by itself?", punchline: "It was two tired." },
  { setup: "I'm afraid for the calendar.", punchline: "Its days are numbered." },
  { setup: "What do you call cheese that isn't yours?", punchline: "Nacho cheese!" },
  { setup: "I only know 25 letters of the alphabet.", punchline: "I don't know y." },
  { setup: "What's brown and sticky?", punchline: "A stick!" },
  { setup: "What did the buffalo say to his son when he left?", punchline: "Bison!" },
  { setup: "Why do dads take an extra pair of socks when they play golf?", punchline: "In case they get a hole in one!" },
  { setup: "How do you organize a space party?", punchline: "You planet!" },
  { setup: "What's the best time to go to the dentist?", punchline: "Tooth-hurty!" },
  { setup: "I'm thinking of taking up meditation.", punchline: "I figure it's better than sitting around doing nothing." },
  { setup: "What do you call a fish with no eyes?", punchline: "A fsh!" },
  { setup: "I told my wife she should embrace her mistakes.", punchline: "She hugged me." },
  { setup: "Did you hear about the claustrophobic astronaut?", punchline: "He just needed a little space." },
  { setup: "Why don't eggs tell jokes?", punchline: "They'd crack each other up!" },
  { setup: "I just got back from a job interview where I was asked if I could perform under pressure.", punchline: "I said no, but I can do a mean Bohemian Rhapsody!" },
];

async function fetchOnlineDadJoke() {
  try {
    const response = await axios.get('https://icanhazdadjoke.com/', {
      headers: { 'Accept': 'application/json' },
      timeout: 5000
    });
    return response.data.joke;
  } catch {
    return null;
  }
}

export default {
  data: new SlashCommandBuilder()
    .setName('dadjoke')
    .setDescription('Get the best (worst?) dad jokes!'),
  
  aliases: ['dad', 'dj', 'fatherjoke'],
  cooldown: 3,
  
  async execute(interaction) {
    await interaction.deferReply();
    
    const container = await createDadJokeContainer();
    
    await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('dadjoke_')) return;
    
    if (interaction.customId === 'dadjoke_groan') {
      return interaction.reply({ content: '*Collective groan*', ephemeral: true });
    }
    
    if (interaction.customId === 'dadjoke_laugh') {
      return interaction.reply({ content: 'Haha! Classic dad humor!', ephemeral: true });
    }
    
    await interaction.deferUpdate();
    
    const container = await createDadJokeContainer();
    
    await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};

async function createDadJokeContainer() {
  const onlineJoke = await fetchOnlineDadJoke();
  let jokeContent;
  
  if (onlineJoke) {
    jokeContent = onlineJoke;
  } else {
    const joke = dadJokes[Math.floor(Math.random() * dadJokes.length)];
    jokeContent = `**Question:** ${joke.setup}\n\n**Answer:** ||${joke.punchline}||`;
  }
  
  return new ContainerBuilder()
    .setAccentColor(0x8B4513)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 👨 Dad Joke')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(jokeContent)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('*adjusts belt* "That was a good one!"')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('👨 **Another Dad Joke!**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('dadjoke_next')
            .setLabel('Another')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('😩 **Groan**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('dadjoke_groan')
            .setLabel('Groan')
            .setStyle(ButtonStyle.Secondary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('😂 **Laugh**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('dadjoke_laugh')
            .setLabel('Laugh')
            .setStyle(ButtonStyle.Success)
        )
    );
}
