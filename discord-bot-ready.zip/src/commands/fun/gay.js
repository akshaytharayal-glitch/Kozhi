import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize, AttachmentBuilder } from 'discord.js';
import { createCanvas, loadImage } from 'canvas';

const OWNER_ID = process.env.OWNER_ID || '';

export default {
  data: new SlashCommandBuilder()
    .setName('gay')
    .setDescription('Check how gay someone is with a fancy image!')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to check (leave empty for yourself)')
        .setRequired(false)),
  
  aliases: ['howgay', 'gaymeter', 'gaytest'],
  cooldown: 5,
  
  async execute(interaction) {
    await interaction.deferReply();
    
    const target = interaction.options.getUser('user') || interaction.user;
    
    let percentage;
    
    if (OWNER_ID && target.id === OWNER_ID) {
      percentage = 0;
    } else {
      const seed = parseInt(target.id.slice(-8), 10);
      percentage = seed % 101;
    }
    
    const canvas = createCanvas(800, 400);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 800, 400);
    gradient.addColorStop(0, '#1a1a2e');
    gradient.addColorStop(0.5, '#16213e');
    gradient.addColorStop(1, '#0f3460');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 400);
    
    drawParticles(ctx, 800, 400);
    
    drawRainbowBorder(ctx, 800, 400);
    
    try {
      const avatarURL = target.displayAvatarURL({ extension: 'png', size: 256 });
      const avatar = await loadImage(avatarURL);
      
      ctx.save();
      ctx.beginPath();
      ctx.arc(150, 200, 80, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(avatar, 70, 120, 160, 160);
      ctx.restore();
      
      ctx.strokeStyle = getRainbowGradient(ctx, 70, 120, 230, 280);
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(150, 200, 82, 0, Math.PI * 2);
      ctx.stroke();
    } catch (error) {
      ctx.fillStyle = '#7289DA';
      ctx.beginPath();
      ctx.arc(150, 200, 80, 0, Math.PI * 2);
      ctx.fill();
    }
    
    ctx.font = 'bold 32px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';
    ctx.fillText(target.displayName || target.username, 270, 120);
    
    ctx.font = 'bold 72px Arial';
    const percentGradient = ctx.createLinearGradient(270, 150, 600, 220);
    if (percentage === 0) {
      percentGradient.addColorStop(0, '#FFD700');
      percentGradient.addColorStop(1, '#FFA500');
    } else if (percentage < 30) {
      percentGradient.addColorStop(0, '#00FF00');
      percentGradient.addColorStop(1, '#32CD32');
    } else if (percentage < 70) {
      percentGradient.addColorStop(0, '#FFFF00');
      percentGradient.addColorStop(1, '#FFA500');
    } else {
      percentGradient.addColorStop(0, '#FF69B4');
      percentGradient.addColorStop(1, '#FF1493');
    }
    ctx.fillStyle = percentGradient;
    ctx.fillText(`${percentage}%`, 270, 220);
    
    ctx.font = 'bold 24px Arial';
    ctx.fillStyle = '#888888';
    ctx.fillText('Gay Meter', 270, 260);
    
    const barX = 270;
    const barY = 290;
    const barWidth = 480;
    const barHeight = 30;
    
    ctx.fillStyle = '#333333';
    ctx.beginPath();
    ctx.roundRect(barX, barY, barWidth, barHeight, 15);
    ctx.fill();
    
    const filledWidth = (percentage / 100) * barWidth;
    if (filledWidth > 0) {
      const barGradient = ctx.createLinearGradient(barX, barY, barX + filledWidth, barY);
      barGradient.addColorStop(0, '#FF0018');
      barGradient.addColorStop(0.2, '#FFA52C');
      barGradient.addColorStop(0.4, '#FFFF41');
      barGradient.addColorStop(0.6, '#008018');
      barGradient.addColorStop(0.8, '#0000F9');
      barGradient.addColorStop(1, '#86007D');
      ctx.fillStyle = barGradient;
      ctx.beginPath();
      ctx.roundRect(barX, barY, filledWidth, barHeight, 15);
      ctx.fill();
    }
    
    ctx.font = 'italic 18px Arial';
    ctx.fillStyle = '#aaaaaa';
    ctx.textAlign = 'center';
    const message = getMessage(percentage);
    ctx.fillText(message, 510, 365);
    
    const attachment = new AttachmentBuilder(canvas.toBuffer('image/png'), { name: 'gay-meter.png' });
    
    let description = `**${target.displayName || target.username}** is **${percentage}%** gay!`;
    if (percentage === 0 && OWNER_ID && target.id === OWNER_ID) {
      description = '**VIP STATUS** - This person is certified 100% straight!';
    }
    
    const container = new ContainerBuilder()
      .setAccentColor(percentage === 0 ? 0xFFD700 : 0xFF69B4)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Gay Meter')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(description)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*${message}*`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*Requested by ${interaction.user.username}*`)
      );
    
    await interaction.editReply({ components: [container], files: [attachment], flags: MessageFlags.IsComponentsV2 });
  },
};

function drawParticles(ctx, width, height) {
  const colors = ['#FF0018', '#FFA52C', '#FFFF41', '#008018', '#0000F9', '#86007D'];
  
  for (let i = 0; i < 50; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const size = Math.random() * 4 + 1;
    const color = colors[Math.floor(Math.random() * colors.length)];
    
    ctx.fillStyle = color;
    ctx.globalAlpha = 0.3;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawRainbowBorder(ctx, width, height) {
  const borderWidth = 6;
  const gradient = ctx.createLinearGradient(0, 0, width, 0);
  gradient.addColorStop(0, '#FF0018');
  gradient.addColorStop(0.2, '#FFA52C');
  gradient.addColorStop(0.4, '#FFFF41');
  gradient.addColorStop(0.6, '#008018');
  gradient.addColorStop(0.8, '#0000F9');
  gradient.addColorStop(1, '#86007D');
  
  ctx.strokeStyle = gradient;
  ctx.lineWidth = borderWidth;
  ctx.strokeRect(borderWidth / 2, borderWidth / 2, width - borderWidth, height - borderWidth);
}

function getRainbowGradient(ctx, x1, y1, x2, y2) {
  const gradient = ctx.createLinearGradient(x1, y1, x2, y2);
  gradient.addColorStop(0, '#FF0018');
  gradient.addColorStop(0.2, '#FFA52C');
  gradient.addColorStop(0.4, '#FFFF41');
  gradient.addColorStop(0.6, '#008018');
  gradient.addColorStop(0.8, '#0000F9');
  gradient.addColorStop(1, '#86007D');
  return gradient;
}

function getMessage(percentage) {
  if (percentage === 0) return '100% Certified Straight - VIP Status!';
  if (percentage < 10) return 'Straight as an arrow!';
  if (percentage < 30) return 'Mostly straight with curious vibes';
  if (percentage < 50) return 'Bi-curious perhaps?';
  if (percentage < 70) return 'Definitely exploring!';
  if (percentage < 90) return 'Pretty fabulous!';
  return 'Maximum rainbow power activated!';
}
