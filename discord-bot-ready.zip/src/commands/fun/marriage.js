import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize, AttachmentBuilder } from 'discord.js';
import { createCanvas, loadImage } from 'canvas';
import { getMarriageMode } from '../../utils/marriageSettings.js';

const maleRoleNames = ['male', 'boy', 'man', 'husband', 'groom', '♂️', 'boys', 'he/him'];
const femaleRoleNames = ['female', 'girl', 'woman', 'wife', 'bride', '♀️', 'girls', 'she/her'];

export default {
  data: new SlashCommandBuilder()
    .setName('marriage')
    .setDescription('Find your random match from the server!'),
  
  aliases: ['marry', 'ship', 'couple', 'love'],
  cooldown: 10,
  
  async execute(interaction) {
    await interaction.deferReply();
    
    const person1 = interaction.user;
    const member1 = await interaction.guild.members.fetch(person1.id).catch(() => null);
    
    if (!member1) {
      return interaction.editReply({ content: 'Could not fetch your member data!' });
    }
    
    const mode = getMarriageMode(interaction.guildId);
    const role1 = getRoleType(member1);
    
    if (mode === 'role_based') {
      if (!role1) {
        return interaction.editReply({ 
          content: 'You need a **male** or **female** role to use this command!\n\nAsk an admin to give you a gender role first, or ask an admin to switch to random mode using `/marriagemode`.',
        });
      }
      
      const oppositeGender = role1 === 'male' ? 'female' : 'male';
      
      try {
        await interaction.guild.members.fetch();
      } catch (e) {
        console.log('Could not fetch all members, using cache');
      }
      
      const eligibleMembers = interaction.guild.members.cache.filter(member => {
        if (member.user.bot) return false;
        if (member.user.id === person1.id) return false;
        
        const memberRole = getRoleType(member);
        return memberRole === oppositeGender;
      });
      
      if (eligibleMembers.size === 0) {
        return interaction.editReply({ 
          content: `No ${oppositeGender} members found in this server!\n\nMake sure people have the appropriate gender roles.`,
        });
      }
      
      const randomIndex = Math.floor(Math.random() * eligibleMembers.size);
      const member2 = [...eligibleMembers.values()][randomIndex];
      
      await generateMatchImage(interaction, person1, member1, member2, role1, getRoleType(member2));
    } else {
      try {
        await interaction.guild.members.fetch();
      } catch (e) {
        console.log('Could not fetch all members, using cache');
      }
      
      const eligibleMembers = interaction.guild.members.cache.filter(member => {
        if (member.user.bot) return false;
        if (member.user.id === person1.id) return false;
        return true;
      });
      
      if (eligibleMembers.size === 0) {
        return interaction.editReply({ 
          content: 'No other members found in this server!',
        });
      }
      
      const randomIndex = Math.floor(Math.random() * eligibleMembers.size);
      const member2 = [...eligibleMembers.values()][randomIndex];
      const role2 = getRoleType(member2);
      
      await generateMatchImage(interaction, person1, member1, member2, role1, role2);
    }
  },
};

async function generateMatchImage(interaction, person1, member1, member2, role1, role2) {
  const person2 = member2.user;
  
  const combinedId = [person1.id, person2.id].sort().join('');
  const seed = parseInt(combinedId.slice(-10), 10);
  const compatibility = (seed % 61) + 40;
  
  const canvas = createCanvas(900, 500);
  const ctx = canvas.getContext('2d');
  
  const gradient = ctx.createRadialGradient(450, 250, 0, 450, 250, 500);
  gradient.addColorStop(0, '#2d1f3d');
  gradient.addColorStop(0.5, '#1a1a2e');
  gradient.addColorStop(1, '#0f0f1a');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 900, 500);
  
  drawHeartParticles(ctx, 900, 500);
  drawLoveBorder(ctx, 900, 500);
  
  try {
    const avatar1URL = person1.displayAvatarURL({ extension: 'png', size: 256 });
    const avatar1 = await loadImage(avatar1URL);
    
    ctx.save();
    ctx.beginPath();
    ctx.arc(150, 200, 90, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar1, 60, 110, 180, 180);
    ctx.restore();
    
    ctx.strokeStyle = role1 === 'male' ? '#4169E1' : role1 === 'female' ? '#FF69B4' : '#9B59B6';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(150, 200, 93, 0, Math.PI * 2);
    ctx.stroke();
  } catch {
    ctx.fillStyle = '#7289DA';
    ctx.beginPath();
    ctx.arc(150, 200, 90, 0, Math.PI * 2);
    ctx.fill();
  }
  
  try {
    const avatar2URL = person2.displayAvatarURL({ extension: 'png', size: 256 });
    const avatar2 = await loadImage(avatar2URL);
    
    ctx.save();
    ctx.beginPath();
    ctx.arc(750, 200, 90, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar2, 660, 110, 180, 180);
    ctx.restore();
    
    ctx.strokeStyle = role2 === 'male' ? '#4169E1' : role2 === 'female' ? '#FF69B4' : '#9B59B6';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(750, 200, 93, 0, Math.PI * 2);
    ctx.stroke();
  } catch {
    ctx.fillStyle = '#7289DA';
    ctx.beginPath();
    ctx.arc(750, 200, 90, 0, Math.PI * 2);
    ctx.fill();
  }
  
  drawHeart(ctx, 450, 180, 80);
  
  ctx.font = 'bold 48px Arial';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText(`${compatibility}%`, 450, 195);
  
  ctx.font = 'bold 22px Arial';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  
  const name1 = (member1.displayName || person1.username).slice(0, 15);
  const name2 = (member2.displayName || person2.username).slice(0, 15);
  
  ctx.fillText(name1, 150, 320);
  ctx.fillText(name2, 750, 320);
  
  ctx.font = '16px Arial';
  if (role1) {
    ctx.fillStyle = role1 === 'male' ? '#4169E1' : '#FF69B4';
    ctx.fillText(role1 === 'male' ? 'Male' : 'Female', 150, 345);
  } else {
    ctx.fillStyle = '#9B59B6';
    ctx.fillText('Member', 150, 345);
  }
  
  if (role2) {
    ctx.fillStyle = role2 === 'male' ? '#4169E1' : '#FF69B4';
    ctx.fillText(role2 === 'male' ? 'Male' : 'Female', 750, 345);
  } else {
    ctx.fillStyle = '#9B59B6';
    ctx.fillText('Member', 750, 345);
  }
  
  ctx.font = 'bold 28px Arial';
  ctx.textAlign = 'center';
  const statusGradient = ctx.createLinearGradient(200, 380, 700, 380);
  statusGradient.addColorStop(0, '#FF69B4');
  statusGradient.addColorStop(0.5, '#FF1493');
  statusGradient.addColorStop(1, '#FF69B4');
  ctx.fillStyle = statusGradient;
  
  const status = getRelationshipStatus(compatibility);
  ctx.fillText(status, 450, 400);
  
  ctx.font = 'italic 18px Arial';
  ctx.fillStyle = '#aaaaaa';
  const description = getRelationshipDescription(compatibility);
  ctx.fillText(description, 450, 435);
  
  ctx.font = '14px Arial';
  ctx.fillStyle = '#666666';
  ctx.fillText('Random Match - Marriage Compatibility', 450, 475);
  
  const attachment = new AttachmentBuilder(canvas.toBuffer('image/png'), { name: 'marriage.png' });
  
  const container = new ContainerBuilder()
    .setAccentColor(0xFF69B4)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# Your Random Match!')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**${person1.username}** has been matched with **${person2.username}**!`)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Compatibility:** ${compatibility}%`)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Status:** ${status}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`*${description}*`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`*Requested by ${interaction.user.username}*`)
    );
  
  await interaction.editReply({ content: `<@${person2.id}>`, components: [container], files: [attachment], flags: MessageFlags.IsComponentsV2 });
}

function getRoleType(member) {
  for (const role of member.roles.cache.values()) {
    const roleName = role.name.toLowerCase();
    if (maleRoleNames.some(r => roleName.includes(r))) return 'male';
    if (femaleRoleNames.some(r => roleName.includes(r))) return 'female';
  }
  return null;
}

function drawHeartParticles(ctx, width, height) {
  const colors = ['#FF69B4', '#FF1493', '#FF6B6B', '#FFB6C1', '#FFC0CB'];
  
  for (let i = 0; i < 30; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const size = Math.random() * 15 + 5;
    const color = colors[Math.floor(Math.random() * colors.length)];
    
    ctx.globalAlpha = 0.2;
    drawSmallHeart(ctx, x, y, size, color);
  }
  ctx.globalAlpha = 1;
}

function drawSmallHeart(ctx, x, y, size, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, y + size / 4);
  ctx.bezierCurveTo(x, y, x - size / 2, y, x - size / 2, y + size / 4);
  ctx.bezierCurveTo(x - size / 2, y + size / 2, x, y + size * 0.75, x, y + size);
  ctx.bezierCurveTo(x, y + size * 0.75, x + size / 2, y + size / 2, x + size / 2, y + size / 4);
  ctx.bezierCurveTo(x + size / 2, y, x, y, x, y + size / 4);
  ctx.fill();
}

function drawLoveBorder(ctx, width, height) {
  const borderWidth = 6;
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, '#FF69B4');
  gradient.addColorStop(0.5, '#FF1493');
  gradient.addColorStop(1, '#FF69B4');
  
  ctx.strokeStyle = gradient;
  ctx.lineWidth = borderWidth;
  ctx.strokeRect(borderWidth / 2, borderWidth / 2, width - borderWidth, height - borderWidth);
}

function drawHeart(ctx, x, y, size) {
  const gradient = ctx.createRadialGradient(x, y, 0, x, y, size);
  gradient.addColorStop(0, '#FF6B6B');
  gradient.addColorStop(0.5, '#FF1493');
  gradient.addColorStop(1, '#C71585');
  
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.moveTo(x, y + size / 4);
  ctx.bezierCurveTo(x, y, x - size / 2, y, x - size / 2, y + size / 4);
  ctx.bezierCurveTo(x - size / 2, y + size / 2, x, y + size * 0.75, x, y + size);
  ctx.bezierCurveTo(x, y + size * 0.75, x + size / 2, y + size / 2, x + size / 2, y + size / 4);
  ctx.bezierCurveTo(x + size / 2, y, x, y, x, y + size / 4);
  ctx.fill();
  
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 3;
  ctx.stroke();
}

function getRelationshipStatus(percentage) {
  if (percentage >= 90) return 'Perfect Match - Soulmates!';
  if (percentage >= 80) return 'Deeply In Love';
  if (percentage >= 70) return 'Strong Connection';
  if (percentage >= 60) return 'Good Chemistry';
  if (percentage >= 50) return 'Growing Bond';
  if (percentage >= 40) return 'Needs Work';
  return 'Not Compatible';
}

function getRelationshipDescription(percentage) {
  if (percentage >= 90) return 'Made for each other! Wedding bells are ringing!';
  if (percentage >= 80) return 'A beautiful love story in the making!';
  if (percentage >= 70) return 'Great potential for a lasting relationship!';
  if (percentage >= 60) return 'With some effort, love will bloom!';
  if (percentage >= 50) return 'The spark is there, keep nurturing it!';
  if (percentage >= 40) return 'Better as friends maybe?';
  return 'Perhaps look elsewhere for love...';
}
