import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';

const words = {
  animals: ['elephant', 'giraffe', 'penguin', 'dolphin', 'kangaroo', 'butterfly', 'crocodile', 'hamster', 'octopus', 'flamingo'],
  countries: ['australia', 'brazil', 'canada', 'germany', 'japan', 'mexico', 'norway', 'portugal', 'sweden', 'thailand'],
  food: ['pizza', 'spaghetti', 'hamburger', 'chocolate', 'strawberry', 'pineapple', 'avocado', 'pancakes', 'sandwich', 'watermelon'],
  movies: ['avatar', 'titanic', 'inception', 'gladiator', 'frozen', 'spiderman', 'batman', 'superman', 'starwars', 'jurassic'],
  sports: ['basketball', 'football', 'tennis', 'swimming', 'volleyball', 'baseball', 'hockey', 'cricket', 'boxing', 'surfing'],
  technology: ['computer', 'internet', 'keyboard', 'software', 'database', 'algorithm', 'programming', 'javascript', 'android', 'bluetooth']
};

const hangmanStages = [
  '```\n  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========```',
];

const categoryEmojis = {
  animals: '🐾',
  countries: '🌍',
  food: '🍕',
  movies: '🎬',
  sports: '⚽',
  technology: '💻'
};

const activeGames = new Map();

export default {
  data: new SlashCommandBuilder()
    .setName('hangman')
    .setDescription('Play Hangman!')
    .addStringOption(option =>
      option.setName('category')
        .setDescription('Choose a category')
        .setRequired(false)
        .addChoices(
          { name: '🐾 Animals', value: 'animals' },
          { name: '🌍 Countries', value: 'countries' },
          { name: '🍕 Food', value: 'food' },
          { name: '🎬 Movies', value: 'movies' },
          { name: '⚽ Sports', value: 'sports' },
          { name: '💻 Technology', value: 'technology' },
          { name: '🎲 Random', value: 'random' }
        )),
  
  aliases: ['hang', 'hm'],
  cooldown: 5,
  
  async execute(interaction) {
    let category = interaction.options.getString('category') || 'random';
    
    if (category === 'random') {
      const categories = Object.keys(words);
      category = categories[Math.floor(Math.random() * categories.length)];
    }
    
    const wordList = words[category];
    const word = wordList[Math.floor(Math.random() * wordList.length)].toLowerCase();
    
    const gameId = `hangman-${interaction.channel.id}`;
    
    if (activeGames.has(gameId)) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Game In Progress')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('A game is already in progress in this channel!')
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const game = {
      word,
      category,
      guessedLetters: new Set(),
      wrongGuesses: 0,
      maxWrong: 6,
      userId: interaction.user.id,
      startTime: Date.now()
    };
    
    activeGames.set(gameId, game);
    
    const container = createGameContainer(game);
    
    const buttons = createLetterButtons(game.guessedLetters);
    
    const message = await interaction.reply({ components: [container, ...buttons], flags: MessageFlags.IsComponentsV2, fetchReply: true });
    game.messageId = message.id;
    
    const filter = m => !m.author.bot && m.content.length === 1 && /[a-z]/i.test(m.content);
    const collector = interaction.channel.createMessageCollector({ filter, time: 300000 });
    
    collector.on('collect', async m => {
      try {
        const currentGame = activeGames.get(gameId);
        if (!currentGame) {
          collector.stop();
          return;
        }
        
        const letter = m.content.toLowerCase();
        
        if (currentGame.guessedLetters.has(letter)) {
          return;
        }
        
        currentGame.guessedLetters.add(letter);
        
        if (!currentGame.word.includes(letter)) {
          currentGame.wrongGuesses++;
        }
        
        try {
          await m.delete().catch(() => {});
        } catch {}
        
        if (currentGame.wrongGuesses >= currentGame.maxWrong) {
          collector.stop('lost');
          activeGames.delete(gameId);
          
          const loseContainer = new ContainerBuilder()
            .setAccentColor(0xFF0000)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('# 💀 Game Over!')
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${hangmanStages[6]}\n\nThe word was: **${currentGame.word.toUpperCase()}**`)
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('-# Better luck next time!')
            );
          
          try {
            await interaction.editReply({ components: [loseContainer], flags: MessageFlags.IsComponentsV2 });
          } catch {
            await m.channel.send({ components: [loseContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
          }
          return;
        }
        
        const displayWord = getDisplayWord(currentGame.word, currentGame.guessedLetters);
        
        if (!displayWord.includes('_')) {
          collector.stop('won');
          activeGames.delete(gameId);
          
          const timeTaken = ((Date.now() - currentGame.startTime) / 1000).toFixed(1);
          
          const winContainer = new ContainerBuilder()
            .setAccentColor(0x00FF00)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('# 🎉 You Won!')
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`The word was: **${currentGame.word.toUpperCase()}**`)
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addSectionComponents(
              new SectionBuilder()
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent(
                    `**⏱️ Time:** ${timeTaken}s\n` +
                    `**❌ Wrong Guesses:** ${currentGame.wrongGuesses}\n` +
                    `**📁 Category:** ${currentGame.category}`
                  )
                )
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('-# Great job!')
            );
          
          try {
            await interaction.editReply({ components: [winContainer], flags: MessageFlags.IsComponentsV2 });
          } catch {
            await m.channel.send({ components: [winContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
          }
          return;
        }
        
        const updatedContainer = createGameContainer(currentGame);
        const updatedButtons = createLetterButtons(currentGame.guessedLetters);
        
        try {
          await interaction.editReply({ components: [updatedContainer, ...updatedButtons], flags: MessageFlags.IsComponentsV2 });
        } catch {
          await m.channel.send({ components: [updatedContainer, ...updatedButtons], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
      } catch (error) {
        console.error('[Hangman] Collector error:', error);
      }
    });
    
    collector.on('end', async (collected, reason) => {
      try {
        const game = activeGames.get(gameId);
        if (reason === 'time' && game) {
          activeGames.delete(gameId);
          
          const timeoutContainer = new ContainerBuilder()
            .setAccentColor(0xFF0000)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent("# ⏰ Time's Up!")
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`The word was: **${game.word.toUpperCase()}**`)
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('-# Try again with /hangman!')
            );
          
          try {
            await interaction.editReply({ components: [timeoutContainer], flags: MessageFlags.IsComponentsV2 });
          } catch {
            await interaction.channel.send({ components: [timeoutContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
          }
        }
      } catch (error) {
        console.error('[Hangman] End handler error:', error);
      }
    });
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('hm_')) return;
    
    const gameId = `hangman-${interaction.channel.id}`;
    const game = activeGames.get(gameId);
    
    if (!game) {
      try {
        const expiredContainer = new ContainerBuilder()
          .setAccentColor(0x808080)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🎮 Game Ended')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('This game has ended or expired.\n\nStart a new game with `/hangman` or `ehangman`!')
          );
        
        await interaction.update({ components: [expiredContainer], flags: MessageFlags.IsComponentsV2 });
      } catch {
        const endedContainer = new ContainerBuilder()
          .setAccentColor(0xFF0000)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Game Ended')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('This game has ended! Start a new one with `/hangman`')
          );
        await interaction.reply({ components: [endedContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral }).catch(() => {});
      }
      return;
    }
    
    const letter = interaction.customId.replace('hm_', '');
    
    if (game.guessedLetters.has(letter)) {
      const alreadyGuessedContainer = new ContainerBuilder()
        .setAccentColor(0xFFA500)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Already Guessed')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('This letter was already guessed!')
        );
      return interaction.reply({ components: [alreadyGuessedContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    game.guessedLetters.add(letter);
    
    if (!game.word.includes(letter)) {
      game.wrongGuesses++;
    }
    
    if (game.wrongGuesses >= game.maxWrong) {
      activeGames.delete(gameId);
      
      const loseContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 💀 Game Over!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${hangmanStages[6]}\n\nThe word was: **${game.word.toUpperCase()}**`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# Better luck next time!')
        );
      
      return interaction.update({ components: [loseContainer], flags: MessageFlags.IsComponentsV2 });
    }
    
    const displayWord = getDisplayWord(game.word, game.guessedLetters);
    
    if (!displayWord.includes('_')) {
      activeGames.delete(gameId);
      
      const timeTaken = ((Date.now() - game.startTime) / 1000).toFixed(1);
      
      const winContainer = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 🎉 You Won!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**${interaction.user}** guessed the word!\n\nThe word was: **${game.word.toUpperCase()}**`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(
                `**⏱️ Time:** ${timeTaken}s\n` +
                `**❌ Wrong Guesses:** ${game.wrongGuesses}\n` +
                `**📁 Category:** ${game.category}`
              )
            )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# Great job!')
        );
      
      return interaction.update({ components: [winContainer], flags: MessageFlags.IsComponentsV2 });
    }
    
    const updatedContainer = createGameContainer(game);
    const updatedButtons = createLetterButtons(game.guessedLetters);
    
    await interaction.update({ components: [updatedContainer, ...updatedButtons], flags: MessageFlags.IsComponentsV2 });
  },
};

function getDisplayWord(word, guessedLetters) {
  return word.split('').map(letter => guessedLetters.has(letter) ? letter.toUpperCase() : '_').join(' ');
}

function createGameContainer(game) {
  const displayWord = getDisplayWord(game.word, game.guessedLetters);
  const livesLeft = game.maxWrong - game.wrongGuesses;
  const guessedArray = Array.from(game.guessedLetters).sort();
  
  const color = livesLeft <= 2 ? 0xFF0000 : livesLeft <= 4 ? 0xFFD700 : 0x00FF00;
  
  return new ContainerBuilder()
    .setAccentColor(color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# 🎮 Hangman - ${categoryEmojis[game.category]} ${game.category.charAt(0).toUpperCase() + game.category.slice(1)}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`${hangmanStages[game.wrongGuesses]}\n\n**Word:** \`${displayWord}\``)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**❤️ Lives Left:** ${'❤️'.repeat(livesLeft)}${'🖤'.repeat(game.wrongGuesses)}\n` +
            `**📝 Letters Guessed:** ${guessedArray.length > 0 ? guessedArray.join(', ').toUpperCase() : 'None'}`
          )
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('-# Type a letter or click a button!')
    );
}

function createLetterButtons(guessedLetters) {
  const rows = [];
  const alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('');
  
  for (let i = 0; i < 4; i++) {
    const row = new ActionRowBuilder();
    const startIdx = i * 5;
    const letters = i === 3 ? alphabet.slice(20, 26) : alphabet.slice(startIdx, startIdx + 5);
    
    for (const letter of letters) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`hm_${letter}`)
          .setLabel(letter.toUpperCase())
          .setStyle(guessedLetters.has(letter) ? ButtonStyle.Secondary : ButtonStyle.Primary)
          .setDisabled(guessedLetters.has(letter))
      );
    }
    
    if (i === 3) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId('hm_hint')
          .setLabel('💡')
          .setStyle(ButtonStyle.Success)
      );
    }
    
    rows.push(row);
  }
  
  return rows;
}
