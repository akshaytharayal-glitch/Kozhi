import { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags
} from 'discord.js';

const questions = [
  { optionA: "Have the ability to fly", optionB: "Be invisible" },
  { optionA: "Never use social media again", optionB: "Never watch movies/TV again" },
  { optionA: "Have unlimited money", optionB: "Have unlimited time" },
  { optionA: "Live without music", optionB: "Live without video games" },
  { optionA: "Be able to speak all languages", optionB: "Be able to talk to animals" },
  { optionA: "Live in the past", optionB: "Live in the future" },
  { optionA: "Have super strength", optionB: "Have super speed" },
  { optionA: "Be famous", optionB: "Be the smartest person alive" },
  { optionA: "Never have to sleep", optionB: "Never have to eat" },
  { optionA: "Have a rewind button for your life", optionB: "Have a pause button for your life" },
  { optionA: "Be able to read minds", optionB: "Be able to see the future" },
  { optionA: "Have free Wi-Fi everywhere", optionB: "Have free coffee everywhere" },
  { optionA: "Only eat pizza forever", optionB: "Only eat tacos forever" },
  { optionA: "Be a superhero", optionB: "Be a wizard" },
  { optionA: "Live in a treehouse", optionB: "Live in a submarine" },
  { optionA: "Have a pet dragon", optionB: "Have a pet unicorn" },
  { optionA: "Be extremely lucky", optionB: "Be extremely talented" },
  { optionA: "Never get sick", optionB: "Never feel tired" },
  { optionA: "Have the power of teleportation", optionB: "Have the power of time travel" },
  { optionA: "Be the funniest person alive", optionB: "Be the most attractive person alive" },
  { optionA: "Know when you're going to die", optionB: "Know how you're going to die" },
  { optionA: "Be stranded on a desert island alone", optionB: "Be stranded with someone you hate" },
  { optionA: "Always be 10 minutes late", optionB: "Always be 20 minutes early" },
  { optionA: "Have a personal chef", optionB: "Have a personal driver" },
  { optionA: "Be able to control fire", optionB: "Be able to control water" },
  { optionA: "Live without internet", optionB: "Live without air conditioning/heating" },
  { optionA: "Be a famous singer", optionB: "Be a famous actor" },
  { optionA: "Have a billion dollars", optionB: "Have true love" },
  { optionA: "Always have to say what's on your mind", optionB: "Never speak again" },
  { optionA: "Be immortal", optionB: "Have 9 lives like a cat" },
];

const activePolls = new Map();

function createQuestionContainer(question, isPoll = false) {
  return new ContainerBuilder()
    .setAccentColor(0xFF69B4)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 🤔 Would You Rather...'),
      new TextDisplayBuilder().setContent(isPoll ? '*Vote with the buttons! Poll closes in 60 seconds.*' : '*Make your choice!*')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`🅰️ **Option A**\n${question.optionA}`)
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('wyr_a')
            .setLabel('Option A')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`🅱️ **Option B**\n${question.optionB}`)
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('wyr_b')
            .setLabel('Option B')
            .setStyle(ButtonStyle.Danger)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('**Want a different question?**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('wyr_new')
            .setLabel('New Question')
            .setStyle(ButtonStyle.Secondary)
        )
    );
}

export default {
  data: new SlashCommandBuilder()
    .setName('wouldyourather')
    .setDescription('Would you rather... a fun choice game!')
    .addStringOption(option =>
      option.setName('mode')
        .setDescription('Choose game mode')
        .setRequired(false)
        .addChoices(
          { name: '🎲 Random Question', value: 'random' },
          { name: '📊 Poll Mode (Others can vote)', value: 'poll' }
        )),
  
  aliases: ['wyr', 'rather', 'wouldurather'],
  cooldown: 5,
  
  async execute(interaction) {
    const mode = interaction.options.getString('mode') || 'random';
    const question = questions[Math.floor(Math.random() * questions.length)];
    
    const container = createQuestionContainer(question, mode === 'poll');
    const message = await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, fetchReply: true });
    
    if (mode === 'poll') {
      const pollId = `wyr-${message.id}`;
      activePolls.set(pollId, {
        question,
        votesA: new Set(),
        votesB: new Set(),
        startTime: Date.now()
      });
      
      setTimeout(async () => {
        const poll = activePolls.get(pollId);
        if (!poll) return;
        
        activePolls.delete(pollId);
        
        const totalVotes = poll.votesA.size + poll.votesB.size;
        const percentA = totalVotes > 0 ? Math.round((poll.votesA.size / totalVotes) * 100) : 0;
        const percentB = totalVotes > 0 ? Math.round((poll.votesB.size / totalVotes) * 100) : 0;
        
        const resultsContainer = new ContainerBuilder()
          .setAccentColor(0x00FF00)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🤔 Would You Rather - Results!'),
            new TextDisplayBuilder().setContent(`**Total Votes:** ${totalVotes}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`🅰️ **Option A** (${poll.votesA.size} votes - ${percentA}%)\n${question.optionA}\n${createBar(percentA)}`),
            new TextDisplayBuilder().setContent(`🅱️ **Option B** (${poll.votesB.size} votes - ${percentB}%)\n${question.optionB}\n${createBar(percentB)}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('*Poll closed!*')
          );
        
        await interaction.editReply({ components: [resultsContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
      }, 60000);
    }
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('wyr_')) return;
    
    if (interaction.customId === 'wyr_new') {
      const question = questions[Math.floor(Math.random() * questions.length)];
      const container = createQuestionContainer(question, false);
      return interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
    
    const pollId = `wyr-${interaction.message.id}`;
    const poll = activePolls.get(pollId);
    
    if (poll) {
      const choice = interaction.customId === 'wyr_a' ? 'A' : 'B';
      
      poll.votesA.delete(interaction.user.id);
      poll.votesB.delete(interaction.user.id);
      
      if (choice === 'A') {
        poll.votesA.add(interaction.user.id);
      } else {
        poll.votesB.add(interaction.user.id);
      }
      
      return interaction.reply({ content: `You voted for Option ${choice}!`, ephemeral: true });
    }
    
    const choice = interaction.customId === 'wyr_a' ? 'A' : 'B';
    return interaction.reply({ content: `You chose Option ${choice}!`, ephemeral: true });
  },
};

function createBar(percent) {
  const filled = Math.round(percent / 10);
  const empty = 10 - filled;
  return '🟩'.repeat(filled) + '⬜'.repeat(empty) + ` ${percent}%`;
}
