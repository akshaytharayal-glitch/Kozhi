import { SlashCommandBuilder, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { getBalance, addBalance, removeBalance } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('slots')
    .setDescription('Play the slot machine')
    .addIntegerOption(option =>
      option.setName('bet')
        .setDescription('Amount to bet')
        .setRequired(true)
        .setMinValue(10)),
  
  cooldown: 5,
  
  async execute(interaction) {
    const bet = interaction.options.getInteger('bet');
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    
    const balance = getBalance(guildId, userId);
    
    if (balance < bet) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Insufficient Eggs')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`You don't have enough eggs!\n\n**Your Balance:** ${balance.toLocaleString()} eggs`)
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const symbols = ['', '', '', '', '', '', '', ''];
    const weights = [30, 25, 20, 15, 5, 3, 1, 1];
    
    function getSymbol() {
      const total = weights.reduce((a, b) => a + b, 0);
      let random = Math.random() * total;
      for (let i = 0; i < symbols.length; i++) {
        if (random < weights[i]) return symbols[i];
        random -= weights[i];
      }
      return symbols[0];
    }
    
    const slots = [
      [getSymbol(), getSymbol(), getSymbol()],
      [getSymbol(), getSymbol(), getSymbol()],
      [getSymbol(), getSymbol(), getSymbol()],
    ];
    
    const middleRow = slots[1];
    const display = slots.map(row => row.join(' | ')).join('\n');
    
    let multiplier = 0;
    let winType = '';
    
    if (middleRow[0] === middleRow[1] && middleRow[1] === middleRow[2]) {
      switch (middleRow[0]) {
        case '': multiplier = 10; winType = 'JACKPOT! 777'; break;
        case '': multiplier = 7; winType = 'DIAMOND WIN!'; break;
        case '': multiplier = 5; winType = 'STAR WIN!'; break;
        case '': multiplier = 4; winType = 'BELL WIN!'; break;
        default: multiplier = 3; winType = 'THREE OF A KIND!';
      }
    } else if (middleRow[0] === middleRow[1] || middleRow[1] === middleRow[2]) {
      multiplier = 1.5;
      winType = 'Two matching!';
    }
    
    let title = '# Slot Machine';
    let resultText = '';
    let accentColor = 0x5865F2;
    
    if (multiplier > 0) {
      const winnings = Math.floor(bet * multiplier);
      addBalance(guildId, userId, winnings - bet);
      accentColor = 0x00FF00;
      title = `# ${winType}`;
      resultText = `\`\`\`\n${display}\n\`\`\`\n\n**Multiplier:** ${multiplier}x\n**Winnings:** +${(winnings - bet).toLocaleString()} eggs\n**New Balance:** ${(balance + winnings - bet).toLocaleString()} eggs`;
    } else {
      removeBalance(guildId, userId, bet);
      accentColor = 0xFF0000;
      title = '# No Match!';
      resultText = `\`\`\`\n${display}\n\`\`\`\n\n**Lost:** -${bet.toLocaleString()} eggs\n**New Balance:** ${Math.max(0, balance - bet).toLocaleString()} eggs`;
    }
    
    const container = new ContainerBuilder()
      .setAccentColor(accentColor)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(title)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(resultText)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
