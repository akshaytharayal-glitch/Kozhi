import { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { getCountGame, setCountGame } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('count')
    .setDescription('Manage the counting game')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Set up the counting game in a channel')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('The channel for counting')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('stats')
        .setDescription('View counting game statistics'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('reset')
        .setDescription('Reset the counting game'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  
  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    
    if (subcommand === 'setup') {
      const channel = interaction.options.getChannel('channel');
      
      if (!channel.isTextBased()) {
        const errorContainer = new ContainerBuilder()
          .setAccentColor(0xFF0000)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Error')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('Please select a text channel!')
          );
        return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
      }
      
      const gameData = getCountGame(guildId);
      gameData.channelId = channel.id;
      gameData.currentNumber = 0;
      gameData.lastUserId = null;
      setCountGame(guildId, gameData);
      
      const successContainer = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Counting Game Setup')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Counting game has been set up in ${channel}!`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('Start counting from **1**. You earn eggs for reaching milestones!')
        );
      
      await interaction.reply({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
      
      const rulesContainer = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Counting Game Started!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent("Start from **1**. Rules:\n- Count one number at a time\n- You can't count twice in a row\n- Wrong number resets the count\n- Earn eggs at milestones (every 5 and 10)!")
        );
      
      await channel.send({ components: [rulesContainer], flags: MessageFlags.IsComponentsV2 });
      
    } else if (subcommand === 'stats') {
      const gameData = getCountGame(guildId);
      
      const container = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Counting Game Stats')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Current Count:** ${gameData.currentNumber || 0}`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**High Score:** ${gameData.highScore || 0}`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Channel:** ${gameData.channelId ? `<#${gameData.channelId}>` : 'Not set'}`)
        );
      
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      
    } else if (subcommand === 'reset') {
      const gameData = getCountGame(guildId);
      gameData.currentNumber = 0;
      gameData.lastUserId = null;
      setCountGame(guildId, gameData);
      
      const resetContainer = new ContainerBuilder()
        .setAccentColor(0xFFA500)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Game Reset')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('Counting game has been reset! The count is now **0**.')
        );
      
      await interaction.reply({ components: [resetContainer], flags: MessageFlags.IsComponentsV2 });
    }
  },
};
