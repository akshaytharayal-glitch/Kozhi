import { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags
} from 'discord.js';

const choices = ['rock', 'paper', 'scissors'];
const emojis = { rock: '🪨', paper: '📄', scissors: '✂️' };
const winMessages = [
  "Victory is yours!",
  "You crushed it!",
  "The champion emerges!",
  "Flawless victory!",
  "You're on fire!"
];
const loseMessages = [
  "Better luck next time!",
  "So close!",
  "The bot wins this round!",
  "Keep trying!",
  "Revenge will be sweet!"
];
const tieMessages = [
  "Great minds think alike!",
  "A draw!",
  "Neither wins this time!",
  "Perfectly balanced!",
  "Try again!"
];

function getResult(playerChoice, botChoice) {
  if (playerChoice === botChoice) return 'tie';
  if (
    (playerChoice === 'rock' && botChoice === 'scissors') ||
    (playerChoice === 'paper' && botChoice === 'rock') ||
    (playerChoice === 'scissors' && botChoice === 'paper')
  ) {
    return 'win';
  }
  return 'lose';
}

function createGameContainer() {
  return new ContainerBuilder()
    .setAccentColor(0x5865F2)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 🎮 Rock Paper Scissors'),
      new TextDisplayBuilder().setContent('**Choose your weapon!**')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🪨 **Rock** - Crushes scissors')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('rps_rock')
            .setLabel('Rock')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('📄 **Paper** - Covers rock')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('rps_paper')
            .setLabel('Paper')
            .setStyle(ButtonStyle.Success)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('✂️ **Scissors** - Cuts paper')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('rps_scissors')
            .setLabel('Scissors')
            .setStyle(ButtonStyle.Danger)
        )
    );
}

function createResultContainer(playerChoice, botChoice, result, user) {
  let color, title, message;
  
  if (result === 'win') {
    color = 0x00FF00;
    title = '# 🎉 You Win!';
    message = winMessages[Math.floor(Math.random() * winMessages.length)];
  } else if (result === 'lose') {
    color = 0xFF0000;
    title = '# 😢 You Lose!';
    message = loseMessages[Math.floor(Math.random() * loseMessages.length)];
  } else {
    color = 0xFFD700;
    title = '# 🤝 It\'s a Tie!';
    message = tieMessages[Math.floor(Math.random() * tieMessages.length)];
  }
  
  return new ContainerBuilder()
    .setAccentColor(color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(title),
      new TextDisplayBuilder().setContent(message)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**👤 Your Choice:** ${emojis[playerChoice]} ${playerChoice.charAt(0).toUpperCase() + playerChoice.slice(1)}`),
      new TextDisplayBuilder().setContent(`**🤖 Bot's Choice:** ${emojis[botChoice]} ${botChoice.charAt(0).toUpperCase() + botChoice.slice(1)}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('**Play again?**')
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🪨 **Rock**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('rps_rock')
            .setLabel('Rock')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('📄 **Paper**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('rps_paper')
            .setLabel('Paper')
            .setStyle(ButtonStyle.Success)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('✂️ **Scissors**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('rps_scissors')
            .setLabel('Scissors')
            .setStyle(ButtonStyle.Danger)
        )
    );
}

export default {
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Play Rock Paper Scissors against the bot!')
    .addStringOption(option =>
      option.setName('choice')
        .setDescription('Your choice')
        .setRequired(false)
        .addChoices(
          { name: '🪨 Rock', value: 'rock' },
          { name: '📄 Paper', value: 'paper' },
          { name: '✂️ Scissors', value: 'scissors' }
        )),
  
  aliases: ['rockpaperscissors', 'roshambo'],
  cooldown: 3,
  
  async execute(interaction) {
    const playerChoice = interaction.options.getString('choice');
    
    if (!playerChoice) {
      const container = createGameContainer();
      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
    
    const botChoice = choices[Math.floor(Math.random() * choices.length)];
    const result = getResult(playerChoice, botChoice);
    
    const container = createResultContainer(playerChoice, botChoice, result, interaction.user);
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('rps_')) return;
    
    const playerChoice = interaction.customId.replace('rps_', '');
    const botChoice = choices[Math.floor(Math.random() * choices.length)];
    const result = getResult(playerChoice, botChoice);
    
    const container = createResultContainer(playerChoice, botChoice, result, interaction.user);
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
