import { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags
} from 'discord.js';

const truths = [
  "What's the most embarrassing thing you've ever done in public?",
  "Have you ever lied to your best friend? What about?",
  "What's your biggest fear that you've never told anyone?",
  "Who was your first crush and do they know?",
  "What's the worst date you've ever been on?",
  "Have you ever pretended to like a gift you actually hated?",
  "What's the most childish thing you still do?",
  "What's a secret you've never told your parents?",
  "Have you ever blamed someone else for something you did?",
  "What's the longest you've gone without showering?",
  "What's your most embarrassing nickname?",
  "Have you ever had a crush on a friend's partner?",
  "What's the weirdest dream you've ever had?",
  "What's the most embarrassing song on your playlist?",
  "Have you ever walked into a glass door?",
  "What's the dumbest thing you've ever done for attention?",
  "Have you ever stalked someone on social media?",
  "What's your guilty pleasure TV show or movie?",
  "What's the worst lie you've ever told?",
  "Have you ever pretended to be sick to skip something?",
  "What's the most trouble you've ever been in?",
  "Who in this server would you want to be stuck on an island with?",
  "What's the most useless talent you have?",
  "Have you ever had an imaginary friend?",
  "What's the weirdest food combination you enjoy?",
  "Have you ever laughed so hard you peed a little?",
  "What's your most irrational fear?",
  "Have you ever said 'I love you' without meaning it?",
  "What's the pettiest thing you've ever done?",
  "What's the last thing you searched on Google?",
  "Have you ever cheated at a game?",
  "What's the most awkward thing that's happened to you on a video call?",
  "What's something you've done that you'd judge someone else for?",
  "Have you ever been caught talking to yourself?",
  "What's the worst haircut you've ever had?",
  "Have you ever accidentally sent a message to the wrong person?",
  "What's your most unpopular opinion?",
  "Have you ever pretended to know a song you didn't?",
  "What's the cringiest thing you did as a teenager?",
  "Have you ever cried during a movie? Which one?",
];

const dares = [
  "Change your Discord status to something embarrassing for 1 hour!",
  "Send your last selfie in this chat!",
  "Let someone else write a message from your account!",
  "Voice chat for the next 10 minutes using only a funny accent!",
  "Send a random emoji to the last person who messaged you!",
  "Change your Discord avatar to whatever the group chooses for 24 hours!",
  "Sing a song in voice chat (at least 30 seconds)!",
  "Let the group pick your new nickname for the server!",
  "Send a voice message saying 'I am a beautiful butterfly'!",
  "Type with your eyes closed for the next 3 messages!",
  "Share the last photo in your camera roll!",
  "Post your screen time report!",
  "Do 10 push-ups and send a video/voice message of you doing them!",
  "Text your best friend 'I need to tell you something important' and wait!",
  "Speak only in questions for the next 5 minutes!",
  "Make up a rap about another member in this server!",
  "Send a message using only emojis for the next 3 messages!",
  "Share the last YouTube video you watched!",
  "Do your best impression of another member in voice chat!",
  "Change your username to 'I lost at Truth or Dare' for 1 hour!",
  "Send a compliment to every person in this chat!",
  "Share your most listened to song this week!",
  "Let someone else send a message as you!",
  "Record yourself doing a silly dance and share it!",
  "Speak in third person for the next 10 minutes!",
  "Post a childhood photo of yourself!",
  "Create a short poem about another server member!",
  "Let someone else choose your profile picture for 24 hours!",
  "Send 'I love you' to the 5th person in your DM list!",
  "Share an embarrassing autocorrect fail you've had!",
  "Do 20 jumping jacks and send proof!",
  "Change your nickname to 'Queen/King of Bad Decisions'!",
  "Share your most used emoji!",
  "Send a message backwards (type it in reverse)!",
  "Create a haiku about this Discord server!",
  "Make animal sounds in voice chat for 30 seconds!",
  "Share the last meme you saved!",
  "Let someone else write your bio for 24 hours!",
  "Send a voice message whispering something mysterious!",
  "React to every message in this channel with a clown for 5 minutes!",
];

const spicyTruths = [
  "What's your biggest turn-off in a person?",
  "Have you ever had a dream about someone in this server?",
  "What's the most romantic thing you've ever done?",
  "What's your type? Be specific!",
  "Have you ever ghosted someone? Why?",
  "What's the biggest risk you've taken for love?",
  "Have you ever been jealous of someone in this server?",
  "What's the most attractive quality in a person?",
  "Have you ever been friend-zoned?",
  "What's your ideal first date?",
];

const spicyDares = [
  "Flirt with someone in this chat for 2 minutes!",
  "Send a pickup line to the last person who messaged you!",
  "Rate everyone in this chat from 1-10 (looks)!",
  "Share your celebrity crush and explain why!",
  "Do your best flirty voice in voice chat!",
  "Give someone a cheesy compliment!",
  "Send a romantic song to someone in the server!",
  "Describe your perfect partner in detail!",
  "Send a wink emoji to your crush (if they're here)!",
  "Tell someone they have nice... (something appropriate)!",
];

function createGameContainer() {
  return new ContainerBuilder()
    .setAccentColor(0xFF69B4)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 🎲 Truth or Dare'),
      new TextDisplayBuilder().setContent('**Choose an option below to play!**')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('😇 **Truth** - Answer a question honestly!')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_truth')
            .setLabel('Truth')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('😈 **Dare** - Complete a challenge!')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_dare')
            .setLabel('Dare')
            .setStyle(ButtonStyle.Danger)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🎰 **Random** - Let fate decide!')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_random')
            .setLabel('Random')
            .setStyle(ButtonStyle.Secondary)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🌶️ **Spicy Truth** - More personal questions!')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_spicy_truth')
            .setLabel('Spicy Truth')
            .setStyle(ButtonStyle.Success)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🔥 **Spicy Dare** - Bolder challenges!')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_spicy_dare')
            .setLabel('Spicy Dare')
            .setStyle(ButtonStyle.Success)
        )
    );
}

function createResultContainer(choice, result, targetMention) {
  const isTruth = choice === 'truth' || choice === 'spicy_truth';
  const isSpicy = choice.startsWith('spicy');
  
  const title = isTruth 
    ? (isSpicy ? '# 🌶️ Spicy Truth!' : '# 😇 Truth!')
    : (isSpicy ? '# 🔥 Spicy Dare!' : '# 😈 Dare!');
  
  const color = isTruth 
    ? (isSpicy ? 0xFF4500 : 0x5865F2)
    : (isSpicy ? 0xFF0000 : 0xED4245);
  
  return new ContainerBuilder()
    .setAccentColor(color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(title),
      new TextDisplayBuilder().setContent(`**${targetMention}**\n\n${result}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(isTruth ? '*Answer honestly!*' : '*Complete the dare!*')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('**Play again?**')
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('😇 **Truth**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_truth')
            .setLabel('Truth')
            .setStyle(ButtonStyle.Primary)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('😈 **Dare**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_dare')
            .setLabel('Dare')
            .setStyle(ButtonStyle.Danger)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('🎰 **Random**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('tod_random')
            .setLabel('Random')
            .setStyle(ButtonStyle.Secondary)
        )
    );
}

export default {
  data: new SlashCommandBuilder()
    .setName('truthordare')
    .setDescription('Play Truth or Dare!')
    .addStringOption(option =>
      option.setName('choice')
        .setDescription('Choose Truth or Dare')
        .setRequired(false)
        .addChoices(
          { name: 'Truth', value: 'truth' },
          { name: 'Dare', value: 'dare' },
          { name: 'Random', value: 'random' },
          { name: 'Spicy Truth', value: 'spicy_truth' },
          { name: 'Spicy Dare', value: 'spicy_dare' }
        ))
    .addUserOption(option =>
      option.setName('target')
        .setDescription('Choose someone to answer/do the dare')
        .setRequired(false)),
  
  cooldown: 5,
  
  async execute(interaction) {
    let choice = interaction.options.getString('choice');
    const target = interaction.options.getUser('target');
    
    if (!choice) {
      const container = createGameContainer();
      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
    
    if (choice === 'random') {
      choice = Math.random() < 0.5 ? 'truth' : 'dare';
    }
    
    const targetMention = target ? `<@${target.id}>` : `<@${interaction.user.id}>`;
    const result = getResult(choice);
    
    const container = createResultContainer(choice, result, targetMention);
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
  
  async handleButton(interaction) {
    const customId = interaction.customId;
    
    if (!customId.startsWith('tod_')) return;
    
    let choice = customId.replace('tod_', '');
    
    if (choice === 'random') {
      choice = Math.random() < 0.5 ? 'truth' : 'dare';
    }
    
    const result = getResult(choice);
    const container = createResultContainer(choice, result, `<@${interaction.user.id}>`);
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};

function getResult(choice) {
  switch (choice) {
    case 'truth':
      return truths[Math.floor(Math.random() * truths.length)];
    case 'dare':
      return dares[Math.floor(Math.random() * dares.length)];
    case 'spicy_truth':
      return spicyTruths[Math.floor(Math.random() * spicyTruths.length)];
    case 'spicy_dare':
      return spicyDares[Math.floor(Math.random() * spicyDares.length)];
    default:
      return truths[Math.floor(Math.random() * truths.length)];
  }
}
