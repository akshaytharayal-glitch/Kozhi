import { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ThumbnailBuilder,
  MessageFlags
} from 'discord.js';
import { getBalance, addBalance, removeBalance } from '../../utils/database.js';

const activeGames = new Map();

export default {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Flip a coin and bet your eggs')
    .addIntegerOption(option =>
      option.setName('bet')
        .setDescription('Amount to bet')
        .setRequired(true)
        .setMinValue(10)),
  
  cooldown: 5,
  
  async execute(interaction) {
    const bet = interaction.options.getInteger('bet');
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    
    const balance = getBalance(guildId, userId);
    
    if (balance < bet) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Insufficient Eggs')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`You don't have enough eggs!\n\n**Your Balance:** ${balance.toLocaleString()} eggs`)
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const gameId = `${guildId}_${userId}_${Date.now()}`;
    activeGames.set(gameId, { bet, odUserId: userId, guildId });
    
    const container = new ContainerBuilder()
      .setAccentColor(0xFFD700)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Coin Flip'),
            new TextDisplayBuilder().setContent(`**Bet Amount:** ${bet.toLocaleString()} eggs\n**Your Balance:** ${balance.toLocaleString()} eggs`)
          )
          .setThumbnailAccessory(
            new ThumbnailBuilder({ media: { url: 'https://em-content.zobj.net/source/twitter/376/coin_1fa99.png' } })
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('**Choose your side to flip the coin!**')
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**Heads** - Gold side up')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId(`coinflip_heads_${gameId}`)
              .setLabel('Heads')
              .setStyle(ButtonStyle.Primary)
          )
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**Tails** - Silver side up')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId(`coinflip_tails_${gameId}`)
              .setLabel('Tails')
              .setStyle(ButtonStyle.Secondary)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    
    setTimeout(() => {
      activeGames.delete(gameId);
    }, 60000);
  },
  
  async handleButton(interaction) {
    const customId = interaction.customId;
    if (!customId.startsWith('coinflip_')) return;
    
    const parts = customId.split('_');
    const action = parts[1];
    
    if (action === 'playagain') {
      const bet = parseInt(parts[2]);
      const guildId = parts[3];
      const userId = interaction.user.id;
      const balance = getBalance(guildId, userId);
      
      if (balance < bet) {
        const errorContainer = new ContainerBuilder()
          .setAccentColor(0xFF0000)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Insufficient Eggs')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`You don't have enough eggs!\n\n**Your Balance:** ${balance.toLocaleString()} eggs`)
          );
        return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
      }
      
      const gameId = `${guildId}_${userId}_${Date.now()}`;
      activeGames.set(gameId, { bet, odUserId: userId, guildId });
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFFD700)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('# Coin Flip'),
              new TextDisplayBuilder().setContent(`**Bet Amount:** ${bet.toLocaleString()} eggs\n**Your Balance:** ${balance.toLocaleString()} eggs`)
            )
            .setThumbnailAccessory(
              new ThumbnailBuilder({ media: { url: 'https://em-content.zobj.net/source/twitter/376/coin_1fa99.png' } })
            )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('**Choose your side to flip the coin!**')
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('**Heads** - Gold side up')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId(`coinflip_heads_${gameId}`)
                .setLabel('Heads')
                .setStyle(ButtonStyle.Primary)
            )
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('**Tails** - Silver side up')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId(`coinflip_tails_${gameId}`)
                .setLabel('Tails')
                .setStyle(ButtonStyle.Secondary)
            )
        );
      
      setTimeout(() => {
        activeGames.delete(gameId);
      }, 60000);
      
      return interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
    
    const choice = action;
    const gameId = parts.slice(2).join('_');
    
    const game = activeGames.get(gameId);
    
    if (!game) {
      const expiredContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Game Expired')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('This game has expired! Start a new coinflip with /coinflip')
        );
      return interaction.reply({ components: [expiredContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    if (interaction.user.id !== game.odUserId) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Not Your Game')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('This is not your game!')
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    activeGames.delete(gameId);
    
    const { bet, guildId } = game;
    const userId = interaction.user.id;
    const balance = getBalance(guildId, userId);
    
    if (balance < bet) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Insufficient Eggs')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`You no longer have enough eggs!\n\n**Your Balance:** ${balance.toLocaleString()} eggs`)
        );
      return interaction.update({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
    }
    
    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const won = choice === result;
    
    const resultEmoji = result === 'heads' ? '' : '';
    const newBalance = won ? balance + bet : Math.max(0, balance - bet);
    
    if (won) {
      addBalance(guildId, userId, bet);
    } else {
      removeBalance(guildId, userId, bet);
    }
    
    const resultContainer = new ContainerBuilder()
      .setAccentColor(won ? 0x00FF00 : 0xFF0000)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Coin Flip Result'),
            new TextDisplayBuilder().setContent(`${resultEmoji} **${result.toUpperCase()}** ${resultEmoji}\n\nYou chose: **${choice.toUpperCase()}**`)
          )
          .setThumbnailAccessory(
            new ThumbnailBuilder({ media: { url: 'https://em-content.zobj.net/source/twitter/376/coin_1fa99.png' } })
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(won 
          ? `## You Won!\n**+${bet.toLocaleString()}** eggs\n**New Balance:** ${newBalance.toLocaleString()} eggs`
          : `## You Lost!\n**-${bet.toLocaleString()}** eggs\n**New Balance:** ${newBalance.toLocaleString()} eggs`
        )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**Want to try again?**')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId(`coinflip_playagain_${bet}_${guildId}`)
              .setLabel('Play Again')
              .setStyle(ButtonStyle.Success)
          )
      );
    
    await interaction.update({ components: [resultContainer], flags: MessageFlags.IsComponentsV2 });
  }
};
