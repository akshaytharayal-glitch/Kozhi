import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import axios from 'axios';

const triviaCategories = {
  general: 9,
  books: 10,
  film: 11,
  music: 12,
  theatre: 13,
  television: 14,
  videogames: 15,
  boardgames: 16,
  science: 17,
  computers: 18,
  math: 19,
  mythology: 20,
  sports: 21,
  geography: 22,
  history: 23,
  politics: 24,
  art: 25,
  celebrities: 26,
  animals: 27,
  vehicles: 28,
  comics: 29,
  anime: 31,
  cartoons: 32
};

const categoryEmojis = {
  general: '🎯',
  books: '📚',
  film: '🎬',
  music: '🎵',
  theatre: '🎭',
  television: '📺',
  videogames: '🎮',
  boardgames: '🎲',
  science: '🔬',
  computers: '💻',
  math: '🔢',
  mythology: '⚡',
  sports: '⚽',
  geography: '🌍',
  history: '📜',
  politics: '🏛️',
  art: '🎨',
  celebrities: '⭐',
  animals: '🐾',
  vehicles: '🚗',
  comics: '💥',
  anime: '🎌',
  cartoons: '📺'
};

const fallbackQuestions = [
  {
    question: "What is the capital of France?",
    correct_answer: "Paris",
    incorrect_answers: ["London", "Berlin", "Madrid"],
    category: "Geography",
    difficulty: "easy"
  },
  {
    question: "Which planet is known as the Red Planet?",
    correct_answer: "Mars",
    incorrect_answers: ["Venus", "Jupiter", "Saturn"],
    category: "Science",
    difficulty: "easy"
  },
  {
    question: "Who painted the Mona Lisa?",
    correct_answer: "Leonardo da Vinci",
    incorrect_answers: ["Pablo Picasso", "Vincent van Gogh", "Michelangelo"],
    category: "Art",
    difficulty: "easy"
  },
  {
    question: "What is the largest ocean on Earth?",
    correct_answer: "Pacific Ocean",
    incorrect_answers: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean"],
    category: "Geography",
    difficulty: "easy"
  },
  {
    question: "In what year did World War II end?",
    correct_answer: "1945",
    incorrect_answers: ["1944", "1946", "1943"],
    category: "History",
    difficulty: "medium"
  },
  {
    question: "What is the chemical symbol for gold?",
    correct_answer: "Au",
    incorrect_answers: ["Ag", "Fe", "Cu"],
    category: "Science",
    difficulty: "medium"
  },
  {
    question: "Who wrote 'Romeo and Juliet'?",
    correct_answer: "William Shakespeare",
    incorrect_answers: ["Charles Dickens", "Jane Austen", "Mark Twain"],
    category: "Literature",
    difficulty: "easy"
  },
  {
    question: "What is the speed of light in km/s (approximately)?",
    correct_answer: "300,000",
    incorrect_answers: ["150,000", "500,000", "1,000,000"],
    category: "Science",
    difficulty: "hard"
  }
];

function decodeHTML(html) {
  return html
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&ldquo;/g, '"')
    .replace(/&rdquo;/g, '"')
    .replace(/&lsquo;/g, "'")
    .replace(/&rsquo;/g, "'")
    .replace(/&eacute;/g, 'é')
    .replace(/&ntilde;/g, 'ñ');
}

async function fetchTrivia(category, difficulty) {
  try {
    let url = 'https://opentdb.com/api.php?amount=1&type=multiple';
    if (category && triviaCategories[category]) {
      url += `&category=${triviaCategories[category]}`;
    }
    if (difficulty) {
      url += `&difficulty=${difficulty}`;
    }
    
    const response = await axios.get(url, { timeout: 10000 });
    if (response.data.results && response.data.results.length > 0) {
      return response.data.results[0];
    }
    return null;
  } catch {
    return null;
  }
}

function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

const activeGames = new Map();

export default {
  data: new SlashCommandBuilder()
    .setName('trivia')
    .setDescription('Test your knowledge with trivia questions!')
    .addStringOption(option =>
      option.setName('category')
        .setDescription('Choose a category')
        .setRequired(false)
        .addChoices(
          { name: '🎯 General Knowledge', value: 'general' },
          { name: '🎬 Film', value: 'film' },
          { name: '🎵 Music', value: 'music' },
          { name: '🎮 Video Games', value: 'videogames' },
          { name: '🔬 Science', value: 'science' },
          { name: '💻 Computers', value: 'computers' },
          { name: '🌍 Geography', value: 'geography' },
          { name: '📜 History', value: 'history' },
          { name: '⚽ Sports', value: 'sports' },
          { name: '🐾 Animals', value: 'animals' },
          { name: '🎌 Anime & Manga', value: 'anime' },
          { name: '📚 Books', value: 'books' }
        ))
    .addStringOption(option =>
      option.setName('difficulty')
        .setDescription('Choose difficulty')
        .setRequired(false)
        .addChoices(
          { name: '🟢 Easy', value: 'easy' },
          { name: '🟡 Medium', value: 'medium' },
          { name: '🔴 Hard', value: 'hard' }
        )),
  
  aliases: ['quiz', 'question', 'q'],
  cooldown: 5,
  
  async execute(interaction) {
    await interaction.deferReply();
    
    const category = interaction.options.getString('category');
    const difficulty = interaction.options.getString('difficulty');
    
    let question = await fetchTrivia(category, difficulty);
    
    if (!question) {
      question = fallbackQuestions[Math.floor(Math.random() * fallbackQuestions.length)];
    }
    
    const correctAnswer = decodeHTML(question.correct_answer);
    const allAnswers = shuffleArray([
      correctAnswer,
      ...question.incorrect_answers.map(a => decodeHTML(a))
    ]);
    
    const correctIndex = allAnswers.indexOf(correctAnswer);
    const answerLabels = ['A', 'B', 'C', 'D'];
    
    const difficultyColors = {
      easy: 0x00FF00,
      medium: 0xFFD700,
      hard: 0xFF0000
    };
    
    const difficultyEmojis = {
      easy: '🟢',
      medium: '🟡',
      hard: '🔴'
    };
    
    const container = new ContainerBuilder()
      .setAccentColor(difficultyColors[question.difficulty] || 0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# 🧠 Trivia Time!')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**${decodeHTML(question.question)}**`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**A)** ${allAnswers[0]}\n**B)** ${allAnswers[1]}`
            )
          )
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**C)** ${allAnswers[2]}\n**D)** ${allAnswers[3]}`
            )
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**📁 Category:** ${decodeHTML(question.category)}\n` +
              `**${difficultyEmojis[question.difficulty]} Difficulty:** ${question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1)}`
            )
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('-# You have 30 seconds to answer!')
      );
    
    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('trivia_A')
          .setLabel('A')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('trivia_B')
          .setLabel('B')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('trivia_C')
          .setLabel('C')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('trivia_D')
          .setLabel('D')
          .setStyle(ButtonStyle.Primary)
      );
    
    const message = await interaction.editReply({ components: [container, buttons], flags: MessageFlags.IsComponentsV2 });
    
    const gameId = `${interaction.user.id}-${message.id}`;
    activeGames.set(gameId, {
      correctIndex,
      correctAnswer,
      allAnswers,
      question: question.question,
      answered: false,
      startTime: Date.now()
    });
    
    setTimeout(() => {
      const game = activeGames.get(gameId);
      if (game && !game.answered) {
        activeGames.delete(gameId);
        const timeoutContainer = new ContainerBuilder()
          .setAccentColor(0xFF0000)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent("# ⏰ Time's Up!")
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`The correct answer was: **${answerLabels[correctIndex]}) ${correctAnswer}**`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('-# Try again with /trivia!')
          );
        
        interaction.editReply({ components: [timeoutContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
      }
    }, 30000);
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('trivia_')) return;
    
    const answerLabel = interaction.customId.replace('trivia_', '');
    const answerIndex = ['A', 'B', 'C', 'D'].indexOf(answerLabel);
    
    const gameId = `${interaction.user.id}-${interaction.message.id}`;
    const game = activeGames.get(gameId);
    
    if (!game) {
      try {
        const expiredContainer = new ContainerBuilder()
          .setAccentColor(0x808080)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🧠 Trivia Ended')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('This trivia question has ended or expired.\n\nStart a new one with `/trivia` or `etrivia`!')
          );
        
        await interaction.update({ components: [expiredContainer], flags: MessageFlags.IsComponentsV2 });
      } catch {
        const endedContainer = new ContainerBuilder()
          .setAccentColor(0xFF0000)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Trivia Ended')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('This trivia has ended! Start a new one with `/trivia`')
          );
        await interaction.reply({ components: [endedContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral }).catch(() => {});
      }
      return;
    }
    
    if (game.answered) {
      const answeredContainer = new ContainerBuilder()
        .setAccentColor(0xFFA500)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Already Answered')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('This question has already been answered!')
        );
      return interaction.reply({ components: [answeredContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    game.answered = true;
    activeGames.delete(gameId);
    
    const isCorrect = answerIndex === game.correctIndex;
    const timeTaken = ((Date.now() - game.startTime) / 1000).toFixed(1);
    
    let container;
    if (isCorrect) {
      container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 🎉 Correct!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**${answerLabel}) ${game.correctAnswer}** is the right answer!`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`**⏱️ Time:** ${timeTaken} seconds`)
            )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# Great job!')
        );
    } else {
      container = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# ❌ Wrong!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `You answered: **${answerLabel}) ${game.allAnswers[answerIndex]}**\n\n` +
            `The correct answer was: **${['A', 'B', 'C', 'D'][game.correctIndex]}) ${game.correctAnswer}**`
          )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# Better luck next time!')
        );
    }
    
    const playAgainButton = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('trivia_new')
          .setLabel('Play Again!')
          .setStyle(ButtonStyle.Success)
          .setEmoji('🔄')
      );
    
    await interaction.update({ components: [container, playAgainButton], flags: MessageFlags.IsComponentsV2 });
  },
};
