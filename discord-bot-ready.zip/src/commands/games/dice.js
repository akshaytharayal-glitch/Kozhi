import { SlashCommandBuilder, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { getBalance, addBalance, removeBalance } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Roll dice against the bot')
    .addIntegerOption(option =>
      option.setName('bet')
        .setDescription('Amount to bet')
        .setRequired(true)
        .setMinValue(10)),
  
  cooldown: 5,
  
  async execute(interaction) {
    const bet = interaction.options.getInteger('bet');
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    
    const balance = getBalance(guildId, userId);
    
    if (balance < bet) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Insufficient Eggs')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`You don't have enough eggs!\n\n**Your Balance:** ${balance.toLocaleString()} eggs`)
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const playerRoll = Math.floor(Math.random() * 6) + 1 + Math.floor(Math.random() * 6) + 1;
    const botRoll = Math.floor(Math.random() * 6) + 1 + Math.floor(Math.random() * 6) + 1;
    
    let resultText = '';
    let accentColor = 0x5865F2;
    let title = '# Dice Roll';
    
    if (playerRoll > botRoll) {
      const winnings = Math.floor(bet * 1.5);
      addBalance(guildId, userId, winnings);
      accentColor = 0x00FF00;
      title = '# You Win!';
      resultText = `**Your Roll:** ${playerRoll}\n**Bot Roll:** ${botRoll}\n\n**Winnings:** +${winnings.toLocaleString()} eggs\n**New Balance:** ${(balance + winnings).toLocaleString()} eggs`;
    } else if (playerRoll < botRoll) {
      removeBalance(guildId, userId, bet);
      accentColor = 0xFF0000;
      title = '# You Lose!';
      resultText = `**Your Roll:** ${playerRoll}\n**Bot Roll:** ${botRoll}\n\n**Lost:** -${bet.toLocaleString()} eggs\n**New Balance:** ${Math.max(0, balance - bet).toLocaleString()} eggs`;
    } else {
      accentColor = 0xFFFF00;
      title = "# It's a Tie!";
      resultText = `Your bet is returned.\n\n**Your Roll:** ${playerRoll}\n**Bot Roll:** ${botRoll}\n\n**Result:** No change\n**Balance:** ${balance.toLocaleString()} eggs`;
    }
    
    const container = new ContainerBuilder()
      .setAccentColor(accentColor)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(title)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(resultText)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
