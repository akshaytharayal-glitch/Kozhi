import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { isBotOwner } from '../../utils/permissions.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataPath = join(__dirname, '../../../data/wordfilter.json');

function getFilterData() {
  if (!existsSync(dataPath)) {
    writeFileSync(dataPath, '{}');
    return {};
  }
  try {
    return JSON.parse(readFileSync(dataPath, 'utf8'));
  } catch {
    return {};
  }
}

function saveFilterData(data) {
  writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

export function getBannedWords(guildId) {
  const data = getFilterData();
  return data[guildId]?.words || [];
}

export function addBannedWord(guildId, word) {
  const data = getFilterData();
  if (!data[guildId]) {
    data[guildId] = { words: [], enabled: true };
  }
  const lowerWord = word.toLowerCase();
  if (!data[guildId].words.includes(lowerWord)) {
    data[guildId].words.push(lowerWord);
    saveFilterData(data);
    return true;
  }
  return false;
}

export function removeBannedWord(guildId, word) {
  const data = getFilterData();
  if (!data[guildId]) return false;
  const lowerWord = word.toLowerCase();
  const index = data[guildId].words.indexOf(lowerWord);
  if (index > -1) {
    data[guildId].words.splice(index, 1);
    saveFilterData(data);
    return true;
  }
  return false;
}

export function isFilterEnabled(guildId) {
  const data = getFilterData();
  return data[guildId]?.enabled !== false;
}

export function toggleFilter(guildId, enabled) {
  const data = getFilterData();
  if (!data[guildId]) {
    data[guildId] = { words: [], enabled };
  } else {
    data[guildId].enabled = enabled;
  }
  saveFilterData(data);
}

export default {
  data: new SlashCommandBuilder()
    .setName('wordfilter')
    .setDescription('Manage restricted words in the server')
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add a word/phrase to the filter')
        .addStringOption(opt =>
          opt.setName('word')
            .setDescription('The word or phrase to ban')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a word/phrase from the filter')
        .addStringOption(opt =>
          opt.setName('word')
            .setDescription('The word or phrase to unban')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all banned words'))
    .addSubcommand(sub =>
      sub.setName('enable')
        .setDescription('Enable the word filter'))
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('Disable the word filter'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  aliases: ['filter', 'banword', 'restrictword'],

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const guildId = interaction.guildId;
    
    const isServerOwner = interaction.guild.ownerId === interaction.user.id;
    const isBotOwnerUser = isBotOwner(interaction.user.id);
    
    if (!isServerOwner && !isBotOwnerUser) {
      return interaction.reply({
        content: 'Only the server owner can manage the word filter.',
        flags: 64
      });
    }

    if (subcommand === 'add') {
      const word = interaction.options.getString('word');
      const added = addBannedWord(guildId, word);
      
      if (added) {
        await interaction.reply({
          content: `Added "${word}" to the word filter. Messages containing this will be deleted.`,
          flags: 64
        });
      } else {
        await interaction.reply({
          content: `"${word}" is already in the filter.`,
          flags: 64
        });
      }
    }

    else if (subcommand === 'remove') {
      const word = interaction.options.getString('word');
      const removed = removeBannedWord(guildId, word);
      
      if (removed) {
        await interaction.reply({
          content: `Removed "${word}" from the word filter.`,
          flags: 64
        });
      } else {
        await interaction.reply({
          content: `"${word}" was not in the filter.`,
          flags: 64
        });
      }
    }

    else if (subcommand === 'list') {
      const words = getBannedWords(guildId);
      const enabled = isFilterEnabled(guildId);
      
      if (words.length === 0) {
        await interaction.reply({
          content: `No words are currently filtered.\nFilter status: ${enabled ? 'Enabled' : 'Disabled'}`,
          flags: 64
        });
      } else {
        const wordList = words.map((w, i) => `${i + 1}. ||${w}||`).join('\n');
        await interaction.reply({
          content: `**Filtered Words** (${words.length})\nStatus: ${enabled ? 'Enabled' : 'Disabled'}\n\n${wordList}`,
          flags: 64
        });
      }
    }

    else if (subcommand === 'enable') {
      toggleFilter(guildId, true);
      await interaction.reply({
        content: 'Word filter has been **enabled**. Banned words will now be deleted.',
        flags: 64
      });
    }

    else if (subcommand === 'disable') {
      toggleFilter(guildId, false);
      await interaction.reply({
        content: 'Word filter has been **disabled**.',
        flags: 64
      });
    }
  }
};
