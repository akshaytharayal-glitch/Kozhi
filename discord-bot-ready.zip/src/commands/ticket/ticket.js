import { 
  SlashCommandBuilder, 
  PermissionFlagsBits, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  ChannelType,
  AttachmentBuilder,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ThumbnailBuilder,
  MessageFlags
} from 'discord.js';
import { getTickets, setTickets, addTicket, closeTicket } from '../../utils/database.js';
import { sendTicketVoiceMessage, announceTicketToAdminVC } from '../../utils/ticketTTS.js';

const WELCOME_CHANNELS = {
  channel1: '1445673305590857799',
  channel2: '1445635607249551431',
  channel3: '1445382624163139634'
};

export default {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket system commands')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Set up the ticket system')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('Channel to send the ticket panel')
            .setRequired(true))
        .addChannelOption(option =>
          option.setName('category')
            .setDescription('Category for ticket channels')
            .setRequired(false))
        .addChannelOption(option =>
          option.setName('logs')
            .setDescription('Channel for ticket logs')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('close')
        .setDescription('Close the current ticket'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Add a user to the ticket')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('User to add')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('remove')
        .setDescription('Remove a user from the ticket')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('User to remove')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  
  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    
    if (subcommand === 'setup') {
      const channel = interaction.options.getChannel('channel');
      const category = interaction.options.getChannel('category');
      const logs = interaction.options.getChannel('logs');
      
      const ticketData = getTickets(guildId);
      ticketData.categoryId = category?.id || null;
      ticketData.logChannelId = logs?.id || null;
      setTickets(guildId, ticketData);
      
      const container = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('# 🎫 Need Help?'),
              new TextDisplayBuilder().setContent('Click the button below to create a support ticket.')
            )
            .setThumbnailAccessory(
              new ThumbnailBuilder({ media: { url: interaction.guild.iconURL({ dynamic: true, size: 128 }) || 'https://cdn.discordapp.com/embed/avatars/0.png' } })
            )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('## 📋 What can we help with?'),
          new TextDisplayBuilder().setContent('• General support and questions\n• Technical issues\n• Reporting problems\n• Other assistance needed')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('**Ready to get help?**')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId('ticket_create')
                .setLabel('Create Ticket')
                .setStyle(ButtonStyle.Success)
            )
        );
      
      await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
      await interaction.reply({ content: `✅ Ticket panel has been set up in ${channel}!`, flags: 64 });
      
    } else if (subcommand === 'close') {
      const ticketData = getTickets(guildId);
      const ticket = ticketData.tickets.find(t => t.channelId === interaction.channel.id);
      
      if (!ticket) {
        return interaction.reply({ content: '❌ This is not a ticket channel!', flags: 64 });
      }
      
      await interaction.reply({ content: '🔒 Generating transcript and closing ticket...' });
      
      const htmlBuffer = await generateTicketTranscript(interaction.channel, ticket, interaction.guild);
      const attachment = new AttachmentBuilder(htmlBuffer, { name: `ticket-${ticket.id}-transcript.html` });
      
      closeTicket(guildId, interaction.channel.id);
      
      if (ticketData.logChannelId) {
        const logChannel = interaction.guild.channels.cache.get(ticketData.logChannelId);
        if (logChannel) {
          const logContainer = new ContainerBuilder()
            .setAccentColor(0xFF0000)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('# Ticket Closed')
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`**Ticket:** #${ticket.id}\n**Opened By:** <@${ticket.userId}>\n**Closed By:** ${interaction.user}`)
            );
          
          await logChannel.send({ components: [logContainer], files: [attachment], flags: MessageFlags.IsComponentsV2 });
        }
      }
      
      try {
        const ticketUser = await interaction.client.users.fetch(ticket.userId);
        const dmContainer = new ContainerBuilder()
          .setAccentColor(0x5865F2)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Your Ticket Has Been Closed')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Your ticket **#${ticket.id}** in **${interaction.guild.name}** has been closed.\n\nAttached is a transcript of your conversation.`)
          );
        
        const dmAttachment = new AttachmentBuilder(htmlBuffer, { name: `ticket-${ticket.id}-transcript.html` });
        await ticketUser.send({ components: [dmContainer], files: [dmAttachment], flags: MessageFlags.IsComponentsV2 });
      } catch (error) {
        console.log('Could not DM user:', error.message);
      }
      
      setTimeout(async () => {
        try {
          await interaction.channel.delete();
        } catch (error) {
          console.error('Failed to delete ticket channel:', error);
        }
      }, 5000);
      
    } else if (subcommand === 'add') {
      const user = interaction.options.getUser('user');
      
      const ticketData = getTickets(guildId);
      const ticket = ticketData.tickets.find(t => t.channelId === interaction.channel.id);
      
      if (!ticket) {
        return interaction.reply({ content: '❌ This is not a ticket channel!', flags: 64 });
      }
      
      await interaction.channel.permissionOverwrites.edit(user.id, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true,
      });
      
      await interaction.reply({ content: `✅ Added ${user} to the ticket!` });
      
    } else if (subcommand === 'remove') {
      const user = interaction.options.getUser('user');
      
      const ticketData = getTickets(guildId);
      const ticket = ticketData.tickets.find(t => t.channelId === interaction.channel.id);
      
      if (!ticket) {
        return interaction.reply({ content: '❌ This is not a ticket channel!', flags: 64 });
      }
      
      await interaction.channel.permissionOverwrites.delete(user.id);
      await interaction.reply({ content: `✅ Removed ${user} from the ticket!` });
    }
  },
  
  async handleButton(interaction, client) {
    if (interaction.customId === 'ticket_create') {
      const guildId = interaction.guild.id;
      const ticketData = getTickets(guildId);
      
      const existingTicket = ticketData.tickets.find(
        t => t.userId === interaction.user.id && t.status === 'open'
      );
      
      if (existingTicket) {
        return interaction.reply({ 
          content: `❌ You already have an open ticket: <#${existingTicket.channelId}>`, 
          flags: 64 
        });
      }
      
      const ticketNumber = ticketData.counter + 1;
      
      const channelOptions = {
        name: `ticket-${ticketNumber}`,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'],
          },
          {
            id: client.user.id,
            allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'ManageChannels'],
          },
        ],
      };
      
      if (ticketData.categoryId) {
        channelOptions.parent = ticketData.categoryId;
      }
      
      const ticketChannel = await interaction.guild.channels.create(channelOptions);
      
      const ticket = addTicket(guildId, {
        userId: interaction.user.id,
        channelId: ticketChannel.id,
        status: 'open',
        createdAt: Date.now(),
      });
      
      const adminRole = interaction.guild.roles.cache.find(role => 
        role.name.toLowerCase() === 'admin' || role.name.toLowerCase() === 'administrator'
      );
      const ownerRole = interaction.guild.roles.cache.find(role => 
        role.name.toLowerCase() === 'owner' || role.name.toLowerCase() === 'server owner'
      );

      const roleMentions = [];
      if (adminRole) roleMentions.push(`<@&${adminRole.id}>`);
      if (ownerRole) roleMentions.push(`<@&${ownerRole.id}>`);
      
      const ticketContainer = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`# 🎫 Ticket #${ticket.id}`),
              new TextDisplayBuilder().setContent(`Hello ${interaction.user}! Welcome to **${interaction.guild.name}** Support.\n\nOur ${roleMentions.length > 0 ? roleMentions.join(' and ') : 'staff team'} will be with you shortly.`)
            )
            .setThumbnailAccessory(
              new ThumbnailBuilder({ media: { url: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) } })
            )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('## 📝 Please describe your issue'),
          new TextDisplayBuilder().setContent('• Be patient and respectful\n• Provide as much detail as possible\n• One issue per ticket')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('## 🔗 Useful Channels'),
          new TextDisplayBuilder().setContent(`• <#${WELCOME_CHANNELS.channel1}>\n• <#${WELCOME_CHANNELS.channel2}>\n• <#${WELCOME_CHANNELS.channel3}>`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('**Need to close this ticket?**')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId('ticket_close_confirm')
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
            )
        );
      
      await ticketChannel.send({ components: [ticketContainer], flags: MessageFlags.IsComponentsV2 });
      
      const adminMembers = interaction.guild.members.cache.filter(
        member => member.permissions.has('Administrator') && !member.user.bot
      );
      
      const mentionContent = [];
      if (adminRole) mentionContent.push(`<@&${adminRole.id}>`);
      if (ownerRole) mentionContent.push(`<@&${ownerRole.id}>`);
      if (adminMembers.size > 0) {
        mentionContent.push(...adminMembers.map(admin => `<@${admin.id}>`));
      }
      
      if (mentionContent.length > 0) {
        await ticketChannel.send({
          content: `🔔 **New Ticket Alert!** ${mentionContent.join(' ')}\n\n${interaction.user} has opened a support ticket and needs assistance!`,
        });
      }

      sendTicketVoiceMessage(ticketChannel, interaction.guild, interaction.user)
        .then(success => {
          if (success) {
            console.log(`[Ticket] Voice welcome message sent for ticket #${ticket.id}`);
          }
        })
        .catch(err => console.error('[Ticket] TTS Error:', err));

      announceTicketToAdminVC(interaction.guild, interaction.user, ticket.id, client)
        .then(success => {
          if (success) {
            console.log(`[Ticket] Admin VC announcement sent for ticket #${ticket.id}`);
          } else {
            console.log(`[Ticket] No admin in VC or announcement failed for ticket #${ticket.id}`);
          }
        })
        .catch(err => console.error('[Ticket] VC Announce Error:', err));
      
      await interaction.reply({ content: `✅ Your ticket has been created: ${ticketChannel}`, flags: 64 });
      
      if (ticketData.logChannelId) {
        const logChannel = interaction.guild.channels.cache.get(ticketData.logChannelId);
        if (logChannel) {
          const logContainer = new ContainerBuilder()
            .setAccentColor(0x00FF00)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('# Ticket Created')
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`**Ticket:** #${ticket.id}\n**User:** ${interaction.user}\n**Channel:** ${ticketChannel}`)
            );
          
          await logChannel.send({ components: [logContainer], flags: MessageFlags.IsComponentsV2 });
        }
      }
    } else if (interaction.customId === 'ticket_close_confirm') {
      const guildId = interaction.guild.id;
      const ticketData = getTickets(guildId);
      const ticket = ticketData.tickets.find(t => t.channelId === interaction.channel.id);
      
      if (!ticket) {
        return interaction.reply({ content: '❌ This is not a ticket channel!', flags: 64 });
      }
      
      await interaction.reply({ content: '🔒 Generating transcript and closing ticket...' });
      
      const htmlBuffer = await generateTicketTranscript(interaction.channel, ticket, interaction.guild);
      const attachment = new AttachmentBuilder(htmlBuffer, { name: `ticket-${ticket.id}-transcript.html` });
      
      closeTicket(guildId, interaction.channel.id);
      
      if (ticketData.logChannelId) {
        const logChannel = interaction.guild.channels.cache.get(ticketData.logChannelId);
        if (logChannel) {
          const logContainer = new ContainerBuilder()
            .setAccentColor(0xFF0000)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('# Ticket Closed')
            )
            .addSeparatorComponents(
              new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`**Ticket:** #${ticket.id}\n**Opened By:** <@${ticket.userId}>\n**Closed By:** ${interaction.user}`)
            );
          
          await logChannel.send({ components: [logContainer], files: [attachment], flags: MessageFlags.IsComponentsV2 });
        }
      }
      
      try {
        const ticketUser = await interaction.client.users.fetch(ticket.userId);
        const dmContainer = new ContainerBuilder()
          .setAccentColor(0x5865F2)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Your Ticket Has Been Closed')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Your ticket **#${ticket.id}** in **${interaction.guild.name}** has been closed.\n\nAttached is a transcript of your conversation.`)
          );
        
        const dmAttachment = new AttachmentBuilder(htmlBuffer, { name: `ticket-${ticket.id}-transcript.html` });
        await ticketUser.send({ components: [dmContainer], files: [dmAttachment], flags: MessageFlags.IsComponentsV2 });
      } catch (error) {
        console.log('Could not DM user:', error.message);
      }
      
      setTimeout(async () => {
        try {
          await interaction.channel.delete();
        } catch (error) {
          console.error('Failed to delete ticket channel:', error);
        }
      }, 5000);
    }
  },
};

async function generateTicketTranscript(channel, ticket, guild) {
  const messages = await channel.messages.fetch({ limit: 100 });
  const sortedMessages = [...messages.values()].reverse();
  
  const escapeHtml = (text) => {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  };
  
  const formatMentions = (text) => {
    return text.replace(/<@(\d+)>/g, '<span class="mention">@user</span>');
  };
  
  let messagesHtml = '';
  
  for (const msg of sortedMessages) {
    const timestamp = new Date(msg.createdTimestamp).toLocaleString();
    const isBot = msg.author.bot;
    const avatarUrl = msg.author.displayAvatarURL({ size: 64 });
    
    let contentHtml = '';
    
    if (msg.embeds.length > 0) {
      for (const embed of msg.embeds) {
        contentHtml += '<div class="embed">';
        if (embed.title) contentHtml += `<div class="embed-title">${escapeHtml(embed.title)}</div>`;
        if (embed.description) contentHtml += `<div class="embed-description">${formatMentions(escapeHtml(embed.description))}</div>`;
        if (embed.fields && embed.fields.length > 0) {
          contentHtml += '<div class="embed-fields">';
          for (const field of embed.fields) {
            contentHtml += `<div class="embed-field"><strong>${escapeHtml(field.name)}:</strong> ${escapeHtml(field.value)}</div>`;
          }
          contentHtml += '</div>';
        }
        contentHtml += '</div>';
      }
    }
    
    if (msg.content) {
      contentHtml += `<div class="message-text">${formatMentions(escapeHtml(msg.content))}</div>`;
    }
    
    if (msg.attachments.size > 0) {
      contentHtml += `<div class="attachments">📎 ${msg.attachments.size} attachment(s)</div>`;
    }
    
    if (contentHtml) {
      messagesHtml += `
        <div class="message ${isBot ? 'ai-message' : 'user-message'}">
          <div class="avatar">
            <img src="${avatarUrl}" alt="avatar" />
            ${isBot ? '<div class="ai-indicator"></div>' : ''}
          </div>
          <div class="message-content">
            <div class="message-header">
              <span class="username ${isBot ? 'ai-username' : ''}">${escapeHtml(msg.author.username)}${isBot ? ' <span class="ai-tag">AI</span>' : ''}</span>
              <span class="timestamp">${timestamp}</span>
            </div>
            ${contentHtml}
          </div>
        </div>
      `;
    }
  }
  
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Support Transcript #${ticket.id}</title>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-primary: #0a0a0f;
      --bg-secondary: #12121a;
      --bg-tertiary: #1a1a28;
      --bg-card: rgba(26, 26, 40, 0.8);
      --accent-primary: #00ff88;
      --accent-secondary: #00ccff;
      --accent-tertiary: #8b5cf6;
      --accent-glow: rgba(0, 255, 136, 0.3);
      --text-primary: #e0e0e0;
      --text-secondary: #a0a0a0;
      --text-muted: #666;
      --border-color: rgba(0, 255, 136, 0.2);
      --gradient-1: linear-gradient(135deg, #00ff88 0%, #00ccff 50%, #8b5cf6 100%);
      --gradient-2: linear-gradient(180deg, rgba(0, 255, 136, 0.1) 0%, transparent 100%);
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      background: var(--bg-primary);
      color: var(--text-primary);
      min-height: 100vh;
      padding: 20px;
      background-image: 
        radial-gradient(ellipse at top, rgba(0, 255, 136, 0.05) 0%, transparent 50%),
        radial-gradient(ellipse at bottom right, rgba(0, 204, 255, 0.05) 0%, transparent 50%),
        radial-gradient(ellipse at bottom left, rgba(139, 92, 246, 0.05) 0%, transparent 50%);
    }
    
    .container {
      max-width: 1000px;
      margin: 0 auto;
      background: var(--bg-card);
      border-radius: 24px;
      box-shadow: 
        0 0 60px rgba(0, 255, 136, 0.1),
        0 25px 50px -12px rgba(0, 0, 0, 0.5),
        inset 0 1px 0 rgba(255, 255, 255, 0.05);
      overflow: hidden;
      border: 1px solid var(--border-color);
      backdrop-filter: blur(20px);
    }
    
    .header {
      background: var(--bg-secondary);
      padding: 40px;
      text-align: center;
      position: relative;
      overflow: hidden;
      border-bottom: 1px solid var(--border-color);
    }
    
    .header::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: var(--gradient-1);
    }
    
    .header::after {
      content: '';
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 200px;
      height: 100px;
      background: radial-gradient(ellipse, rgba(0, 255, 136, 0.15) 0%, transparent 70%);
    }
    
    .ai-logo {
      width: 80px;
      height: 80px;
      margin: 0 auto 20px;
      background: var(--gradient-1);
      border-radius: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
      box-shadow: 0 0 40px var(--accent-glow);
      position: relative;
      animation: pulse 3s ease-in-out infinite;
    }
    
    @keyframes pulse {
      0%, 100% { box-shadow: 0 0 40px var(--accent-glow); }
      50% { box-shadow: 0 0 60px var(--accent-glow), 0 0 80px rgba(0, 204, 255, 0.2); }
    }
    
    .header h1 {
      font-family: 'JetBrains Mono', monospace;
      font-size: 28px;
      font-weight: 600;
      background: var(--gradient-1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 8px;
      letter-spacing: -0.5px;
    }
    
    .header .subtitle {
      font-family: 'JetBrains Mono', monospace;
      color: var(--text-secondary);
      font-size: 14px;
      letter-spacing: 2px;
      text-transform: uppercase;
    }
    
    .info-bar {
      background: var(--bg-tertiary);
      padding: 24px 40px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 20px;
      border-bottom: 1px solid var(--border-color);
    }
    
    .info-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 16px;
      background: rgba(0, 255, 136, 0.05);
      border-radius: 12px;
      border: 1px solid rgba(0, 255, 136, 0.1);
      transition: all 0.3s ease;
    }
    
    .info-item:hover {
      background: rgba(0, 255, 136, 0.1);
      border-color: rgba(0, 255, 136, 0.3);
    }
    
    .info-item .icon {
      width: 40px;
      height: 40px;
      background: var(--gradient-1);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
    }
    
    .info-item .label {
      font-family: 'JetBrains Mono', monospace;
      color: var(--accent-primary);
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      margin-bottom: 2px;
    }
    
    .info-item .value {
      color: var(--text-primary);
      font-weight: 600;
      font-size: 13px;
    }
    
    .messages {
      padding: 30px 40px;
      background: var(--gradient-2);
    }
    
    .message {
      display: flex;
      gap: 16px;
      padding: 20px;
      margin-bottom: 12px;
      border-radius: 16px;
      transition: all 0.3s ease;
      position: relative;
      border: 1px solid transparent;
    }
    
    .message:hover {
      background: rgba(255, 255, 255, 0.02);
      border-color: var(--border-color);
    }
    
    .ai-message {
      background: rgba(0, 255, 136, 0.03);
      border-left: 3px solid var(--accent-primary);
      border-radius: 0 16px 16px 0;
    }
    
    .ai-message::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 100px;
      background: linear-gradient(90deg, rgba(0, 255, 136, 0.05) 0%, transparent 100%);
      pointer-events: none;
    }
    
    .user-message {
      background: rgba(139, 92, 246, 0.03);
      border-left: 3px solid var(--accent-tertiary);
      border-radius: 0 16px 16px 0;
    }
    
    .avatar {
      position: relative;
      flex-shrink: 0;
    }
    
    .avatar img {
      width: 48px;
      height: 48px;
      border-radius: 14px;
      border: 2px solid var(--border-color);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }
    
    .ai-indicator {
      position: absolute;
      bottom: -4px;
      right: -4px;
      width: 18px;
      height: 18px;
      background: var(--accent-primary);
      border-radius: 50%;
      border: 2px solid var(--bg-tertiary);
      box-shadow: 0 0 10px var(--accent-primary);
    }
    
    .ai-indicator::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 6px;
      height: 6px;
      background: var(--bg-primary);
      border-radius: 50%;
    }
    
    .message-content {
      flex: 1;
      min-width: 0;
    }
    
    .message-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 8px;
      flex-wrap: wrap;
    }
    
    .username {
      font-weight: 600;
      color: var(--text-primary);
      font-size: 15px;
    }
    
    .ai-username {
      background: var(--gradient-1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    .ai-tag {
      background: var(--gradient-1);
      color: var(--bg-primary);
      font-size: 9px;
      padding: 3px 8px;
      border-radius: 6px;
      font-weight: 700;
      letter-spacing: 1px;
      text-transform: uppercase;
      box-shadow: 0 0 15px var(--accent-glow);
    }
    
    .timestamp {
      font-family: 'JetBrains Mono', monospace;
      color: var(--text-muted);
      font-size: 11px;
      letter-spacing: 0.5px;
    }
    
    .message-text {
      color: var(--text-primary);
      line-height: 1.7;
      word-wrap: break-word;
      font-size: 14px;
    }
    
    .mention {
      background: rgba(0, 204, 255, 0.2);
      color: var(--accent-secondary);
      padding: 2px 8px;
      border-radius: 6px;
      font-weight: 500;
      font-size: 13px;
    }
    
    .embed {
      background: var(--bg-tertiary);
      border-left: 4px solid var(--accent-secondary);
      padding: 16px;
      margin: 12px 0;
      border-radius: 0 12px 12px 0;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
    }
    
    .embed-title {
      color: var(--accent-secondary);
      font-weight: 600;
      margin-bottom: 10px;
      font-size: 15px;
    }
    
    .embed-description {
      color: var(--text-secondary);
      font-size: 13px;
      line-height: 1.6;
    }
    
    .embed-fields {
      margin-top: 12px;
      display: grid;
      gap: 8px;
    }
    
    .embed-field {
      font-size: 13px;
      padding: 8px 12px;
      background: rgba(0, 0, 0, 0.2);
      border-radius: 8px;
    }
    
    .attachments {
      color: var(--accent-secondary);
      font-size: 13px;
      margin-top: 10px;
      padding: 8px 12px;
      background: rgba(0, 204, 255, 0.1);
      border-radius: 8px;
      display: inline-block;
    }
    
    .divider {
      height: 1px;
      background: linear-gradient(90deg, transparent, var(--accent-primary), transparent);
      margin: 30px 0;
      opacity: 0.3;
    }
    
    .footer {
      background: var(--bg-secondary);
      padding: 30px 40px;
      text-align: center;
      border-top: 1px solid var(--border-color);
      position: relative;
    }
    
    .footer::before {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: var(--gradient-1);
    }
    
    .footer-logo {
      width: 40px;
      height: 40px;
      margin: 0 auto 15px;
      background: var(--gradient-1);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
    }
    
    .footer p {
      font-family: 'JetBrains Mono', monospace;
      color: var(--text-muted);
      font-size: 12px;
      letter-spacing: 1px;
    }
    
    .footer .powered-by {
      margin-top: 10px;
      color: var(--text-secondary);
      font-size: 11px;
    }
    
    .footer .powered-by span {
      background: var(--gradient-1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      font-weight: 600;
    }
    
    @media (max-width: 768px) {
      body {
        padding: 10px;
      }
      
      .container {
        border-radius: 16px;
      }
      
      .header {
        padding: 30px 20px;
      }
      
      .info-bar {
        padding: 20px;
        grid-template-columns: 1fr;
      }
      
      .messages {
        padding: 20px;
      }
      
      .message {
        padding: 15px;
        gap: 12px;
      }
      
      .avatar img {
        width: 40px;
        height: 40px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="ai-logo">🤖</div>
      <h1>AI Support Transcript</h1>
      <p class="subtitle">Session #${ticket.id}</p>
    </div>
    
    <div class="info-bar">
      <div class="info-item">
        <span class="icon">🏠</span>
        <div>
          <div class="label">Server</div>
          <div class="value">${escapeHtml(guild.name)}</div>
        </div>
      </div>
      <div class="info-item">
        <span class="icon">💬</span>
        <div>
          <div class="label">Channel</div>
          <div class="value">#${escapeHtml(channel.name)}</div>
        </div>
      </div>
      <div class="info-item">
        <span class="icon">🚀</span>
        <div>
          <div class="label">Session Start</div>
          <div class="value">${new Date(ticket.createdAt).toLocaleString()}</div>
        </div>
      </div>
      <div class="info-item">
        <span class="icon">✅</span>
        <div>
          <div class="label">Session End</div>
          <div class="value">${new Date().toLocaleString()}</div>
        </div>
      </div>
    </div>
    
    <div class="messages">
      <div class="divider"></div>
      ${messagesHtml}
      <div class="divider"></div>
    </div>
    
    <div class="footer">
      <div class="footer-logo">⚡</div>
      <p>--- END OF TRANSCRIPT ---</p>
      <p class="powered-by">Powered by <span>AI Support System</span></p>
    </div>
  </div>
</body>
</html>`;
  
  return Buffer.from(html, 'utf-8');
}
