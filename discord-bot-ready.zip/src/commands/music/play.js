import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play music from YouTube, Spotify, SoundCloud, or search by name')
    .addStringOption(option =>
      option.setName('query')
        .setDescription('Song name, YouTube URL, Spotify URL, or SoundCloud URL')
        .setRequired(true)),
  
  async execute(interaction, client) {
    const query = interaction.options.getString('query');
    const member = interaction.member;
    
    if (!member.voice.channel) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('You need to be in a voice channel to play music!')
            )
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const botPermissions = member.voice.channel.permissionsFor(interaction.guild.members.me);
    if (!botPermissions.has('Connect') || !botPermissions.has('Speak')) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('I need permissions to **Connect** and **Speak** in your voice channel!')
            )
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const kazagumo = client.kazagumo;
    
    const loadingContainer = new ContainerBuilder()
      .setAccentColor(0x3498DB)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Searching')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Searching for **${query}**...`)
          )
      );
    
    await interaction.reply({ components: [loadingContainer], flags: MessageFlags.IsComponentsV2 });
    
    try {
      let player = kazagumo.players.get(interaction.guildId);
      
      if (!player) {
        player = await kazagumo.createPlayer({
          guildId: interaction.guildId,
          textId: interaction.channelId,
          voiceId: member.voice.channel.id,
          deaf: true,
          volume: 80,
        });
      }
      
      const result = await kazagumo.search(query, { requester: interaction.user });
      
      if (!result.tracks.length) {
        const notFoundContainer = new ContainerBuilder()
          .setAccentColor(0xFFA500)
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('## No Results')
              )
          )
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`No results found for: **${query}**`)
              )
          );
        return interaction.editReply({ components: [notFoundContainer], flags: MessageFlags.IsComponentsV2 });
      }
      
      if (result.type === 'PLAYLIST') {
        for (const track of result.tracks) {
          player.queue.add(track);
        }
        
        const container = new ContainerBuilder()
          .setAccentColor(0x00FF00)
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('## Playlist Added')
              )
          )
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**${result.playlistName || 'Playlist'}**\n\n**Tracks:** ${result.tracks.length}\n**Requested By:** ${interaction.user}`)
              )
          );
        
        if (!player.playing && !player.paused) {
          player.play();
        }
        
        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      } else {
        const track = result.tracks[0];
        player.queue.add(track);
        
        if (!player.playing && !player.paused) {
          player.play();
          
          const container = new ContainerBuilder()
            .setAccentColor(0x5865F2)
            .addSectionComponents(
              new SectionBuilder()
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent('## Now Playing')
                )
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
            .addSectionComponents(
              new SectionBuilder()
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent(`**[${track.title}](${track.uri})**\n\n**Author:** ${track.author || 'Unknown'}\n**Duration:** ${formatDuration(track.length)}\n**Requested By:** ${interaction.user}`)
                )
            );
          
          return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else {
          const container = new ContainerBuilder()
            .setAccentColor(0x00FF00)
            .addSectionComponents(
              new SectionBuilder()
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent('## Added to Queue')
                )
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
            .addSectionComponents(
              new SectionBuilder()
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent(`**[${track.title}](${track.uri})**\n\n**Author:** ${track.author || 'Unknown'}\n**Duration:** ${formatDuration(track.length)}\n**Position:** #${player.queue.size}`)
                )
            );
          
          return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
      }
    } catch (error) {
      console.error('[Play] Error:', error);
      
      let errorMessage = 'An error occurred while trying to play music.';
      
      if (error.message?.includes('No available nodes')) {
        errorMessage = 'Music servers are currently unavailable. Please try again later.';
      } else if (error.message?.includes('Unable to find')) {
        errorMessage = `Could not find any tracks for: **${query}**`;
      }
      
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(errorMessage)
            )
        );
      
      return interaction.editReply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
    }
  },
};

function formatDuration(ms) {
  if (!ms || ms === 0) return 'Live';
  
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor(ms / (1000 * 60 * 60));
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
