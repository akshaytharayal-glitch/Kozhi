import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { checkVoiceChannel } from '../../utils/voiceCheck.js';

export default {
  data: new SlashCommandBuilder()
    .setName('shuffle')
    .setDescription('Shuffle the queue'),
  
  async execute(interaction, client) {
    const kazagumo = client.kazagumo;
    const player = kazagumo.players.get(interaction.guildId);
    
    const voiceCheck = checkVoiceChannel(interaction, player);
    if (!voiceCheck.valid) {
      return interaction.reply({ components: [voiceCheck.container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    if (player.queue.length < 2) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('Not enough songs in the queue to shuffle!')
            )
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    player.queue.shuffle();
    
    const successContainer = new ContainerBuilder()
      .setAccentColor(0x00FF00)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Shuffled')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Shuffled **${player.queue.length}** songs in the queue!`)
          )
      );
    
    await interaction.reply({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
  },
};
