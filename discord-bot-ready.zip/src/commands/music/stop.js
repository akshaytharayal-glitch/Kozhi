import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { checkVoiceChannel } from '../../utils/voiceCheck.js';

export default {
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Stop the music and clear the queue'),
  
  async execute(interaction, client) {
    const kazagumo = client.kazagumo;
    const player = kazagumo.players.get(interaction.guildId);
    
    const voiceCheck = checkVoiceChannel(interaction, player);
    if (!voiceCheck.valid) {
      return interaction.reply({ components: [voiceCheck.container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    player.destroy();
    
    const successContainer = new ContainerBuilder()
      .setAccentColor(0xFF0000)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Stopped')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('Stopped the music and cleared the queue!')
          )
      );
    
    await interaction.reply({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
  },
};
