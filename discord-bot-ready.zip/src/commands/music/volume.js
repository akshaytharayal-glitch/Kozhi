import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { checkVoiceChannel } from '../../utils/voiceCheck.js';

export default {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set the music volume')
    .addIntegerOption(option =>
      option.setName('level')
        .setDescription('Volume level (0-100)')
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(100)),
  
  async execute(interaction, client) {
    const kazagumo = client.kazagumo;
    const player = kazagumo.players.get(interaction.guildId);
    const volume = interaction.options.getInteger('level');
    
    const voiceCheck = checkVoiceChannel(interaction, player);
    if (!voiceCheck.valid) {
      return interaction.reply({ components: [voiceCheck.container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    if (!player.queue.current) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('No music is currently playing!')
            )
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    player.setVolume(volume);
    
    let emoji = '🔊';
    if (volume === 0) emoji = '🔇';
    else if (volume < 30) emoji = '🔈';
    else if (volume < 70) emoji = '🔉';
    
    const successContainer = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${emoji} Volume`)
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Volume set to **${volume}%**`)
          )
      );
    
    await interaction.reply({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
  },
};
