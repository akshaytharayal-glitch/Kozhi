import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';
import { checkVoiceChannel } from '../../utils/voiceCheck.js';

export default {
  data: new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Resume the paused song'),
  
  async execute(interaction, client) {
    const kazagumo = client.kazagumo;
    const player = kazagumo.players.get(interaction.guildId);
    
    const voiceCheck = checkVoiceChannel(interaction, player);
    if (!voiceCheck.valid) {
      return interaction.reply({ components: [voiceCheck.container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    if (!player.queue.current) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('No music is currently playing!')
            )
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    if (!player.paused) {
      const warningContainer = new ContainerBuilder()
        .setAccentColor(0xFFA500)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Not Paused')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('The music is not paused!')
            )
        );
      return interaction.reply({ components: [warningContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    player.pause(false);
    
    const successContainer = new ContainerBuilder()
      .setAccentColor(0x00FF00)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Resumed')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Resumed **${player.queue.current.title}**`)
          )
      );
    
    await interaction.reply({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
  },
};
