import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('View the music queue')
    .addIntegerOption(option =>
      option.setName('page')
        .setDescription('Page number')
        .setMinValue(1)
        .setRequired(false)),
  
  async execute(interaction, client) {
    const kazagumo = client.kazagumo;
    const player = kazagumo.players.get(interaction.guildId);
    
    if (!player || !player.queue.current) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('No music is currently playing!')
            )
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const tracks = player.queue;
    const currentTrack = player.queue.current;
    
    const pageSize = 10;
    const totalPages = Math.ceil(tracks.length / pageSize) || 1;
    const page = Math.min(interaction.options.getInteger('page') || 1, totalPages);
    
    const start = (page - 1) * pageSize;
    const end = start + pageSize;
    const currentTracks = [...tracks].slice(start, end);
    
    let queueContent = `**Now Playing:**\n[${currentTrack.title}](${currentTrack.uri}) - ${formatDuration(currentTrack.length)}\nRequested by: ${currentTrack.requester}\n`;
    
    if (currentTracks.length > 0) {
      queueContent += `\n**Up Next:**\n`;
      queueContent += currentTracks
        .map((track, i) => `**${start + i + 1}.** [${track.title}](${track.uri}) - ${formatDuration(track.length)}`)
        .join('\n');
    } else if (tracks.length === 0) {
      queueContent += `\n**Up Next:** No more songs in queue`;
    }
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Music Queue')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(queueContent)
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Page ${page}/${totalPages} | ${tracks.length} songs in queue`)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};

function formatDuration(ms) {
  if (!ms || ms === 0) return 'Live';
  
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor(ms / (1000 * 60 * 60));
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
