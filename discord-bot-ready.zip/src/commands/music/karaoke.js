import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ThumbnailBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import axios from 'axios';

const activeKaraokeSessions = new Map();

export default {
  data: new SlashCommandBuilder()
    .setName('karaoke')
    .setDescription('Play a song and display lyrics for karaoke!')
    .addStringOption(option =>
      option.setName('query')
        .setDescription('Song name, YouTube URL, or Artist - Song Title')
        .setRequired(true)),
  
  aliases: ['sing', 'lyrics'],
  cooldown: 10,
  
  async execute(interaction, client) {
    const query = interaction.options.getString('query');
    const member = interaction.member;
    
    if (!member.voice.channel) {
      return interaction.reply({ content: '🎤 You need to be in a voice channel to start karaoke!', ephemeral: true });
    }
    
    const botPermissions = member.voice.channel.permissionsFor(interaction.guild.members.me);
    if (!botPermissions.has('Connect') || !botPermissions.has('Speak')) {
      return interaction.reply({ 
        content: '❌ I need permissions to **Connect** and **Speak** in your voice channel!', 
        ephemeral: true 
      });
    }
    
    await interaction.deferReply();
    
    const kazagumo = client.kazagumo;
    
    try {
      let player = kazagumo.players.get(interaction.guildId);
      
      if (!player) {
        player = await kazagumo.createPlayer({
          guildId: interaction.guildId,
          textId: interaction.channelId,
          voiceId: member.voice.channel.id,
          deaf: true,
          volume: 80,
        });
      }
      
      const result = await kazagumo.search(query, { requester: interaction.user });
      
      if (!result.tracks.length) {
        return interaction.editReply({ content: `❌ No results found for: **${query}**` });
      }
      
      const track = result.tracks[0];
      
      await interaction.editReply({ 
        content: `🔍 Searching lyrics for **${track.title}** by **${track.author}**...`
      });
      
      const lyricsData = await fetchLyricsMultiSource(track.title, track.author, query);
      
      player.queue.add(track);
      
      if (!player.playing && !player.paused) {
        player.play();
      }
      
      if (!lyricsData || !lyricsData.lyrics) {
        const nowPlayingContainer = createNowPlayingContainer(track, interaction.user);
        return interaction.editReply({ 
          content: `🎵 Now playing **${track.title}** but couldn't find lyrics.\n\n💡 Try searching with format: \`Artist - Song Name\``,
          components: [nowPlayingContainer],
          flags: MessageFlags.IsComponentsV2
        });
      }
      
      const sessionId = `karaoke-${interaction.guildId}`;
      
      if (activeKaraokeSessions.has(sessionId)) {
        const oldSession = activeKaraokeSessions.get(sessionId);
        if (oldSession.autoScrollInterval) {
          clearInterval(oldSession.autoScrollInterval);
        }
        if (oldSession.lyricsInterval) {
          clearInterval(oldSession.lyricsInterval);
        }
      }
      
      const lyricsLines = lyricsData.lines || lyricsData.lyrics.split('\n').filter(line => line.trim() !== '');
      const hasSyncedLyrics = lyricsData.synced && lyricsData.lines;
      
      activeKaraokeSessions.set(sessionId, {
        lines: lyricsLines,
        currentLine: 0,
        trackTitle: track.title,
        trackAuthor: track.author,
        trackLength: track.length,
        userId: interaction.user.id,
        channelId: interaction.channelId,
        paused: false,
        startTime: Date.now(),
        synced: hasSyncedLyrics,
        lyricsSource: lyricsData.source
      });
      
      const karaokeContainer = createKaraokeContainer(lyricsLines, 0, track, interaction.user, lyricsData.source, hasSyncedLyrics);
      
      const buttons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('karaoke_prev')
            .setLabel('Previous')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('⏮️'),
          new ButtonBuilder()
            .setCustomId('karaoke_next')
            .setLabel('Next Line')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('⏭️'),
          new ButtonBuilder()
            .setCustomId('karaoke_auto')
            .setLabel(hasSyncedLyrics ? 'Synced Play' : 'Auto Scroll')
            .setStyle(ButtonStyle.Success)
            .setEmoji('▶️'),
          new ButtonBuilder()
            .setCustomId('karaoke_post')
            .setLabel('Post Lyrics')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('📝'),
          new ButtonBuilder()
            .setCustomId('karaoke_stop')
            .setLabel('Stop')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('⏹️')
        );
      
      const message = await interaction.editReply({ 
        content: hasSyncedLyrics ? '🎤 **Synced Lyrics Found!** Click "Synced Play" for real-time lyrics!' : '🎤 **Lyrics Found!** Navigate with buttons or use Auto Scroll.',
        components: [karaokeContainer, buttons],
        flags: MessageFlags.IsComponentsV2
      });
      
      const session = activeKaraokeSessions.get(sessionId);
      session.messageId = message.id;
      session.interaction = interaction;
      
    } catch (error) {
      console.error('[Karaoke] Error:', error);
      
      let errorMessage = '❌ An error occurred while starting karaoke.';
      
      if (error.message?.includes('No available nodes')) {
        errorMessage = '❌ Music servers are currently unavailable. Please try again later.';
      } else if (error.message?.includes('Unable to find')) {
        errorMessage = `❌ Could not find any tracks for: **${query}**`;
      }
      
      return interaction.editReply({ content: errorMessage });
    }
  },
  
  async handleButton(interaction, client) {
    if (!interaction.customId.startsWith('karaoke_')) return;
    
    const sessionId = `karaoke-${interaction.guildId}`;
    const session = activeKaraokeSessions.get(sessionId);
    
    if (!session) {
      return interaction.reply({ content: '❌ No active karaoke session! Start one with `/karaoke`', ephemeral: true });
    }
    
    const action = interaction.customId.replace('karaoke_', '');
    
    try {
      if (action === 'next') {
        if (session.currentLine < session.lines.length - 1) {
          session.currentLine++;
        }
        const container = createKaraokeContainer(session.lines, session.currentLine, {
          title: session.trackTitle,
          author: session.trackAuthor
        }, interaction.user, session.lyricsSource, session.synced);
        
        const buttons = createKaraokeButtons(session.synced, !!session.autoScrollInterval || !!session.lyricsInterval);
        await interaction.update({ components: [container, buttons], flags: MessageFlags.IsComponentsV2 });
      }
      
      else if (action === 'prev') {
        if (session.currentLine > 0) {
          session.currentLine--;
        }
        const container = createKaraokeContainer(session.lines, session.currentLine, {
          title: session.trackTitle,
          author: session.trackAuthor
        }, interaction.user, session.lyricsSource, session.synced);
        
        const buttons = createKaraokeButtons(session.synced, !!session.autoScrollInterval || !!session.lyricsInterval);
        await interaction.update({ components: [container, buttons], flags: MessageFlags.IsComponentsV2 });
      }
      
      else if (action === 'post') {
        await postLyricsToChannel(interaction, session);
      }
      
      else if (action === 'auto') {
        if (session.autoScrollInterval || session.lyricsInterval) {
          if (session.autoScrollInterval) clearInterval(session.autoScrollInterval);
          if (session.lyricsInterval) clearInterval(session.lyricsInterval);
          session.autoScrollInterval = null;
          session.lyricsInterval = null;
          
          const container = createKaraokeContainer(session.lines, session.currentLine, {
            title: session.trackTitle,
            author: session.trackAuthor
          }, interaction.user, session.lyricsSource, session.synced);
          const buttons = createKaraokeButtons(session.synced, false);
          return interaction.update({ components: [container, buttons], flags: MessageFlags.IsComponentsV2 });
        }
        
        if (session.synced && session.lines[0]?.timestamp !== undefined) {
          session.startTime = Date.now();
          session.currentLine = 0;
          
          session.lyricsInterval = setInterval(async () => {
            const currentSession = activeKaraokeSessions.get(sessionId);
            if (!currentSession) {
              clearInterval(session.lyricsInterval);
              return;
            }
            
            const elapsed = Date.now() - currentSession.startTime;
            
            let newLineIndex = currentSession.currentLine;
            for (let i = currentSession.currentLine; i < currentSession.lines.length; i++) {
              if (currentSession.lines[i].timestamp <= elapsed) {
                newLineIndex = i;
              } else {
                break;
              }
            }
            
            if (newLineIndex !== currentSession.currentLine) {
              currentSession.currentLine = newLineIndex;
              const container = createKaraokeContainer(currentSession.lines, currentSession.currentLine, {
                title: currentSession.trackTitle,
                author: currentSession.trackAuthor
              }, interaction.user, currentSession.lyricsSource, currentSession.synced);
              
              const buttons = createKaraokeButtons(currentSession.synced, true);
              
              try {
                await interaction.editReply({ components: [container, buttons], flags: MessageFlags.IsComponentsV2 });
              } catch (e) {
                clearInterval(session.lyricsInterval);
              }
            }
          }, 200);
        } else {
          const msPerLine = session.trackLength ? Math.floor(session.trackLength / session.lines.length) : 3000;
          const scrollSpeed = Math.max(2000, Math.min(msPerLine, 5000));
          
          session.autoScrollInterval = setInterval(async () => {
            const currentSession = activeKaraokeSessions.get(sessionId);
            if (!currentSession) {
              clearInterval(session.autoScrollInterval);
              return;
            }
            
            if (currentSession.currentLine < currentSession.lines.length - 1) {
              currentSession.currentLine++;
              const container = createKaraokeContainer(currentSession.lines, currentSession.currentLine, {
                title: currentSession.trackTitle,
                author: currentSession.trackAuthor
              }, interaction.user, currentSession.lyricsSource, currentSession.synced);
              
              const buttons = createKaraokeButtons(currentSession.synced, true);
              
              try {
                await interaction.editReply({ components: [container, buttons], flags: MessageFlags.IsComponentsV2 });
              } catch (e) {
                clearInterval(session.autoScrollInterval);
              }
            } else {
              clearInterval(currentSession.autoScrollInterval);
              currentSession.autoScrollInterval = null;
            }
          }, scrollSpeed);
        }
        
        const container = createKaraokeContainer(session.lines, session.currentLine, {
          title: session.trackTitle,
          author: session.trackAuthor
        }, interaction.user, session.lyricsSource, session.synced);
        const buttons = createKaraokeButtons(session.synced, true);
        await interaction.update({ components: [container, buttons], flags: MessageFlags.IsComponentsV2 });
      }
      
      else if (action === 'stop') {
        if (session.autoScrollInterval) {
          clearInterval(session.autoScrollInterval);
        }
        if (session.lyricsInterval) {
          clearInterval(session.lyricsInterval);
        }
        activeKaraokeSessions.delete(sessionId);
        
        const endContainer = new ContainerBuilder()
          .setAccentColor(0xFF6B6B)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🎤 Karaoke Session Ended')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Thanks for singing **${session.trackTitle}**!`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('-# Use /karaoke to start another session!')
          );
        
        await interaction.update({ components: [endContainer], flags: MessageFlags.IsComponentsV2 });
      }
    } catch (error) {
      console.error('[Karaoke Button] Error:', error);
      try {
        await interaction.reply({ content: '❌ An error occurred. Try again!', ephemeral: true });
      } catch {}
    }
  },
};

async function fetchLyricsMultiSource(title, artist, originalQuery) {
  const cleanTitle = title
    .replace(/\(Official.*?\)/gi, '')
    .replace(/\[Official.*?\]/gi, '')
    .replace(/\(Lyric.*?\)/gi, '')
    .replace(/\[Lyric.*?\]/gi, '')
    .replace(/\(Audio.*?\)/gi, '')
    .replace(/\[Audio.*?\]/gi, '')
    .replace(/\(Music Video.*?\)/gi, '')
    .replace(/\[Music Video.*?\]/gi, '')
    .replace(/\(HD.*?\)/gi, '')
    .replace(/\[HD.*?\]/gi, '')
    .replace(/\(4K.*?\)/gi, '')
    .replace(/\[4K.*?\]/gi, '')
    .replace(/ft\..*/gi, '')
    .replace(/feat\..*/gi, '')
    .replace(/\|.*/gi, '')
    .replace(/-.*$/gi, '')
    .trim();
  
  const cleanArtist = artist
    ?.replace(/- Topic$/i, '')
    .replace(/VEVO$/i, '')
    .replace(/Official$/i, '')
    .replace(/Music$/i, '')
    .trim() || '';

  const result = await tryLRCLIB(cleanTitle, cleanArtist);
  if (result) return result;
  
  const result2 = await tryLyricsOvh(cleanTitle, cleanArtist);
  if (result2) return result2;
  
  const result3 = await trySomeRandomApi(cleanTitle, cleanArtist);
  if (result3) return result3;
  
  if (originalQuery.includes('-')) {
    const parts = originalQuery.split('-').map(p => p.trim());
    if (parts.length >= 2) {
      const queryArtist = parts[0];
      const queryTitle = parts.slice(1).join(' ');
      
      const result4 = await tryLRCLIB(queryTitle, queryArtist);
      if (result4) return result4;
      
      const result5 = await tryLyricsOvh(queryTitle, queryArtist);
      if (result5) return result5;
    }
  }
  
  return null;
}

async function tryLRCLIB(title, artist) {
  try {
    const url = `https://lrclib.net/api/get?artist_name=${encodeURIComponent(artist)}&track_name=${encodeURIComponent(title)}`;
    const response = await axios.get(url, { timeout: 8000 });
    
    if (response.data) {
      if (response.data.syncedLyrics) {
        const lines = parseSyncedLyrics(response.data.syncedLyrics);
        return {
          lyrics: response.data.plainLyrics || lines.map(l => l.text).join('\n'),
          lines: lines,
          synced: true,
          source: 'LRCLIB (Synced)'
        };
      }
      
      if (response.data.plainLyrics) {
        return {
          lyrics: response.data.plainLyrics,
          synced: false,
          source: 'LRCLIB'
        };
      }
    }
  } catch (e) {
    console.log('[LRCLIB] Error or no lyrics:', e.message);
  }
  
  try {
    const searchUrl = `https://lrclib.net/api/search?q=${encodeURIComponent(`${artist} ${title}`)}`;
    const searchResponse = await axios.get(searchUrl, { timeout: 8000 });
    
    if (searchResponse.data && searchResponse.data.length > 0) {
      const first = searchResponse.data[0];
      
      if (first.syncedLyrics) {
        const lines = parseSyncedLyrics(first.syncedLyrics);
        return {
          lyrics: first.plainLyrics || lines.map(l => l.text).join('\n'),
          lines: lines,
          synced: true,
          source: 'LRCLIB (Synced)'
        };
      }
      
      if (first.plainLyrics) {
        return {
          lyrics: first.plainLyrics,
          synced: false,
          source: 'LRCLIB'
        };
      }
    }
  } catch (e) {
    console.log('[LRCLIB Search] Error:', e.message);
  }
  
  return null;
}

async function tryLyricsOvh(title, artist) {
  try {
    const response = await axios.get(
      `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`,
      { timeout: 8000 }
    );
    
    if (response.data && response.data.lyrics) {
      return {
        lyrics: response.data.lyrics,
        synced: false,
        source: 'Lyrics.ovh'
      };
    }
  } catch (e) {
    console.log('[Lyrics.ovh] Error or no lyrics');
  }
  return null;
}

async function trySomeRandomApi(title, artist) {
  try {
    const response = await axios.get(
      `https://some-random-api.com/others/lyrics?title=${encodeURIComponent(`${artist} ${title}`)}`,
      { timeout: 8000 }
    );
    
    if (response.data && response.data.lyrics) {
      return {
        lyrics: response.data.lyrics,
        synced: false,
        source: 'SomeRandomAPI'
      };
    }
  } catch (e) {
    console.log('[SomeRandomAPI] Error or no lyrics');
  }
  return null;
}

function parseSyncedLyrics(syncedLyrics) {
  const lines = [];
  const regex = /\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)/g;
  let match;
  
  while ((match = regex.exec(syncedLyrics)) !== null) {
    const minutes = parseInt(match[1], 10);
    const seconds = parseInt(match[2], 10);
    const milliseconds = parseInt(match[3].padEnd(3, '0'), 10);
    const timestamp = (minutes * 60 * 1000) + (seconds * 1000) + milliseconds;
    const text = match[4].trim();
    
    if (text) {
      lines.push({ timestamp, text });
    }
  }
  
  return lines;
}

async function postLyricsToChannel(interaction, session) {
  const lines = session.lines;
  const chunks = [];
  let currentChunk = '';
  
  for (const line of lines) {
    const text = typeof line === 'string' ? line : line.text;
    if ((currentChunk + text + '\n').length > 1900) {
      chunks.push(currentChunk);
      currentChunk = text + '\n';
    } else {
      currentChunk += text + '\n';
    }
  }
  if (currentChunk) {
    chunks.push(currentChunk);
  }
  
  await interaction.reply({ 
    content: `📝 **Posting lyrics for:** ${session.trackTitle}\n\n**Follow along while singing!**`,
    ephemeral: false 
  });
  
  for (let i = 0; i < Math.min(chunks.length, 5); i++) {
    const container = new ContainerBuilder()
      .setAccentColor(0xFF69B4)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(i === 0 ? `# 🎤 ${session.trackTitle}` : `**Part ${i + 1}**`)
      );
    
    if (i === 0) {
      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*${session.trackAuthor || 'Unknown Artist'}*`)
      );
    }
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(chunks[i])
    );
    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# Part ${i + 1}/${Math.min(chunks.length, 5)} | Source: ${session.lyricsSource || 'Unknown'}`)
    );
    
    try {
      await interaction.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (e) {
      console.error('[Post Lyrics] Error sending chunk:', e.message);
    }
  }
  
  if (chunks.length > 5) {
    await interaction.channel.send({ 
      content: `📝 *Showing first 5 parts. Full lyrics have ${chunks.length} parts.*` 
    });
  }
}

function createKaraokeButtons(hasSynced, isPlaying) {
  return new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('karaoke_prev')
        .setLabel('Previous')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('⏮️'),
      new ButtonBuilder()
        .setCustomId('karaoke_next')
        .setLabel('Next Line')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('⏭️'),
      new ButtonBuilder()
        .setCustomId('karaoke_auto')
        .setLabel(isPlaying ? 'Stop Auto' : (hasSynced ? 'Synced Play' : 'Auto Scroll'))
        .setStyle(isPlaying ? ButtonStyle.Secondary : ButtonStyle.Success)
        .setEmoji(isPlaying ? '⏸️' : '▶️'),
      new ButtonBuilder()
        .setCustomId('karaoke_post')
        .setLabel('Post Lyrics')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('📝'),
      new ButtonBuilder()
        .setCustomId('karaoke_stop')
        .setLabel('Stop')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('⏹️')
    );
}

function createKaraokeContainer(lines, currentIndex, track, user, source, synced) {
  const contextLines = 7;
  const startIndex = Math.max(0, currentIndex - 2);
  const endIndex = Math.min(lines.length, currentIndex + contextLines);
  
  let lyricsDisplay = '';
  
  for (let i = startIndex; i < endIndex; i++) {
    const lineData = lines[i];
    const lineText = typeof lineData === 'string' ? lineData : lineData.text;
    
    if (i === currentIndex) {
      lyricsDisplay += `## 🎤 ${lineText}\n\n`;
    } else if (i < currentIndex) {
      lyricsDisplay += `~~${lineText}~~\n`;
    } else {
      lyricsDisplay += `${lineText}\n`;
    }
  }
  
  const progress = Math.round(((currentIndex + 1) / lines.length) * 100);
  const progressBar = createProgressBar(progress);
  
  return new ContainerBuilder()
    .setAccentColor(synced ? 0x00FF88 : 0xFF69B4)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# 🎤 Karaoke: ${track.title}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(lyricsDisplay || '*No lyrics to display*')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**🎵 Artist:** ${track.author || 'Unknown'}\n` +
            `**📝 Line:** ${currentIndex + 1}/${lines.length}\n` +
            `**${synced ? '⚡ Synced' : '📋 Source'}:** ${source || 'Unknown'}`
          )
        )
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**📊 Progress:** ${progressBar} ${progress}%`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# Requested by ${user.username} | Use buttons to navigate or post lyrics to chat`)
    );
}

function createNowPlayingContainer(track, user) {
  return new ContainerBuilder()
    .setAccentColor(0x5865F2)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 🎵 Now Playing')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**[${track.title}](${track.uri})**`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**Author:** ${track.author || 'Unknown'}\n` +
            `**Duration:** ${formatDuration(track.length)}\n` +
            `**Requested By:** ${user}`
          )
        )
        .setThumbnailAccessory(
          track.thumbnail ? new ThumbnailBuilder().setURL(track.thumbnail) : null
        )
    );
}

function createProgressBar(percent) {
  const filled = Math.round(percent / 10);
  const empty = 10 - filled;
  return '▓'.repeat(filled) + '░'.repeat(empty);
}

function formatDuration(ms) {
  if (!ms || ms === 0) return 'Live';
  
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor(ms / (1000 * 60 * 60));
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
