import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('nowplaying')
    .setDescription('Show the currently playing song'),
  
  async execute(interaction, client) {
    const kazagumo = client.kazagumo;
    const player = kazagumo.players.get(interaction.guildId);
    
    if (!player || !player.queue.current) {
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('## Error')
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('No music is currently playing!')
            )
        );
      return interaction.reply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
    }
    
    const track = player.queue.current;
    const position = player.position;
    const duration = track.length;
    
    const progress = createProgressBar(position, duration);
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## Now Playing')
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**[${track.title}](${track.uri})**\nBy: ${track.author}\n\n**Duration:** ${formatDuration(position)} / ${formatDuration(duration)}\n**Requested By:** ${track.requester}\n\n**Progress:**\n${progress}`)
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`Volume: ${player.volume}% | Songs in queue: ${player.queue.length}`)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};

function formatDuration(ms) {
  if (!ms || ms === 0) return 'Live';
  
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor(ms / (1000 * 60 * 60));
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

function createProgressBar(current, total, length = 15) {
  if (!total || total === 0) return 'Live Stream';
  
  const progress = Math.round((current / total) * length);
  const emptyProgress = length - progress;
  
  const progressBar = '▓'.repeat(progress) + '░'.repeat(emptyProgress);
  const percentage = Math.round((current / total) * 100);
  
  return `${progressBar} ${percentage}%`;
}
