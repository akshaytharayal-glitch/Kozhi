import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import axios from 'axios';

const ALLOWED_HOSTNAMES = new Set([
  'youtube.com',
  'www.youtube.com',
  'm.youtube.com',
  'youtu.be',
  'genius.com',
  'www.genius.com',
  'azlyrics.com',
  'www.azlyrics.com',
  'lyrics.com',
  'www.lyrics.com',
  'musixmatch.com',
  'www.musixmatch.com',
  'songlyrics.com',
  'www.songlyrics.com',
  'metrolyrics.com',
  'www.metrolyrics.com'
]);

function isAllowedUrl(urlString) {
  try {
    const parsed = new URL(urlString);
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return false;
    }
    const hostname = parsed.hostname.toLowerCase();
    return ALLOWED_HOSTNAMES.has(hostname);
  } catch (e) {
    return false;
  }
}

const SAFE_AXIOS_CONFIG = {
  timeout: 15000,
  maxRedirects: 0,
  validateStatus: status => status >= 200 && status < 300,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  }
};

export default {
  data: new SlashCommandBuilder()
    .setName('lyrics')
    .setDescription('Get lyrics from a URL or search by song name')
    .addStringOption(option =>
      option.setName('url')
        .setDescription('Direct URL to lyrics page (Genius, AZLyrics, YouTube, Lyrics.com)')
        .setRequired(true)),
  
  cooldown: 5,
  
  async execute(interaction, client) {
    const url = interaction.options.getString('url');
    
    if (!isAllowedUrl(url)) {
      const container = new ContainerBuilder()
        .setAccentColor(0xFF6B6B)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Invalid URL')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `Please provide a URL from one of these supported sites:\n\n` +
            `- **YouTube** (youtube.com, youtu.be)\n` +
            `- **Genius** (genius.com)\n` +
            `- **AZLyrics** (azlyrics.com)\n` +
            `- **Lyrics.com** (lyrics.com)\n` +
            `- **Musixmatch** (musixmatch.com)\n` +
            `- **SongLyrics** (songlyrics.com)`
          )
        );
      
      return interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
      });
    }
    
    await interaction.deferReply();
    
    try {
      let lyricsData = null;
      let songTitle = 'Unknown Song';
      let artistName = 'Unknown Artist';
      
      if (isYouTubeUrl(url)) {
        const videoInfo = await extractYouTubeInfo(url);
        if (videoInfo) {
          songTitle = videoInfo.title;
          artistName = videoInfo.artist;
          lyricsData = await searchLyricsFromInfo(songTitle, artistName);
        }
      } else if (isGeniusUrl(url)) {
        lyricsData = await scrapeGeniusLyrics(url);
        if (lyricsData) {
          songTitle = lyricsData.title || songTitle;
          artistName = lyricsData.artist || artistName;
        }
      } else if (isAZLyricsUrl(url)) {
        lyricsData = await scrapeAZLyrics(url);
        if (lyricsData) {
          songTitle = lyricsData.title || songTitle;
          artistName = lyricsData.artist || artistName;
        }
      } else if (isLyricsComUrl(url)) {
        lyricsData = await scrapeLyricsCom(url);
        if (lyricsData) {
          songTitle = lyricsData.title || songTitle;
          artistName = lyricsData.artist || artistName;
        }
      } else {
        lyricsData = await scrapeGenericLyrics(url);
        if (lyricsData) {
          songTitle = lyricsData.title || songTitle;
          artistName = lyricsData.artist || artistName;
        }
      }
      
      if (!lyricsData || !lyricsData.lyrics) {
        const container = new ContainerBuilder()
          .setAccentColor(0xFF6B6B)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# Lyrics Not Found')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `Could not extract lyrics from the provided URL.\n\n` +
              `**Supported sites:**\n- Genius\n- AZLyrics\n- Lyrics.com\n- YouTube (for search)\n\n` +
              `**Tip:** Make sure the URL points directly to a lyrics page.`
            )
          );
        
        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }
      
      const lines = lyricsData.lyrics.split('\n').filter(line => line.trim() !== '');
      const chunks = createLyricsChunks(lines);
      
      if (chunks.length === 1) {
        const container = createLyricsContainer(songTitle, artistName, chunks[0], 1, 1, lyricsData.source);
        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }
      
      let currentPage = 0;
      const container = createLyricsContainer(songTitle, artistName, chunks[currentPage], currentPage + 1, chunks.length, lyricsData.source);
      const buttons = createPaginationButtons(currentPage, chunks.length);
      
      const message = await interaction.editReply({ 
        components: [container, buttons],
        flags: MessageFlags.IsComponentsV2
      });
      
      const collector = message.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id,
        time: 300000
      });
      
      collector.on('collect', async i => {
        if (i.customId === 'lyrics_prev') {
          currentPage = Math.max(0, currentPage - 1);
        } else if (i.customId === 'lyrics_next') {
          currentPage = Math.min(chunks.length - 1, currentPage + 1);
        } else if (i.customId === 'lyrics_first') {
          currentPage = 0;
        } else if (i.customId === 'lyrics_last') {
          currentPage = chunks.length - 1;
        }
        
        const newContainer = createLyricsContainer(songTitle, artistName, chunks[currentPage], currentPage + 1, chunks.length, lyricsData.source);
        const newButtons = createPaginationButtons(currentPage, chunks.length);
        
        await i.update({ components: [newContainer, newButtons], flags: MessageFlags.IsComponentsV2 });
      });
      
      collector.on('end', async () => {
        try {
          const finalContainer = createLyricsContainer(songTitle, artistName, chunks[currentPage], currentPage + 1, chunks.length, lyricsData.source);
          await message.edit({ components: [finalContainer], flags: MessageFlags.IsComponentsV2 });
        } catch (e) {}
      });
      
    } catch (error) {
      console.error('[Lyrics] Error:', error);
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFF6B6B)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Error')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('An error occurred while fetching lyrics. Please try again with a different URL.')
        );
      
      return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  },
};

function isYouTubeUrl(url) {
  return /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/i.test(url);
}

function isGeniusUrl(url) {
  return /^(https?:\/\/)?(www\.)?genius\.com\/.+/i.test(url);
}

function isAZLyricsUrl(url) {
  return /^(https?:\/\/)?(www\.)?azlyrics\.com\/.+/i.test(url);
}

function isLyricsComUrl(url) {
  return /^(https?:\/\/)?(www\.)?lyrics\.com\/.+/i.test(url);
}

async function extractYouTubeInfo(url) {
  try {
    const videoId = extractYouTubeVideoId(url);
    if (!videoId) return null;
    
    const response = await axios.get(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`, {
      timeout: 10000
    });
    
    if (response.data) {
      const title = response.data.title || '';
      const author = response.data.author_name || '';
      
      const cleanedInfo = cleanYouTubeTitle(title, author);
      return cleanedInfo;
    }
  } catch (e) {
    console.log('[YouTube] Error extracting info:', e.message);
  }
  return null;
}

function extractYouTubeVideoId(url) {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/,
    /youtube\.com\/embed\/([^&\n?#]+)/,
    /youtube\.com\/v\/([^&\n?#]+)/
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

function cleanYouTubeTitle(title, author) {
  let cleanTitle = title
    .replace(/\(Official.*?\)/gi, '')
    .replace(/\[Official.*?\]/gi, '')
    .replace(/\(Lyric.*?\)/gi, '')
    .replace(/\[Lyric.*?\]/gi, '')
    .replace(/\(Audio.*?\)/gi, '')
    .replace(/\[Audio.*?\]/gi, '')
    .replace(/\(Music Video.*?\)/gi, '')
    .replace(/\[Music Video.*?\]/gi, '')
    .replace(/\(HD.*?\)/gi, '')
    .replace(/\[HD.*?\]/gi, '')
    .replace(/\(4K.*?\)/gi, '')
    .replace(/\[4K.*?\]/gi, '')
    .replace(/\(Visualizer.*?\)/gi, '')
    .replace(/\[Visualizer.*?\]/gi, '')
    .replace(/\|.*/gi, '')
    .trim();
  
  let artist = author
    ?.replace(/- Topic$/i, '')
    .replace(/VEVO$/i, '')
    .replace(/Official$/i, '')
    .replace(/Music$/i, '')
    .trim() || '';
  
  if (cleanTitle.includes(' - ')) {
    const parts = cleanTitle.split(' - ');
    artist = parts[0].trim();
    cleanTitle = parts.slice(1).join(' - ').trim();
  }
  
  cleanTitle = cleanTitle
    .replace(/ft\..*/gi, '')
    .replace(/feat\..*/gi, '')
    .trim();
  
  return { title: cleanTitle, artist };
}

async function searchLyricsFromInfo(title, artist) {
  const result = await tryLRCLIB(title, artist);
  if (result) return result;
  
  const result2 = await tryLyricsOvh(title, artist);
  if (result2) return result2;
  
  const result3 = await trySomeRandomApi(title, artist);
  if (result3) return result3;
  
  return null;
}

async function tryLRCLIB(title, artist) {
  try {
    const url = `https://lrclib.net/api/get?artist_name=${encodeURIComponent(artist)}&track_name=${encodeURIComponent(title)}`;
    const response = await axios.get(url, { timeout: 8000 });
    
    if (response.data && response.data.plainLyrics) {
      return {
        lyrics: response.data.plainLyrics,
        title: response.data.trackName || title,
        artist: response.data.artistName || artist,
        source: 'LRCLIB'
      };
    }
  } catch (e) {}
  
  try {
    const searchUrl = `https://lrclib.net/api/search?q=${encodeURIComponent(`${artist} ${title}`)}`;
    const searchResponse = await axios.get(searchUrl, { timeout: 8000 });
    
    if (searchResponse.data && searchResponse.data.length > 0) {
      const first = searchResponse.data[0];
      if (first.plainLyrics) {
        return {
          lyrics: first.plainLyrics,
          title: first.trackName || title,
          artist: first.artistName || artist,
          source: 'LRCLIB'
        };
      }
    }
  } catch (e) {}
  
  return null;
}

async function tryLyricsOvh(title, artist) {
  try {
    const response = await axios.get(
      `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`,
      { timeout: 8000 }
    );
    
    if (response.data && response.data.lyrics) {
      return {
        lyrics: response.data.lyrics,
        title,
        artist,
        source: 'Lyrics.ovh'
      };
    }
  } catch (e) {}
  return null;
}

async function trySomeRandomApi(title, artist) {
  try {
    const response = await axios.get(
      `https://some-random-api.com/others/lyrics?title=${encodeURIComponent(`${artist} ${title}`)}`,
      { timeout: 8000 }
    );
    
    if (response.data && response.data.lyrics) {
      return {
        lyrics: response.data.lyrics,
        title: response.data.title || title,
        artist: response.data.author || artist,
        source: 'SomeRandomAPI'
      };
    }
  } catch (e) {}
  return null;
}

async function scrapeGeniusLyrics(url) {
  try {
    const response = await axios.get(url, SAFE_AXIOS_CONFIG);
    
    const html = response.data;
    
    let title = '';
    let artist = '';
    
    const titleMatch = html.match(/<title>(.*?)<\/title>/i);
    if (titleMatch) {
      const fullTitle = titleMatch[1].replace(' | Genius Lyrics', '').trim();
      if (fullTitle.includes(' – ')) {
        const parts = fullTitle.split(' – ');
        artist = parts[0].trim();
        title = parts[1].replace(' Lyrics', '').trim();
      }
    }
    
    let lyrics = '';
    
    const lyricsContainerMatch = html.match(/data-lyrics-container="true"[^>]*>([\s\S]*?)(?=<\/div><div|<div class="LyricsFooter)/gi);
    if (lyricsContainerMatch) {
      for (const match of lyricsContainerMatch) {
        let text = match
          .replace(/<br\s*\/?>/gi, '\n')
          .replace(/<[^>]+>/g, '')
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&quot;/g, '"')
          .replace(/&#x27;/g, "'")
          .replace(/&#39;/g, "'")
          .trim();
        lyrics += text + '\n';
      }
    }
    
    if (!lyrics) {
      const jsonMatch = html.match(/window\.__PRELOADED_STATE__\s*=\s*JSON\.parse\('([^']+)'\)/);
      if (jsonMatch) {
        try {
          const jsonStr = jsonMatch[1].replace(/\\'/g, "'").replace(/\\"/g, '"');
          const data = JSON.parse(jsonStr);
          if (data.songPage?.lyricsData?.body?.html) {
            lyrics = data.songPage.lyricsData.body.html
              .replace(/<br\s*\/?>/gi, '\n')
              .replace(/<[^>]+>/g, '')
              .trim();
          }
        } catch (e) {}
      }
    }
    
    if (lyrics) {
      return { lyrics, title, artist, source: 'Genius' };
    }
  } catch (e) {
    console.log('[Genius] Scraping error:', e.message);
  }
  return null;
}

async function scrapeAZLyrics(url) {
  try {
    const response = await axios.get(url, SAFE_AXIOS_CONFIG);
    
    const html = response.data;
    
    let title = '';
    let artist = '';
    
    const titleMatch = html.match(/<title>(.*?) Lyrics \| AZLyrics\.com<\/title>/i);
    if (titleMatch) {
      const fullTitle = titleMatch[1];
      if (fullTitle.includes(' - ')) {
        const parts = fullTitle.split(' - ');
        artist = parts[0].trim();
        title = parts[1].replace(/"/g, '').trim();
      }
    }
    
    const lyricsMatch = html.match(/<!-- Usage of azlyrics\.com content by any third-party lyrics provider is prohibited by our licensing agreement\. Sorry about that\. -->[\s\S]*?<\/div>/i);
    
    if (lyricsMatch) {
      let lyrics = lyricsMatch[0]
        .replace(/<!-- Usage of azlyrics\.com content by any third-party lyrics provider is prohibited by our licensing agreement\. Sorry about that\. -->/gi, '')
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#x27;/g, "'")
        .replace(/&#39;/g, "'")
        .trim();
      
      if (lyrics) {
        return { lyrics, title, artist, source: 'AZLyrics' };
      }
    }
  } catch (e) {
    console.log('[AZLyrics] Scraping error:', e.message);
  }
  return null;
}

async function scrapeLyricsCom(url) {
  try {
    const response = await axios.get(url, SAFE_AXIOS_CONFIG);
    
    const html = response.data;
    
    let title = '';
    let artist = '';
    
    const titleMatch = html.match(/<h1[^>]*id="lyric-title-text"[^>]*>(.*?)<\/h1>/i);
    if (titleMatch) {
      title = titleMatch[1].replace(/<[^>]+>/g, '').trim();
    }
    
    const artistMatch = html.match(/<h3[^>]*class="lyric-artist"[^>]*>.*?<a[^>]*>(.*?)<\/a>/i);
    if (artistMatch) {
      artist = artistMatch[1].replace(/<[^>]+>/g, '').trim();
    }
    
    const lyricsMatch = html.match(/<pre[^>]*id="lyric-body-text"[^>]*>([\s\S]*?)<\/pre>/i);
    if (lyricsMatch) {
      let lyrics = lyricsMatch[1]
        .replace(/<[^>]+>/g, '')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#x27;/g, "'")
        .replace(/&#39;/g, "'")
        .trim();
      
      if (lyrics) {
        return { lyrics, title, artist, source: 'Lyrics.com' };
      }
    }
  } catch (e) {
    console.log('[Lyrics.com] Scraping error:', e.message);
  }
  return null;
}

async function scrapeGenericLyrics(url) {
  try {
    const response = await axios.get(url, SAFE_AXIOS_CONFIG);
    
    const html = response.data;
    
    let title = '';
    const titleMatch = html.match(/<title>(.*?)<\/title>/i);
    if (titleMatch) {
      title = titleMatch[1]
        .replace(/ - Lyrics.*$/i, '')
        .replace(/ Lyrics$/i, '')
        .replace(/ \|.*$/i, '')
        .trim();
    }
    
    const lyricsPatterns = [
      /<div[^>]*class="[^"]*lyrics[^"]*"[^>]*>([\s\S]*?)<\/div>/gi,
      /<div[^>]*id="[^"]*lyrics[^"]*"[^>]*>([\s\S]*?)<\/div>/gi,
      /<pre[^>]*class="[^"]*lyrics[^"]*"[^>]*>([\s\S]*?)<\/pre>/gi,
      /<div[^>]*class="[^"]*lyric-body[^"]*"[^>]*>([\s\S]*?)<\/div>/gi
    ];
    
    for (const pattern of lyricsPatterns) {
      const matches = html.matchAll(pattern);
      for (const match of matches) {
        let lyrics = match[1]
          .replace(/<br\s*\/?>/gi, '\n')
          .replace(/<p>/gi, '\n')
          .replace(/<\/p>/gi, '\n')
          .replace(/<[^>]+>/g, '')
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&quot;/g, '"')
          .replace(/&#x27;/g, "'")
          .replace(/&#39;/g, "'")
          .trim();
        
        if (lyrics && lyrics.length > 100) {
          return { lyrics, title, artist: '', source: 'Web Scrape' };
        }
      }
    }
  } catch (e) {
    console.log('[Generic] Scraping error:', e.message);
  }
  return null;
}

function createLyricsChunks(lines) {
  const chunks = [];
  let currentChunk = '';
  
  for (const line of lines) {
    if ((currentChunk + line + '\n').length > 1800) {
      if (currentChunk) chunks.push(currentChunk.trim());
      currentChunk = line + '\n';
    } else {
      currentChunk += line + '\n';
    }
  }
  if (currentChunk.trim()) {
    chunks.push(currentChunk.trim());
  }
  
  return chunks.length ? chunks : ['No lyrics content found.'];
}

function createLyricsContainer(title, artist, content, page, totalPages, source) {
  return new ContainerBuilder()
    .setAccentColor(0xFF69B4)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# ${title}`)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`*${artist || 'Unknown Artist'}*`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# Page ${page}/${totalPages} | Source: ${source || 'Unknown'}`)
    );
}

function createPaginationButtons(currentPage, totalPages) {
  return new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('lyrics_first')
        .setLabel('First')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('⏮️')
        .setDisabled(currentPage === 0),
      new ButtonBuilder()
        .setCustomId('lyrics_prev')
        .setLabel('Previous')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('◀️')
        .setDisabled(currentPage === 0),
      new ButtonBuilder()
        .setCustomId('lyrics_next')
        .setLabel('Next')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('▶️')
        .setDisabled(currentPage === totalPages - 1),
      new ButtonBuilder()
        .setCustomId('lyrics_last')
        .setLabel('Last')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('⏭️')
        .setDisabled(currentPage === totalPages - 1)
    );
}
