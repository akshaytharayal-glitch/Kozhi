import { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import { addScheduledAnnouncement, getScheduledAnnouncements, removeScheduledAnnouncement } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Create scheduled or instant announcements')
    .addSubcommand(subcommand =>
      subcommand
        .setName('schedule')
        .setDescription('Schedule an announcement for later')
        .addStringOption(option =>
          option.setName('message')
            .setDescription('The announcement message')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('minutes')
            .setDescription('Minutes from now to post (0-59)')
            .setRequired(true)
            .setMinValue(0)
            .setMaxValue(59))
        .addIntegerOption(option =>
          option.setName('hours')
            .setDescription('Hours from now to post (0-23)')
            .setRequired(false)
            .setMinValue(0)
            .setMaxValue(23))
        .addIntegerOption(option =>
          option.setName('days')
            .setDescription('Days from now to post (0-30)')
            .setRequired(false)
            .setMinValue(0)
            .setMaxValue(30))
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('Channel to post in (default: current channel)')
            .setRequired(false))
        .addStringOption(option =>
          option.setName('title')
            .setDescription('Optional title for the announcement')
            .setRequired(false))
        .addBooleanOption(option =>
          option.setName('embed')
            .setDescription('Send as an embed? (default: true)')
            .setRequired(false))
        .addBooleanOption(option =>
          option.setName('ping_everyone')
            .setDescription('Ping @everyone? (default: false)')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('List all scheduled announcements'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('cancel')
        .setDescription('Cancel a scheduled announcement')
        .addStringOption(option =>
          option.setName('id')
            .setDescription('The ID of the announcement to cancel')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  cooldown: 3,

  async execute(interaction, client) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'schedule') {
      await handleSchedule(interaction);
    } else if (subcommand === 'list') {
      await handleList(interaction);
    } else if (subcommand === 'cancel') {
      await handleCancel(interaction);
    }
  }
};

async function handleSchedule(interaction) {
  const message = interaction.options.getString('message');
  const minutes = interaction.options.getInteger('minutes');
  const hours = interaction.options.getInteger('hours') || 0;
  const days = interaction.options.getInteger('days') || 0;
  const channel = interaction.options.getChannel('channel') || interaction.channel;
  const title = interaction.options.getString('title');
  const useEmbed = interaction.options.getBoolean('embed') ?? true;
  const pingEveryone = interaction.options.getBoolean('ping_everyone') || false;

  const totalMinutes = minutes + (hours * 60) + (days * 24 * 60);

  if (totalMinutes < 1) {
    return interaction.reply({
      content: 'You must schedule the announcement for at least 1 minute in the future!',
      ephemeral: true
    });
  }

  const publishTime = Date.now() + (totalMinutes * 60 * 1000);

  const announcement = {
    message,
    title,
    channelId: channel.id,
    publishTime,
    useEmbed,
    pingEveryone,
    authorId: interaction.user.id,
    sent: false,
    createdAt: Date.now()
  };

  const saved = addScheduledAnnouncement(interaction.guild.id, announcement);

  const timeString = formatDuration(totalMinutes);
  const messagePreview = message.length > 100 ? message.substring(0, 100) + '...' : message;
  
  const container = new ContainerBuilder()
    .setAccentColor(0x00FF00)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 📢 Announcement Scheduled')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('Your announcement has been scheduled!')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**📝 Message Preview**\n${messagePreview}`)
        )
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**📍 Channel:** ${channel}\n` +
            `**⏰ Posts In:** ${timeString}\n` +
            `**🕐 Posts At:** <t:${Math.floor(publishTime / 1000)}:F>\n` +
            `**🆔 ID:** ${saved.id}`
          )
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('-# Use /announce cancel to remove this announcement')
    );

  await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
}

async function handleList(interaction) {
  const announcements = getScheduledAnnouncements(interaction.guild.id);
  const pending = announcements.filter(a => !a.sent);

  if (pending.length === 0) {
    return interaction.reply({
      content: 'There are no scheduled announcements!',
      ephemeral: true
    });
  }

  const container = new ContainerBuilder()
    .setAccentColor(0x0099FF)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 📢 Scheduled Announcements')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`Found **${pending.length}** pending announcement(s)`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );

  for (const ann of pending.slice(0, 10)) {
    const preview = ann.message.length > 50 ? ann.message.substring(0, 50) + '...' : ann.message;
    container.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**ID:** ${ann.id}\n` +
            `**Message:** ${preview}\n` +
            `**Channel:** <#${ann.channelId}>\n` +
            `**Posts:** <t:${Math.floor(ann.publishTime / 1000)}:R>`
          )
        )
    );
  }

  if (pending.length > 10) {
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# Showing 10 of ${pending.length} announcements`)
    );
  }

  await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });
}

async function handleCancel(interaction) {
  const id = interaction.options.getString('id');
  const announcements = getScheduledAnnouncements(interaction.guild.id);
  const announcement = announcements.find(a => a.id === id);

  if (!announcement) {
    return interaction.reply({
      content: 'Announcement not found! Use `/announce list` to see all scheduled announcements.',
      ephemeral: true
    });
  }

  if (announcement.sent) {
    return interaction.reply({
      content: 'This announcement has already been sent!',
      ephemeral: true
    });
  }

  removeScheduledAnnouncement(interaction.guild.id, id);

  await interaction.reply({
    content: `Announcement with ID \`${id}\` has been cancelled!`,
    ephemeral: true
  });
}

function formatDuration(minutes) {
  const days = Math.floor(minutes / (24 * 60));
  const hours = Math.floor((minutes % (24 * 60)) / 60);
  const mins = minutes % 60;

  const parts = [];
  if (days > 0) parts.push(`${days} day${days !== 1 ? 's' : ''}`);
  if (hours > 0) parts.push(`${hours} hour${hours !== 1 ? 's' : ''}`);
  if (mins > 0) parts.push(`${mins} minute${mins !== 1 ? 's' : ''}`);

  return parts.join(', ') || '0 minutes';
}

export async function publishAnnouncement(guild, announcement, client) {
  try {
    const channel = await guild.channels.fetch(announcement.channelId);
    
    if (!channel) {
      console.error(`Channel ${announcement.channelId} not found for announcement`);
      return false;
    }

    const prefix = announcement.pingEveryone ? '@everyone\n' : '';

    if (announcement.useEmbed) {
      const container = new ContainerBuilder()
        .setAccentColor(0xFF6B6B)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`# ${announcement.title || '📢 Announcement'}`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(announcement.message)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`-# Posted by the announcement system`)
        );

      await channel.send({ content: prefix || undefined, components: [container], flags: MessageFlags.IsComponentsV2 });
    } else {
      const content = announcement.title 
        ? `${prefix}**${announcement.title}**\n\n${announcement.message}`
        : `${prefix}${announcement.message}`;
      
      await channel.send(content);
    }

    return true;
  } catch (error) {
    console.error('Error publishing announcement:', error);
    return false;
  }
}
