import { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags
} from 'discord.js';
import { getPrefix } from '../../events/messageCreate.js';

export default {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('View all available commands')
    .addStringOption(option =>
      option.setName('category')
        .setDescription('Command category')
        .setRequired(false)
        .addChoices(
          { name: 'Management', value: 'management' },
          { name: 'Music', value: 'music' },
          { name: 'Economy', value: 'economy' },
          { name: 'Games', value: 'games' },
          { name: 'Fun & Jokes', value: 'fun' },
          { name: 'Tickets', value: 'ticket' },
          { name: 'Utility', value: 'utility' }
        )),
  
  aliases: ['commands', 'cmds', 'h'],
  
  async execute(interaction, client) {
    const category = interaction.options.getString('category');
    const currentPrefix = getPrefix(interaction.guild.id);
    
    const categories = {
      management: {
        emoji: '🛡️',
        name: 'Management',
        commands: [
          { name: '/kick', desc: 'Kick a member from the server', aliases: [`${currentPrefix}kick`] },
          { name: '/ban', desc: 'Ban a member from the server', aliases: [`${currentPrefix}ban`] },
          { name: '/mute', desc: 'Timeout a member', aliases: [`${currentPrefix}mute`, `${currentPrefix}timeout`] },
          { name: '/unmute', desc: 'Remove timeout from a member', aliases: [`${currentPrefix}unmute`] },
          { name: '/clear', desc: 'Delete multiple messages', aliases: [`${currentPrefix}clear`, `${currentPrefix}purge`] },
          { name: '/role add/remove', desc: 'Manage user roles', aliases: [`${currentPrefix}role`] },
        ],
      },
      music: {
        emoji: '🎵',
        name: 'Music',
        commands: [
          { name: '/play', desc: 'Play a song or playlist', aliases: [`${currentPrefix}play`, `${currentPrefix}p`] },
          { name: '/skip', desc: 'Skip the current song', aliases: [`${currentPrefix}skip`, `${currentPrefix}s`, `${currentPrefix}next`] },
          { name: '/stop', desc: 'Stop music and clear queue', aliases: [`${currentPrefix}stop`, `${currentPrefix}dc`, `${currentPrefix}leave`] },
          { name: '/pause', desc: 'Pause the current song', aliases: [`${currentPrefix}pause`] },
          { name: '/resume', desc: 'Resume playback', aliases: [`${currentPrefix}resume`, `${currentPrefix}unpause`] },
          { name: '/queue', desc: 'View the music queue', aliases: [`${currentPrefix}queue`] },
          { name: '/shuffle', desc: 'Shuffle the queue', aliases: [`${currentPrefix}shuffle`, `${currentPrefix}mix`] },
          { name: '/nowplaying', desc: 'Show current song', aliases: [`${currentPrefix}np`, `${currentPrefix}current`] },
          { name: '/volume', desc: 'Set the volume', aliases: [`${currentPrefix}volume`, `${currentPrefix}vol`] },
        ],
      },
      economy: {
        emoji: '🥚',
        name: 'Economy',
        commands: [
          { name: '/balance', desc: 'Check egg balance', aliases: [`${currentPrefix}balance`, `${currentPrefix}bal`] },
          { name: '/daily', desc: 'Claim daily egg reward', aliases: [`${currentPrefix}daily`] },
          { name: '/gather', desc: 'Gather eggs from the farm', aliases: [`${currentPrefix}gather`] },
          { name: '/rob', desc: 'Rob eggs from another player (40% success)', aliases: [`${currentPrefix}rob`] },
          { name: '/give', desc: 'Give eggs to another user', aliases: [`${currentPrefix}give`] },
          { name: '/leaderboard', desc: 'View members with most eggs', aliases: [`${currentPrefix}leaderboard`, `${currentPrefix}lb`] },
          { name: '/addeggs', desc: 'Add eggs (Admin)', aliases: [] },
          { name: '/removeeggs', desc: 'Remove eggs (Admin)', aliases: [] },
        ],
      },
      games: {
        emoji: '🎮',
        name: 'Games',
        commands: [
          { name: '/coinflip', desc: 'Flip a coin and bet', aliases: [`${currentPrefix}coinflip`, `${currentPrefix}cf`, `${currentPrefix}flip`] },
          { name: '/dice', desc: 'Roll dice against the bot', aliases: [`${currentPrefix}dice`, `${currentPrefix}roll`] },
          { name: '/slots', desc: 'Play the slot machine', aliases: [`${currentPrefix}slots`, `${currentPrefix}gamble`] },
          { name: '/rps', desc: 'Rock Paper Scissors', aliases: [`${currentPrefix}rps`, `${currentPrefix}rockpaperscissors`] },
          { name: '/trivia', desc: 'Answer trivia questions', aliases: [`${currentPrefix}trivia`, `${currentPrefix}quiz`, `${currentPrefix}q`] },
          { name: '/hangman', desc: 'Play Hangman', aliases: [`${currentPrefix}hangman`, `${currentPrefix}hang`] },
          { name: '/wouldyourather', desc: 'Would you rather...', aliases: [`${currentPrefix}wyr`, `${currentPrefix}rather`] },
          { name: '/truthordare', desc: 'Truth or Dare game', aliases: [`${currentPrefix}tod`, `${currentPrefix}tord`] },
          { name: '/count setup', desc: 'Set up counting game', aliases: [`${currentPrefix}count`] },
        ],
      },
      fun: {
        emoji: '😂',
        name: 'Fun & Jokes',
        commands: [
          { name: '/joke', desc: 'Get jokes in 14+ languages (Malayalam, Hindi, Spanish, etc.)', aliases: [`${currentPrefix}joke`, `${currentPrefix}jokes`, `${currentPrefix}lol`] },
          { name: '/dadjoke', desc: 'Classic dad jokes', aliases: [`${currentPrefix}dadjoke`, `${currentPrefix}dad`, `${currentPrefix}dj`] },
          { name: '/jokeoftheday', desc: 'Daily joke feature', aliases: [`${currentPrefix}jotd`, `${currentPrefix}dailyjoke`] },
          { name: '/meme', desc: 'Get random memes from Reddit', aliases: [`${currentPrefix}meme`, `${currentPrefix}reddit`] },
          { name: '/gay', desc: 'How gay is someone?', aliases: [`${currentPrefix}gay`, `${currentPrefix}howgay`] },
          { name: '/marriage', desc: 'Ship two users together', aliases: [`${currentPrefix}marriage`, `${currentPrefix}ship`, `${currentPrefix}marry`] },
        ],
      },
      ticket: {
        emoji: '🎫',
        name: 'Tickets',
        commands: [
          { name: '/ticket setup', desc: 'Set up ticket system', aliases: [`${currentPrefix}ticket`] },
          { name: '/ticket close', desc: 'Close current ticket', aliases: [] },
          { name: '/ticket add', desc: 'Add user to ticket', aliases: [] },
          { name: '/ticket remove', desc: 'Remove user from ticket', aliases: [] },
        ],
      },
      utility: {
        emoji: '🔧',
        name: 'Utility',
        commands: [
          { name: '/help', desc: 'View all commands', aliases: [`${currentPrefix}help`, `${currentPrefix}commands`] },
          { name: '/ping', desc: 'Check bot latency', aliases: [`${currentPrefix}ping`] },
          { name: '/serverinfo', desc: 'View server information', aliases: [`${currentPrefix}serverinfo`, `${currentPrefix}si`] },
          { name: '/userinfo', desc: 'View user information', aliases: [`${currentPrefix}userinfo`, `${currentPrefix}ui`, `${currentPrefix}whois`] },
          { name: '/level', desc: 'Check your level and XP', aliases: [`${currentPrefix}level`, `${currentPrefix}lvl`, `${currentPrefix}rank`] },
          { name: '/stats', desc: 'View detailed user statistics', aliases: [`${currentPrefix}stats`] },
          { name: '/leaderboards', desc: 'View various leaderboards', aliases: [`${currentPrefix}leaderboards`, `${currentPrefix}lbs`] },
          { name: '/mcstatus', desc: 'Check Minecraft server status', aliases: [`${currentPrefix}mcstatus`, `${currentPrefix}mc`] },
          { name: '/ai', desc: 'AI chat settings', aliases: [] },
          { name: '/announce', desc: 'Send announcements', aliases: [`${currentPrefix}announce`] },
          { name: '/giveaway', desc: 'Create giveaways', aliases: [`${currentPrefix}giveaway`, `${currentPrefix}gw`] },
        ],
      },
    };
    
    if (category) {
      const cat = categories[category];
      const commandList = cat.commands.map(cmd => {
        const aliasText = cmd.aliases.length > 0 ? `\n*Aliases: ${cmd.aliases.join(', ')}*` : '';
        return `**${cmd.name}** - ${cmd.desc}${aliasText}`;
      }).join('\n\n');
      
      const container = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`# ${cat.emoji} ${cat.name} Commands`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(commandList)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`*Use /help to see all categories | Prefix: ${currentPrefix}*`)
        );
      
      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
    
    const categoryList = Object.entries(categories).map(([key, cat]) => 
      `${cat.emoji} **${cat.name}**: ${cat.commands.map(cmd => `\`${cmd.name.split(' ')[0]}\``).join(' ')}`
    ).join('\n\n');
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# 📚 All Commands'),
        new TextDisplayBuilder().setContent(`Use \`/help <category>\` for detailed command info\n\n**Prefix:** \`${currentPrefix}\` (e.g., \`/joke\` = \`${currentPrefix}joke\`)`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(categoryList)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('**Quick Access Categories:**')
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('🎮 **Games** - Coinflip, RPS, Trivia, Hangman...')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId('help_games')
              .setLabel('Games')
              .setStyle(ButtonStyle.Primary)
          )
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('😂 **Fun & Jokes** - Jokes, Memes, Marriage...')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId('help_fun')
              .setLabel('Fun')
              .setStyle(ButtonStyle.Success)
          )
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('🎵 **Music** - Play, Skip, Queue, Volume...')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId('help_music')
              .setLabel('Music')
              .setStyle(ButtonStyle.Secondary)
          )
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('🥚 **Economy** - Balance, Daily, Gather, Rob...')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId('help_economy')
              .setLabel('Economy')
              .setStyle(ButtonStyle.Secondary)
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*${client.commands.size} commands total | All commands have prefix alternatives!*`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
  
  async handleButton(interaction) {
    if (!interaction.customId.startsWith('help_')) return;
    
    const category = interaction.customId.replace('help_', '');
    const currentPrefix = getPrefix(interaction.guild.id);
    
    const categories = {
      games: {
        emoji: '🎮',
        name: 'Games',
        commands: [
          { name: '/coinflip', desc: 'Flip a coin and bet', aliases: [`${currentPrefix}coinflip`, `${currentPrefix}cf`] },
          { name: '/dice', desc: 'Roll dice against the bot', aliases: [`${currentPrefix}dice`, `${currentPrefix}roll`] },
          { name: '/slots', desc: 'Play the slot machine', aliases: [`${currentPrefix}slots`] },
          { name: '/rps', desc: 'Rock Paper Scissors', aliases: [`${currentPrefix}rps`] },
          { name: '/trivia', desc: 'Answer trivia questions', aliases: [`${currentPrefix}trivia`, `${currentPrefix}quiz`] },
          { name: '/hangman', desc: 'Play Hangman', aliases: [`${currentPrefix}hangman`] },
          { name: '/wouldyourather', desc: 'Would you rather...', aliases: [`${currentPrefix}wyr`] },
          { name: '/truthordare', desc: 'Truth or Dare', aliases: [`${currentPrefix}tod`] },
        ],
      },
      fun: {
        emoji: '😂',
        name: 'Fun & Jokes',
        commands: [
          { name: '/joke', desc: 'Jokes in 14+ languages!', aliases: [`${currentPrefix}joke`] },
          { name: '/dadjoke', desc: 'Classic dad jokes', aliases: [`${currentPrefix}dadjoke`] },
          { name: '/jokeoftheday', desc: 'Daily joke', aliases: [`${currentPrefix}jotd`] },
          { name: '/meme', desc: 'Random memes', aliases: [`${currentPrefix}meme`] },
          { name: '/gay', desc: 'Gay meter', aliases: [`${currentPrefix}gay`] },
          { name: '/marriage', desc: 'Ship users', aliases: [`${currentPrefix}ship`] },
        ],
      },
      music: {
        emoji: '🎵',
        name: 'Music',
        commands: [
          { name: '/play', desc: 'Play a song', aliases: [`${currentPrefix}play`, `${currentPrefix}p`] },
          { name: '/skip', desc: 'Skip song', aliases: [`${currentPrefix}skip`] },
          { name: '/stop', desc: 'Stop music', aliases: [`${currentPrefix}stop`] },
          { name: '/pause', desc: 'Pause', aliases: [`${currentPrefix}pause`] },
          { name: '/resume', desc: 'Resume', aliases: [`${currentPrefix}resume`] },
          { name: '/queue', desc: 'View queue', aliases: [`${currentPrefix}queue`] },
          { name: '/nowplaying', desc: 'Current song', aliases: [`${currentPrefix}np`] },
        ],
      },
      economy: {
        emoji: '🥚',
        name: 'Economy',
        commands: [
          { name: '/balance', desc: 'Check balance', aliases: [`${currentPrefix}bal`] },
          { name: '/daily', desc: 'Daily reward', aliases: [`${currentPrefix}daily`] },
          { name: '/gather', desc: 'Gather eggs', aliases: [`${currentPrefix}gather`] },
          { name: '/rob', desc: 'Rob eggs', aliases: [`${currentPrefix}rob`] },
          { name: '/give', desc: 'Give eggs', aliases: [`${currentPrefix}give`] },
          { name: '/leaderboard', desc: 'Egg leaderboard', aliases: [`${currentPrefix}lb`] },
        ],
      },
    };
    
    const cat = categories[category];
    if (!cat) return;
    
    const commandList = cat.commands.map(cmd => {
      const aliasText = cmd.aliases.length > 0 ? ` *(${cmd.aliases.join(', ')})*` : '';
      return `**${cmd.name}** - ${cmd.desc}${aliasText}`;
    }).join('\n');
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${cat.emoji} ${cat.name} Commands`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(commandList)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*Prefix: ${currentPrefix} | All commands have prefix alternatives!*`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
  },
};
