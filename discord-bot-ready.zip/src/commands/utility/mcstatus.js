import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ThumbnailBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import https from 'https';

export default {
  data: new SlashCommandBuilder()
    .setName('mcstatus')
    .setDescription('Check the status of a Minecraft server')
    .addStringOption(option =>
      option.setName('server')
        .setDescription('Server address (e.g., play.hypixel.net or mc.server.com:25565)')
        .setRequired(true)),
  
  cooldown: 10,
  
  async execute(interaction) {
    const serverInput = interaction.options.getString('server');
    
    let host = serverInput;
    let port = 25565;
    
    if (serverInput.includes(':')) {
      const parts = serverInput.split(':');
      host = parts[0];
      port = parseInt(parts[1]) || 25565;
    }
    
    await interaction.deferReply();
    
    try {
      const status = await fetchServerStatus(host, port);
      
      if (status.online) {
        const container = new ContainerBuilder()
          .setAccentColor(0x00FF00)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# 🟢 ${host}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(status.motd || 'Minecraft Server')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          );
        
        if (status.icon) {
          container.addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                  `**👥 Players:** ${status.players.online} / ${status.players.max}\n` +
                  `**📌 Version:** ${status.version || 'Unknown'}\n` +
                  `**🌐 Address:** \`${host}:${port}\``
                )
              )
              .setThumbnailAccessory(
                new ThumbnailBuilder().setURL(`https://api.mcsrvstat.us/icon/${host}:${port}`)
              )
          );
        } else {
          container.addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                  `**👥 Players:** ${status.players.online} / ${status.players.max}\n` +
                  `**📌 Version:** ${status.version || 'Unknown'}\n` +
                  `**🌐 Address:** \`${host}:${port}\``
                )
              )
          );
        }
        
        if (status.players.list && status.players.list.length > 0) {
          const playerList = status.players.list.slice(0, 20).join(', ');
          const moreText = status.players.list.length > 20 ? ` and ${status.players.list.length - 20} more...` : '';
          
          container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          );
          container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**🎮 Online Players**\n${playerList}${moreText}`)
          );
        }
        
        container.addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# Server is online!')
        );
        
        await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      } else {
        const container = new ContainerBuilder()
          .setAccentColor(0xFF0000)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# 🔴 ${host}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('Server appears to be offline or unreachable.')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**🌐 Address:** \`${host}:${port}\``)
              )
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('-# Could not connect to server')
          );
        
        await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }
    } catch (error) {
      console.error('MC Status error:', error);
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# ❌ Error')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Could not fetch server status for \`${host}\`.\n\nMake sure the server address is correct.`)
        );
      
      await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  },
};

function fetchServerStatus(host, port) {
  return new Promise((resolve, reject) => {
    const url = `https://api.mcsrvstat.us/2/${host}:${port}`;
    
    https.get(url, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve({
            online: json.online || false,
            players: {
              online: json.players?.online || 0,
              max: json.players?.max || 0,
              list: json.players?.list || []
            },
            version: json.version || 'Unknown',
            motd: json.motd?.clean?.join('\n') || '',
            icon: json.icon || null
          });
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', (e) => {
      reject(e);
    });
  });
}
