import { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { joinVoiceChannel, VoiceConnectionStatus, entersState, EndBehaviorType } from '@discordjs/voice';
import { createWriteStream, existsSync, mkdirSync, unlinkSync, statSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import { getRecordingSettings, setRecordingSettings } from '../../utils/database.js';
import prism from 'prism-media';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const recordingsDir = join(__dirname, '../../../recordings');

if (!existsSync(recordingsDir)) {
  mkdirSync(recordingsDir, { recursive: true });
}

const activeRecordings = new Map();

export default {
  data: new SlashCommandBuilder()
    .setName('recorder')
    .setDescription('Record voice channel conversations')
    .addSubcommand(subcommand =>
      subcommand
        .setName('start')
        .setDescription('Start recording a voice channel')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('The voice channel to record (default: your current channel)')
            .setRequired(false))
        .addIntegerOption(option =>
          option.setName('duration')
            .setDescription('Maximum recording duration in minutes (default: 10, max: 60)')
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(60)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('stop')
        .setDescription('Stop the current recording'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Setup recording log channel and admin role')
        .addChannelOption(option =>
          option.setName('log_channel')
            .setDescription('Channel to send recording logs')
            .setRequired(true))
        .addRoleOption(option =>
          option.setName('admin_role')
            .setDescription('Role that can receive recording DMs')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('status')
        .setDescription('Check if recording is active'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 5,

  async execute(interaction, client) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'start') {
      await handleStart(interaction, client);
    } else if (subcommand === 'stop') {
      await handleStop(interaction, client);
    } else if (subcommand === 'setup') {
      await handleSetup(interaction);
    } else if (subcommand === 'status') {
      await handleStatus(interaction);
    }
  }
};

class AudioMixer {
  constructor(outputStream) {
    this.outputStream = outputStream;
    this.sampleRate = 48000;
    this.channels = 2;
    this.bytesPerSample = 2;
    this.bytesPerFrame = this.bytesPerSample * this.channels;
    
    this.userBuffers = new Map();
    this.mixInterval = null;
    this.isRunning = false;
    
    this.frameMs = 20;
    this.samplesPerFrame = Math.floor(this.sampleRate * (this.frameMs / 1000));
    this.bytesPerMixFrame = this.samplesPerFrame * this.bytesPerFrame;
    
    this.silenceFrame = Buffer.alloc(this.bytesPerMixFrame, 0);
  }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    
    this.mixInterval = setInterval(() => {
      this.mixAndWrite();
    }, this.frameMs);
  }

  stop() {
    this.isRunning = false;
    if (this.mixInterval) {
      clearInterval(this.mixInterval);
      this.mixInterval = null;
    }
  }

  addUser(userId) {
    if (!this.userBuffers.has(userId)) {
      this.userBuffers.set(userId, Buffer.alloc(0));
    }
  }

  removeUser(userId) {
    this.userBuffers.delete(userId);
  }

  pushAudio(userId, chunk) {
    if (!this.userBuffers.has(userId)) {
      this.userBuffers.set(userId, Buffer.alloc(0));
    }
    const currentBuffer = this.userBuffers.get(userId);
    this.userBuffers.set(userId, Buffer.concat([currentBuffer, chunk]));
  }

  mixAndWrite() {
    if (!this.outputStream.writable) return;
    
    const userFrames = [];
    let hasAnyData = false;
    
    for (const [userId, buffer] of this.userBuffers) {
      if (buffer.length >= this.bytesPerMixFrame) {
        userFrames.push({
          userId,
          data: buffer.slice(0, this.bytesPerMixFrame),
          hasSamples: true
        });
        this.userBuffers.set(userId, buffer.slice(this.bytesPerMixFrame));
        hasAnyData = true;
      } else if (buffer.length > 0) {
        const paddedBuffer = Buffer.alloc(this.bytesPerMixFrame, 0);
        buffer.copy(paddedBuffer);
        userFrames.push({
          userId,
          data: paddedBuffer,
          hasSamples: true
        });
        this.userBuffers.set(userId, Buffer.alloc(0));
        hasAnyData = true;
      }
    }

    if (!hasAnyData || userFrames.length === 0) {
      return;
    }

    const mixedBuffer = Buffer.alloc(this.bytesPerMixFrame);
    const numSamples = this.bytesPerMixFrame / this.bytesPerSample;
    const numSources = userFrames.length;

    for (let i = 0; i < numSamples; i++) {
      let mixedValue = 0;
      const offset = i * this.bytesPerSample;
      
      for (const frame of userFrames) {
        if (offset + 1 < frame.data.length) {
          const sample = frame.data.readInt16LE(offset);
          mixedValue += sample;
        }
      }

      if (numSources > 1) {
        mixedValue = mixedValue / Math.sqrt(numSources);
      }

      mixedValue = Math.max(-32768, Math.min(32767, Math.floor(mixedValue)));
      mixedBuffer.writeInt16LE(mixedValue, offset);
    }

    this.outputStream.write(mixedBuffer);
  }

  get activeUsers() {
    return this.userBuffers.size;
  }

  clearBuffers() {
    this.userBuffers.clear();
  }
}

async function handleStart(interaction, client) {
  const settings = getRecordingSettings(interaction.guild.id);
  
  if (!settings.logChannelId) {
    return interaction.reply({
      content: 'Please setup a log channel first using `/recorder setup`!',
      ephemeral: true
    });
  }

  if (activeRecordings.has(interaction.guild.id)) {
    return interaction.reply({
      content: 'A recording is already in progress! Use `/recorder stop` to stop it first.',
      ephemeral: true
    });
  }

  let voiceChannel = interaction.options.getChannel('channel');
  
  if (!voiceChannel) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    voiceChannel = member.voice.channel;
    
    if (!voiceChannel) {
      return interaction.reply({
        content: 'Please specify a voice channel or join one first!',
        ephemeral: true
      });
    }
  }

  if (voiceChannel.type !== 2) {
    return interaction.reply({
      content: 'Please select a voice channel!',
      ephemeral: true
    });
  }

  const maxDuration = interaction.options.getInteger('duration') || 10;

  await interaction.deferReply({ ephemeral: true });

  try {
    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: interaction.guild.id,
      adapterCreator: interaction.guild.voiceAdapterCreator,
      selfDeaf: false,
      selfMute: true
    });

    await entersState(connection, VoiceConnectionStatus.Ready, 30000);

    const timestamp = Date.now();
    const rawFilePath = join(recordingsDir, `recording_${interaction.guild.id}_${timestamp}.pcm`);
    const outputFilePath = join(recordingsDir, `recording_${interaction.guild.id}_${timestamp}.mp3`);

    const writeStream = createWriteStream(rawFilePath);
    const mixer = new AudioMixer(writeStream);
    const userStreams = new Map();

    const receiver = connection.receiver;

    const subscribeToUser = (userId) => {
      if (userStreams.has(userId)) return;

      try {
        const opusStream = receiver.subscribe(userId, {
          end: {
            behavior: EndBehaviorType.Manual
          }
        });

        const decoder = new prism.opus.Decoder({
          rate: 48000,
          channels: 2,
          frameSize: 960
        });

        mixer.addUser(userId);

        opusStream.pipe(decoder);

        decoder.on('data', (chunk) => {
          mixer.pushAudio(userId, chunk);
        });

        decoder.on('error', (err) => {
          console.error(`[Recorder] Decoder error for user ${userId}:`, err.message);
        });

        opusStream.on('error', (err) => {
          console.error(`[Recorder] Stream error for user ${userId}:`, err.message);
        });

        opusStream.on('close', () => {
          userStreams.delete(userId);
          mixer.removeUser(userId);
        });

        userStreams.set(userId, { opusStream, decoder });
        console.log(`[Recorder] Subscribed to user ${userId}`);
      } catch (err) {
        console.error(`[Recorder] Failed to subscribe to user ${userId}:`, err.message);
      }
    };

    const speakingHandler = (userId) => {
      subscribeToUser(userId);
    };

    receiver.speaking.on('start', speakingHandler);

    mixer.start();

    const existingMembers = voiceChannel.members.filter(m => !m.user.bot);
    for (const [memberId] of existingMembers) {
      setTimeout(() => subscribeToUser(memberId), 100);
    }

    const recordingData = {
      connection,
      voiceChannel,
      startTime: Date.now(),
      maxDuration,
      rawFilePath,
      outputFilePath,
      writeStream,
      mixer,
      userStreams,
      startedBy: interaction.user.id,
      timeout: null,
      receiver,
      speakingHandler
    };

    recordingData.timeout = setTimeout(async () => {
      await stopRecording(interaction.guild, client, 'Duration limit reached');
    }, maxDuration * 60 * 1000);

    activeRecordings.set(interaction.guild.id, recordingData);

    const container = new ContainerBuilder()
      .setAccentColor(0xFF0000)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Recording Started')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`Recording **${voiceChannel.name}**\nAll voices will be mixed and captured!`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Channel:** ${voiceChannel}\n**Max Duration:** ${maxDuration} minutes\n**Started By:** ${interaction.user}\n**Users in VC:** ${existingMembers.size} members`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('*Use /recorder stop to end the recording*')
      );

    await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });

    const logChannel = await interaction.guild.channels.fetch(settings.logChannelId);
    if (logChannel) {
      const logContainer = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Recording Started')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`A voice recording has been started in **${voiceChannel.name}**`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Started By:** ${interaction.user}\n**Max Duration:** ${maxDuration} minutes\n**Users:** ${existingMembers.size} members`)
        );

      await logChannel.send({ components: [logContainer], flags: MessageFlags.IsComponentsV2 });
    }

  } catch (error) {
    console.error('Error starting recording:', error);
    activeRecordings.delete(interaction.guild.id);
    await interaction.editReply({
      content: 'Failed to start recording. Make sure I have permission to join the voice channel!'
    });
  }
}

async function handleStop(interaction, client) {
  if (!activeRecordings.has(interaction.guild.id)) {
    return interaction.reply({
      content: 'No recording is currently in progress!',
      ephemeral: true
    });
  }

  await interaction.deferReply({ ephemeral: true });
  await stopRecording(interaction.guild, client, 'Manually stopped', interaction);
}

async function stopRecording(guild, client, reason, interaction = null) {
  const recording = activeRecordings.get(guild.id);
  if (!recording) return;

  activeRecordings.delete(guild.id);

  if (recording.timeout) {
    clearTimeout(recording.timeout);
  }

  if (recording.receiver && recording.speakingHandler) {
    recording.receiver.speaking.removeListener('start', recording.speakingHandler);
  }

  if (recording.mixer) {
    recording.mixer.stop();
    recording.mixer.clearBuffers();
  }

  for (const [userId, streams] of recording.userStreams) {
    try {
      if (streams.decoder) streams.decoder.destroy();
      if (streams.opusStream) streams.opusStream.destroy();
    } catch (e) {}
  }

  recording.writeStream.end();

  if (recording.connection) {
    recording.connection.destroy();
  }

  const duration = Math.floor((Date.now() - recording.startTime) / 1000);

  await new Promise(resolve => setTimeout(resolve, 2000));

  try {
    const rawStats = statSync(recording.rawFilePath);
    if (rawStats.size < 1000) {
      throw new Error('Recording too short or no audio captured');
    }

    await convertToMp3(recording.rawFilePath, recording.outputFilePath);

    const fileStats = statSync(recording.outputFilePath);
    const fileSizeMB = (fileStats.size / (1024 * 1024)).toFixed(2);

    const settings = getRecordingSettings(guild.id);

    const container = new ContainerBuilder()
      .setAccentColor(0x00FF00)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Recording Complete')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`Voice recording from **${recording.voiceChannel.name}**`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Duration:** ${formatDuration(duration)}\n**Size:** ${fileSizeMB} MB\n**Reason Stopped:** ${reason}\n**Started By:** <@${recording.startedBy}>`)
      );

    const attachment = new AttachmentBuilder(recording.outputFilePath, { 
      name: `recording_${guild.name}_${new Date().toISOString().slice(0,10)}.mp3` 
    });

    const logChannel = await guild.channels.fetch(settings.logChannelId);
    if (logChannel) {
      await logChannel.send({ components: [container], files: [attachment], flags: MessageFlags.IsComponentsV2 });
    }

    if (settings.adminRoleId) {
      const adminRole = await guild.roles.fetch(settings.adminRoleId);
      if (adminRole) {
        const admins = adminRole.members;
        for (const [adminId, admin] of admins) {
          try {
            const dmContainer = new ContainerBuilder()
              .setAccentColor(0x0099FF)
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# Voice Recording - ${guild.name}`)
              )
              .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
              )
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`A recording from **${recording.voiceChannel.name}** has been completed.`)
              )
              .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
              )
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Duration:** ${formatDuration(duration)}\n**Reason:** ${reason}`)
              );

            const fileStats2 = statSync(recording.outputFilePath);
            if (fileStats2.size < 8 * 1024 * 1024) {
              const dmAttachment = new AttachmentBuilder(recording.outputFilePath, { 
                name: `recording_${guild.name}_${new Date().toISOString().slice(0,10)}.mp3` 
              });
              await admin.send({ components: [dmContainer], files: [dmAttachment], flags: MessageFlags.IsComponentsV2 });
            } else {
              await admin.send({ 
                components: [dmContainer], 
                content: 'Recording file is too large to send via DM. Please check the log channel.',
                flags: MessageFlags.IsComponentsV2
              });
            }
          } catch (error) {
            console.log(`Could not DM admin ${adminId}:`, error.message);
          }
        }
      }
    }

    if (interaction) {
      await interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    setTimeout(() => {
      try {
        if (existsSync(recording.rawFilePath)) unlinkSync(recording.rawFilePath);
        if (existsSync(recording.outputFilePath)) unlinkSync(recording.outputFilePath);
      } catch (error) {
        console.error('Error cleaning up recording files:', error);
      }
    }, 60000);

  } catch (error) {
    console.error('Error processing recording:', error);
    
    const errorContainer = new ContainerBuilder()
      .setAccentColor(0xFF0000)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Recording Error')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('Failed to process the recording. The audio may have been too short or no one spoke during the recording.')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Duration:** ${formatDuration(duration)}\n**Tip:** Make sure people are speaking in the voice channel while recording.`)
      );

    if (interaction) {
      await interaction.editReply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
    }

    const settings = getRecordingSettings(guild.id);
    try {
      const logChannel = await guild.channels.fetch(settings.logChannelId);
      if (logChannel) {
        await logChannel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
      }
    } catch (e) {}

    try {
      if (existsSync(recording.rawFilePath)) unlinkSync(recording.rawFilePath);
      if (existsSync(recording.outputFilePath)) unlinkSync(recording.outputFilePath);
    } catch (e) {}
  }
}

async function handleSetup(interaction) {
  const logChannel = interaction.options.getChannel('log_channel');
  const adminRole = interaction.options.getRole('admin_role');

  const settings = {
    logChannelId: logChannel.id,
    adminRoleId: adminRole?.id || null
  };

  setRecordingSettings(interaction.guild.id, settings);

  const container = new ContainerBuilder()
    .setAccentColor(0x00FF00)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# Recording Settings Updated')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Log Channel:** ${logChannel}\n**Admin Role:** ${adminRole ? `${adminRole}` : 'None set'}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('*Admins with the specified role will receive recordings via DM*')
    );

  await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
}

async function handleStatus(interaction) {
  const recording = activeRecordings.get(interaction.guild.id);

  if (!recording) {
    return interaction.reply({
      content: 'No recording is currently in progress.',
      ephemeral: true
    });
  }

  const elapsed = Math.floor((Date.now() - recording.startTime) / 1000);
  const remaining = (recording.maxDuration * 60) - elapsed;

  const container = new ContainerBuilder()
    .setAccentColor(0xFF0000)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# Recording In Progress')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Channel:** ${recording.voiceChannel}\n**Elapsed:** ${formatDuration(elapsed)}\n**Remaining:** ${formatDuration(remaining)}\n**Started By:** <@${recording.startedBy}>\n**Active Users:** ${recording.userStreams.size}`)
    );

  await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
}

function formatDuration(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

async function convertToMp3(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    const ffmpeg = spawn('ffmpeg', [
      '-y',
      '-f', 's16le',
      '-ar', '48000',
      '-ac', '2',
      '-i', inputPath,
      '-c:a', 'libmp3lame',
      '-b:a', '128k',
      '-af', 'volume=1.5,highpass=f=80,lowpass=f=12000,dynaudnorm',
      outputPath
    ]);

    let stderr = '';
    ffmpeg.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    ffmpeg.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        console.error('[FFmpeg] Error:', stderr);
        reject(new Error(`FFmpeg exited with code ${code}`));
      }
    });

    ffmpeg.on('error', (error) => {
      reject(error);
    });
  });
}
