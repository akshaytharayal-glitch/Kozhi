import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ThumbnailBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import { getUserStats, calculateXPForLevel } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('level')
    .setDescription('Check your level and XP')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to check level for')
        .setRequired(false)),
  
  cooldown: 5,
  
  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const guildId = interaction.guild.id;
    const stats = getUserStats(guildId, target.id);
    
    const currentLevelXP = calculateXPForLevel(stats.level);
    const nextLevelXP = calculateXPForLevel(stats.level + 1);
    const progressXP = stats.xp - currentLevelXP + calculateXPForLevel(stats.level);
    const neededXP = nextLevelXP;
    const progress = Math.min(100, Math.floor((stats.xp / nextLevelXP) * 100));
    
    const progressBar = createProgressBar(progress);
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${target.username}'s Level`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**📊 Level:** ${stats.level}\n` +
              `**✨ Total XP:** ${stats.xp.toLocaleString()}\n` +
              `**💬 Messages:** ${stats.messages.toLocaleString()}`
            )
          )
          .setThumbnailAccessory(
            new ThumbnailBuilder().setURL(target.displayAvatarURL({ size: 256 }))
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `**Progress to Next Level**\n` +
          `${progressBar}\n` +
          `${stats.xp.toLocaleString()} / ${nextLevelXP.toLocaleString()} XP (${progress}%)`
        )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('-# Keep chatting to level up!')
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};

function createProgressBar(percent) {
  const filled = Math.floor(percent / 5);
  const empty = 20 - filled;
  return '▓'.repeat(filled) + '░'.repeat(empty);
}
