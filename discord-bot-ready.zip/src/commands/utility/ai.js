import { SlashCommandBuilder, PermissionFlagsBits, ChannelType, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const settingsPath = path.join(__dirname, '../../../data/aiChannels.json');

function getSettings() {
  try {
    if (!fs.existsSync(settingsPath)) {
      fs.writeFileSync(settingsPath, '{}');
      return {};
    }
    return JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
  } catch {
    return {};
  }
}

function saveSettings(settings) {
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
}

export default {
  data: new SlashCommandBuilder()
    .setName('ai')
    .setDescription('AI Chat setup commands (Owner only)')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Set up AI chat in a channel')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('The channel for AI chat')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('disable')
        .setDescription('Disable AI chat in the server'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('status')
        .setDescription('Check AI chat status')),
  
  async execute(interaction) {
    const ownerId = process.env.OWNER_ID;
    
    if (!ownerId || interaction.user.id !== ownerId) {
      return interaction.reply({ 
        content: '❌ Only the bot owner can use this command!', 
        flags: 64 
      });
    }
    
    const subcommand = interaction.options.getSubcommand();
    const guildId = interaction.guildId;
    const settings = getSettings();
    
    if (subcommand === 'setup') {
      const channel = interaction.options.getChannel('channel');
      
      if (!process.env.OPENAI_API_KEY) {
        return interaction.reply({
          content: '❌ OpenAI API key is not configured! Please add `OPENAI_API_KEY` to your secrets.',
          flags: 64
        });
      }
      
      settings[guildId] = {
        channelId: channel.id,
        enabled: true,
        setupAt: new Date().toISOString()
      };
      saveSettings(settings);
      
      const container = new ContainerBuilder()
        .setAccentColor(0x00D166)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 🤖 AI Chat Enabled')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`AI chat has been set up in ${channel}!\n\nAnyone who sends a message in that channel will receive an AI response.`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`**Channel:** ${channel}\n**Status:** ✅ Active`)
            )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# The AI can understand and respond in multiple languages including Indian languages')
        );
      
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      
    } else if (subcommand === 'disable') {
      if (settings[guildId]) {
        settings[guildId].enabled = false;
        saveSettings(settings);
      }
      
      const container = new ContainerBuilder()
        .setAccentColor(0xED4245)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 🤖 AI Chat Disabled')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('AI chat has been disabled for this server.')
        );
      
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      
    } else if (subcommand === 'status') {
      const guildSettings = settings[guildId];
      
      if (!guildSettings || !guildSettings.enabled) {
        return interaction.reply({
          content: '❌ AI chat is not enabled in this server. Use `/ai setup` to enable it.',
          flags: 64
        });
      }
      
      const channel = interaction.guild.channels.cache.get(guildSettings.channelId);
      
      const container = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 🤖 AI Chat Status')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(
                `**Status:** ${guildSettings.enabled ? '✅ Active' : '❌ Disabled'}\n` +
                `**Channel:** ${channel ? `${channel}` : 'Channel not found'}\n` +
                `**Setup Date:** ${guildSettings.setupAt ? new Date(guildSettings.setupAt).toLocaleDateString() : 'Unknown'}`
              )
            )
        );
      
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  },
};

export function getAIChannelSettings() {
  return getSettings();
}
