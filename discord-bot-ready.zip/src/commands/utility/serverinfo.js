import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('View server information'),
  
  async execute(interaction) {
    const { guild } = interaction;
    
    const verificationLevels = {
      0: 'None',
      1: 'Low',
      2: 'Medium',
      3: 'High',
      4: 'Very High',
    };
    
    const createdAt = Math.floor(guild.createdTimestamp / 1000);
    
    let infoContent = `**Owner:** <@${guild.ownerId}>\n**Created:** <t:${createdAt}:R>\n**Server ID:** ${guild.id}\n\n`;
    infoContent += `**Members:** ${guild.memberCount}\n**Channels:** ${guild.channels.cache.size}\n**Emojis:** ${guild.emojis.cache.size}\n\n`;
    infoContent += `**Roles:** ${guild.roles.cache.size}\n**Verification:** ${verificationLevels[guild.verificationLevel]}\n**Boosts:** ${guild.premiumSubscriptionCount || 0}`;
    
    if (guild.description) {
      infoContent = `*${guild.description}*\n\n` + infoContent;
    }
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${guild.name}`)
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(infoContent)
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*Requested by ${interaction.user.username}*`)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
