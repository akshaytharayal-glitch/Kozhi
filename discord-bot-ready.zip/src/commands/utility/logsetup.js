import { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SectionBuilder, ThumbnailBuilder, ButtonBuilder, ButtonStyle, ChannelType, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import { getLogSettings, setLogSettings } from '../../utils/database.js';

const LOG_TYPES = {
  memberJoin: { name: 'Member Join', emoji: '📥', description: 'When members join the server' },
  memberLeave: { name: 'Member Leave', emoji: '📤', description: 'When members leave the server' },
  memberBan: { name: 'Member Ban', emoji: '🔨', description: 'When members are banned' },
  memberUnban: { name: 'Member Unban', emoji: '🔓', description: 'When members are unbanned' },
  messageDelete: { name: 'Message Delete', emoji: '🗑️', description: 'When messages are deleted' },
  messageEdit: { name: 'Message Edit', emoji: '✏️', description: 'When messages are edited' },
  channelCreate: { name: 'Channel Create', emoji: '➕', description: 'When channels are created' },
  channelDelete: { name: 'Channel Delete', emoji: '➖', description: 'When channels are deleted' },
  roleCreate: { name: 'Role Create', emoji: '🏷️', description: 'When roles are created' },
  roleDelete: { name: 'Role Delete', emoji: '🗑️', description: 'When roles are deleted' },
  voiceJoin: { name: 'Voice Join', emoji: '🎤', description: 'When members join voice channels' },
  voiceLeave: { name: 'Voice Leave', emoji: '🔇', description: 'When members leave voice channels' },
  nicknameChange: { name: 'Nickname Change', emoji: '📝', description: 'When nicknames are changed' },
  roleUpdate: { name: 'Role Update', emoji: '🔄', description: 'When member roles are updated' },
  inviteCreate: { name: 'Invite Create', emoji: '🔗', description: 'When invites are created' },
  commandUsage: { name: 'Command Usage', emoji: '⚡', description: 'When bot commands are used' }
};

export default {
  data: new SlashCommandBuilder()
    .setName('logsetup')
    .setDescription('Configure server logging settings')
    .addSubcommand(sub =>
      sub.setName('channel')
        .setDescription('Set the log channel')
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('Channel to send logs to')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('enable')
        .setDescription('Enable a log type')
        .addStringOption(opt =>
          opt.setName('type')
            .setDescription('Type of log to enable')
            .setRequired(true)
            .addChoices(
              { name: '📥 Member Join', value: 'memberJoin' },
              { name: '📤 Member Leave', value: 'memberLeave' },
              { name: '🔨 Member Ban', value: 'memberBan' },
              { name: '🔓 Member Unban', value: 'memberUnban' },
              { name: '🗑️ Message Delete', value: 'messageDelete' },
              { name: '✏️ Message Edit', value: 'messageEdit' },
              { name: '➕ Channel Create', value: 'channelCreate' },
              { name: '➖ Channel Delete', value: 'channelDelete' },
              { name: '🏷️ Role Create', value: 'roleCreate' },
              { name: '🗑️ Role Delete', value: 'roleDelete' },
              { name: '🎤 Voice Join', value: 'voiceJoin' },
              { name: '🔇 Voice Leave', value: 'voiceLeave' },
              { name: '📝 Nickname Change', value: 'nicknameChange' },
              { name: '🔄 Role Update', value: 'roleUpdate' },
              { name: '🔗 Invite Create', value: 'inviteCreate' },
              { name: '⚡ Command Usage', value: 'commandUsage' }
            )))
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('Disable a log type')
        .addStringOption(opt =>
          opt.setName('type')
            .setDescription('Type of log to disable')
            .setRequired(true)
            .addChoices(
              { name: '📥 Member Join', value: 'memberJoin' },
              { name: '📤 Member Leave', value: 'memberLeave' },
              { name: '🔨 Member Ban', value: 'memberBan' },
              { name: '🔓 Member Unban', value: 'memberUnban' },
              { name: '🗑️ Message Delete', value: 'messageDelete' },
              { name: '✏️ Message Edit', value: 'messageEdit' },
              { name: '➕ Channel Create', value: 'channelCreate' },
              { name: '➖ Channel Delete', value: 'channelDelete' },
              { name: '🏷️ Role Create', value: 'roleCreate' },
              { name: '🗑️ Role Delete', value: 'roleDelete' },
              { name: '🎤 Voice Join', value: 'voiceJoin' },
              { name: '🔇 Voice Leave', value: 'voiceLeave' },
              { name: '📝 Nickname Change', value: 'nicknameChange' },
              { name: '🔄 Role Update', value: 'roleUpdate' },
              { name: '🔗 Invite Create', value: 'inviteCreate' },
              { name: '⚡ Command Usage', value: 'commandUsage' }
            )))
    .addSubcommand(sub =>
      sub.setName('enableall')
        .setDescription('Enable all log types'))
    .addSubcommand(sub =>
      sub.setName('disableall')
        .setDescription('Disable all log types'))
    .addSubcommand(sub =>
      sub.setName('view')
        .setDescription('View current log settings'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction, client) {
    const subcommand = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    let settings = getLogSettings(guildId);

    if (subcommand === 'channel') {
      const channel = interaction.options.getChannel('channel');
      settings.channelId = channel.id;
      setLogSettings(guildId, settings);

      const container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Log Channel Set')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`All enabled logs will now be sent to ${channel}`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# Use /logsetup view to see enabled logs')
        );

      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    if (subcommand === 'enable') {
      const type = interaction.options.getString('type');
      if (!settings.enabled) settings.enabled = {};
      settings.enabled[type] = true;
      setLogSettings(guildId, settings);

      const logInfo = LOG_TYPES[type];
      const container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`# ${logInfo.emoji} Log Enabled`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**${logInfo.name}** logging is now enabled!\n\n${logInfo.description}`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(settings.channelId ? `-# Logs will be sent to <#${settings.channelId}>` : '-# Set a log channel with /logsetup channel')
        );

      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    if (subcommand === 'disable') {
      const type = interaction.options.getString('type');
      if (!settings.enabled) settings.enabled = {};
      settings.enabled[type] = false;
      setLogSettings(guildId, settings);

      const logInfo = LOG_TYPES[type];
      const container = new ContainerBuilder()
        .setAccentColor(0xFF6B6B)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`# ${logInfo.emoji} Log Disabled`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**${logInfo.name}** logging is now disabled.`)
        );

      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    if (subcommand === 'enableall') {
      if (!settings.enabled) settings.enabled = {};
      for (const type of Object.keys(LOG_TYPES)) {
        settings.enabled[type] = true;
      }
      setLogSettings(guildId, settings);

      const container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# All Logs Enabled')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`All **${Object.keys(LOG_TYPES).length}** log types have been enabled!`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(settings.channelId ? `-# Logs will be sent to <#${settings.channelId}>` : '-# Set a log channel with /logsetup channel')
        );

      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    if (subcommand === 'disableall') {
      if (!settings.enabled) settings.enabled = {};
      for (const type of Object.keys(LOG_TYPES)) {
        settings.enabled[type] = false;
      }
      setLogSettings(guildId, settings);

      const container = new ContainerBuilder()
        .setAccentColor(0xFF6B6B)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# All Logs Disabled')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('All log types have been disabled.')
        );

      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    if (subcommand === 'view') {
      const enabledLogs = [];
      const disabledLogs = [];

      for (const [type, info] of Object.entries(LOG_TYPES)) {
        if (settings.enabled?.[type]) {
          enabledLogs.push(`${info.emoji} ${info.name}`);
        } else {
          disabledLogs.push(`${info.emoji} ${info.name}`);
        }
      }

      const container = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Log Settings')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**Log Channel:** ${settings.channelId ? `<#${settings.channelId}>` : 'Not set'}`
          )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**✅ Enabled Logs (${enabledLogs.length}):**\n${enabledLogs.length > 0 ? enabledLogs.join('\n') : 'None'}`
          )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**❌ Disabled Logs (${disabledLogs.length}):**\n${disabledLogs.length > 0 ? disabledLogs.join('\n') : 'None'}`
          )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`-# ${interaction.guild.name}`)
        );

      return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  }
};

export { LOG_TYPES };
