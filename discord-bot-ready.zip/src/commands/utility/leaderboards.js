import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import { getStatsLeaderboard, getLeaderboard } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('leaderboards')
    .setDescription('View various leaderboards')
    .addStringOption(option =>
      option.setName('type')
        .setDescription('Type of leaderboard to view')
        .setRequired(true)
        .addChoices(
          { name: '📊 Levels', value: 'level' },
          { name: '💬 Messages', value: 'messages' },
          { name: '🎤 Voice Time', value: 'voice' },
          { name: '📨 Invites', value: 'invites' },
          { name: '🥚 Eggs (Economy)', value: 'eggs' },
          { name: '⏱️ Active Time', value: 'active' }
        )),
  
  cooldown: 10,
  
  async execute(interaction) {
    const type = interaction.options.getString('type');
    const guildId = interaction.guild.id;
    
    let leaderboard;
    let title;
    let color;
    let formatValue;
    
    if (type === 'eggs') {
      leaderboard = getLeaderboard(guildId, 10).map(entry => ({
        userId: entry.userId,
        value: entry.balance
      }));
      title = '🥚 Egg Leaderboard';
      color = 0xFFD700;
      formatValue = (val) => `${val.toLocaleString()} eggs`;
    } else {
      const stats = getStatsLeaderboard(guildId, type, 10);
      
      switch (type) {
        case 'level':
          leaderboard = stats.map(s => ({ userId: s.userId, value: s.level, xp: s.xp }));
          title = '📊 Level Leaderboard';
          color = 0x5865F2;
          formatValue = (val, entry) => `Level ${val} (${entry.xp?.toLocaleString() || 0} XP)`;
          break;
        case 'messages':
          leaderboard = stats.map(s => ({ userId: s.userId, value: s.messages || 0 }));
          title = '💬 Messages Leaderboard';
          color = 0x00FF00;
          formatValue = (val) => `${val.toLocaleString()} messages`;
          break;
        case 'voice':
          leaderboard = stats.map(s => ({ userId: s.userId, value: s.voiceTime || 0 }));
          title = '🎤 Voice Time Leaderboard';
          color = 0xFF69B4;
          formatValue = (val) => {
            const hours = (val / 3600).toFixed(1);
            return `${hours} hours`;
          };
          break;
        case 'invites':
          leaderboard = stats.map(s => ({ userId: s.userId, value: s.invites || 0 }));
          title = '📨 Invites Leaderboard';
          color = 0x00D4FF;
          formatValue = (val) => `${val} invites`;
          break;
        case 'active':
          leaderboard = stats.map(s => ({ 
            userId: s.userId, 
            value: (s.voiceTime || 0) + ((s.messages || 0) * 60),
            voiceTime: s.voiceTime || 0,
            messages: s.messages || 0
          }));
          title = '⏱️ Active Time Leaderboard';
          color = 0x9B59B6;
          formatValue = (val, entry) => {
            const hours = (val / 3600).toFixed(1);
            return `${hours} hours active (${entry.messages?.toLocaleString() || 0} msgs, ${((entry.voiceTime || 0) / 3600).toFixed(1)}h VC)`;
          };
          break;
      }
    }
    
    if (!leaderboard || leaderboard.length === 0) {
      return interaction.reply({
        content: `📊 No data yet for this leaderboard!`,
        ephemeral: true
      });
    }
    
    const medals = ['🥇', '🥈', '🥉'];
    
    const leaderboardText = await Promise.all(
      leaderboard.map(async (entry, index) => {
        try {
          const user = await interaction.client.users.fetch(entry.userId);
          const medal = medals[index] || `**${index + 1}.**`;
          const valueStr = formatValue(entry.value, entry);
          return `${medal} ${user.username} - ${valueStr}`;
        } catch {
          const valueStr = formatValue(entry.value, entry);
          return `**${index + 1}.** Unknown User - ${valueStr}`;
        }
      })
    );
    
    const container = new ContainerBuilder()
      .setAccentColor(color)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${title}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(leaderboardText.join('\n') || 'No entries yet!')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`-# ${interaction.guild.name}`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
