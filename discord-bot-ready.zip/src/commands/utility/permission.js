import { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { 
  getOwnerCommands, 
  setOwnerCommand, 
  grantRolePermission, 
  revokeRolePermission, 
  getAllPermissions,
  isBotOwner 
} from '../../utils/permissions.js';

export default {
  data: new SlashCommandBuilder()
    .setName('permission')
    .setDescription('Manage command permissions (Owner only)')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setowner')
        .setDescription('Set a command as owner-only')
        .addStringOption(option =>
          option.setName('command')
            .setDescription('The command name to make owner-only')
            .setRequired(true)
            .setAutocomplete(true))
        .addBooleanOption(option =>
          option.setName('enabled')
            .setDescription('Enable or disable owner-only restriction')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('grant')
        .setDescription('Grant a role permission to use an owner-only command')
        .addStringOption(option =>
          option.setName('command')
            .setDescription('The owner-only command')
            .setRequired(true)
            .setAutocomplete(true))
        .addRoleOption(option =>
          option.setName('role')
            .setDescription('The role to grant permission to')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('revoke')
        .setDescription('Revoke a role\'s permission to use an owner-only command')
        .addStringOption(option =>
          option.setName('command')
            .setDescription('The owner-only command')
            .setRequired(true)
            .setAutocomplete(true))
        .addRoleOption(option =>
          option.setName('role')
            .setDescription('The role to revoke permission from')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('List all permission settings'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  cooldown: 3,
  
  async autocomplete(interaction) {
    const focused = interaction.options.getFocused(true);
    const subcommand = interaction.options.getSubcommand();
    
    if (focused.name === 'command') {
      let commands = [];
      
      if (subcommand === 'setowner') {
        commands = Array.from(interaction.client.commands.keys());
      } else {
        commands = getOwnerCommands();
      }
      
      const filtered = commands
        .filter(cmd => cmd.toLowerCase().includes(focused.value.toLowerCase()))
        .slice(0, 25);
      
      await interaction.respond(
        filtered.map(cmd => ({ name: cmd, value: cmd }))
      );
    }
  },
  
  async execute(interaction, client) {
    const isServerOwner = interaction.user.id === interaction.guild.ownerId;
    const isBotOwnerUser = isBotOwner(interaction.user.id);
    
    if (!isServerOwner && !isBotOwnerUser) {
      const container = new ContainerBuilder()
        .setAccentColor(0xFF6B6B)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Access Denied')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('Only the server owner or bot owner can manage command permissions.')
        );
      
      return interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        ephemeral: true
      });
    }
    
    const subcommand = interaction.options.getSubcommand();
    
    switch (subcommand) {
      case 'setowner':
        await handleSetOwner(interaction, client);
        break;
      case 'grant':
        await handleGrant(interaction, client);
        break;
      case 'revoke':
        await handleRevoke(interaction, client);
        break;
      case 'list':
        await handleList(interaction, client);
        break;
    }
  },
};

async function handleSetOwner(interaction, client) {
  const commandName = interaction.options.getString('command').toLowerCase();
  const enabled = interaction.options.getBoolean('enabled');
  
  if (!client.commands.has(commandName)) {
    const container = new ContainerBuilder()
      .setAccentColor(0xFF6B6B)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Command Not Found')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`The command \`/${commandName}\` does not exist.`)
      );
    
    return interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      ephemeral: true
    });
  }
  
  if (commandName === 'permission') {
    const container = new ContainerBuilder()
      .setAccentColor(0xFF6B6B)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Invalid Command')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('You cannot modify permissions for the permission command itself.')
      );
    
    return interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      ephemeral: true
    });
  }
  
  const success = setOwnerCommand(commandName, enabled);
  
  if (success) {
    const container = new ContainerBuilder()
      .setAccentColor(0x7C3AED)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Permission Updated')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(enabled 
          ? `The command \`/${commandName}\` is now **owner-only**.\nOnly you and roles you grant permission to can use it.`
          : `The command \`/${commandName}\` is now **available to everyone**.`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  } else {
    const container = new ContainerBuilder()
      .setAccentColor(0xFF6B6B)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Error')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('Failed to update permission settings.')
      );
    
    await interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      ephemeral: true
    });
  }
}

async function handleGrant(interaction, client) {
  const commandName = interaction.options.getString('command').toLowerCase();
  const role = interaction.options.getRole('role');
  
  const ownerCommands = getOwnerCommands();
  if (!ownerCommands.includes(commandName)) {
    const container = new ContainerBuilder()
      .setAccentColor(0xFF6B6B)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Not Owner-Only')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`The command \`/${commandName}\` is not set as owner-only.\nUse \`/permission setowner\` first.`)
      );
    
    return interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      ephemeral: true
    });
  }
  
  const success = grantRolePermission(interaction.guild.id, role.id, commandName);
  
  if (success) {
    const container = new ContainerBuilder()
      .setAccentColor(0x7C3AED)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Permission Granted')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`The role ${role} can now use \`/${commandName}\`.`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  } else {
    const container = new ContainerBuilder()
      .setAccentColor(0xFF6B6B)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Error')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('Failed to grant permission.')
      );
    
    await interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      ephemeral: true
    });
  }
}

async function handleRevoke(interaction, client) {
  const commandName = interaction.options.getString('command').toLowerCase();
  const role = interaction.options.getRole('role');
  
  const success = revokeRolePermission(interaction.guild.id, role.id, commandName);
  
  if (success) {
    const container = new ContainerBuilder()
      .setAccentColor(0x7C3AED)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Permission Revoked')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`The role ${role} can no longer use \`/${commandName}\`.`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  } else {
    const container = new ContainerBuilder()
      .setAccentColor(0xFF6B6B)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Error')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('Failed to revoke permission.')
      );
    
    await interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      ephemeral: true
    });
  }
}

async function handleList(interaction, client) {
  const permissions = getAllPermissions(interaction.guild.id);
  
  const ownerCommands = permissions.ownerCommands;
  const rolePermissions = permissions.rolePermissions;
  
  let description = '';
  
  if (ownerCommands.length === 0) {
    description = 'No commands are currently set as owner-only.';
  } else {
    description = '**Owner-Only Commands:**\n';
    
    for (const cmd of ownerCommands) {
      const allowedRoles = rolePermissions[cmd] || [];
      description += `\n\`/${cmd}\``;
      
      if (allowedRoles.length > 0) {
        const roleNames = allowedRoles.map(roleId => `<@&${roleId}>`).join(', ');
        description += `\n  Allowed roles: ${roleNames}`;
      } else {
        description += '\n  No additional roles granted';
      }
    }
  }
  
  const container = new ContainerBuilder()
    .setAccentColor(0x7C3AED)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# Permission Settings')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(description)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('*Use /permission setowner to add commands*')
    );
  
  await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
}
