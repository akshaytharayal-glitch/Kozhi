import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View user information')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to view info for')
        .setRequired(false)),
  
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);
    
    const createdAt = Math.floor(user.createdTimestamp / 1000);
    
    let infoContent = `**User ID:** ${user.id}\n**Account Created:** <t:${createdAt}:R>\n**Bot:** ${user.bot ? 'Yes' : 'No'}`;
    
    if (member) {
      const joinedAt = Math.floor(member.joinedTimestamp / 1000);
      const roles = member.roles.cache
        .filter(role => role.id !== interaction.guild.id)
        .sort((a, b) => b.position - a.position)
        .map(role => role.toString())
        .slice(0, 10);
      
      infoContent += `\n\n**Joined Server:** <t:${joinedAt}:R>\n**Nickname:** ${member.nickname || 'None'}\n**Color:** ${member.displayHexColor}`;
      infoContent += `\n\n**Roles [${member.roles.cache.size - 1}]:** ${roles.length ? roles.join(' ') : 'None'}`;
      
      if (member.premiumSince) {
        const boostingSince = Math.floor(member.premiumSinceTimestamp / 1000);
        infoContent += `\n\n**Boosting Since:** <t:${boostingSince}:R>`;
      }
    }
    
    const container = new ContainerBuilder()
      .setAccentColor(member?.displayColor || 0x5865F2)
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${user.username}`)
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(infoContent)
          )
      )
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*Requested by ${interaction.user.username}*`)
          )
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
