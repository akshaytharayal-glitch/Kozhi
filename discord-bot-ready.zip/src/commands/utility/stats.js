import { SlashCommandBuilder, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ThumbnailBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import { getUserStats, calculateXPForLevel } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View detailed statistics for a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to view stats for')
        .setRequired(false)),
  
  cooldown: 5,
  
  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const guildId = interaction.guild.id;
    const stats = getUserStats(guildId, target.id);
    
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    const joinedAt = member?.joinedAt || new Date(stats.joinedAt);
    const daysInServer = Math.floor((Date.now() - joinedAt.getTime()) / (1000 * 60 * 60 * 24));
    
    const voiceHours = (stats.voiceTime / 3600).toFixed(2);
    const voiceMinutes = Math.floor((stats.voiceTime % 3600) / 60);
    
    const nextLevelXP = calculateXPForLevel(stats.level + 1);
    const progress = Math.min(100, Math.floor((stats.xp / nextLevelXP) * 100));
    
    const container = new ContainerBuilder()
      .setAccentColor(0x00D4FF)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# 📊 ${target.username}'s Statistics`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**🎮 Level & XP**\n` +
              `Level **${stats.level}** (${stats.xp.toLocaleString()} XP)\n` +
              `Progress: ${progress}% to Level ${stats.level + 1}`
            )
          )
          .setThumbnailAccessory(
            new ThumbnailBuilder().setURL(target.displayAvatarURL({ size: 256 }))
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**💬 Messages Sent:** ${stats.messages.toLocaleString()} messages\n` +
              `**🎤 Voice Time:** ${voiceHours} hours (${Math.floor(stats.voiceTime / 60)} minutes total)\n` +
              `**📨 Invites:** ${stats.invites || 0} members invited`
            )
          )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `**📅 Server Activity**\n` +
          `Joined: <t:${Math.floor(joinedAt.getTime() / 1000)}:R>\n` +
          `Days in server: **${daysInServer}** days`
        )
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`-# Stats for ${interaction.guild.name}`)
      );
    
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
