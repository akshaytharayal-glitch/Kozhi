import { 
  SlashCommandBuilder, 
  PermissionFlagsBits, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ThumbnailBuilder,
  MessageFlags
} from 'discord.js';
import { addGiveaway, getGiveawayByMessageId, updateGiveaway, getAllActiveGiveaways } from '../../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Create and manage giveaways')
    .addSubcommand(subcommand =>
      subcommand
        .setName('start')
        .setDescription('Start a new giveaway')
        .addStringOption(option =>
          option.setName('prize')
            .setDescription('What are you giving away?')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('duration')
            .setDescription('Duration in minutes')
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(10080))
        .addIntegerOption(option =>
          option.setName('winners')
            .setDescription('Number of winners (default: 1)')
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(20))
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('Channel to host the giveaway (default: current channel)')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('end')
        .setDescription('End a giveaway early')
        .addStringOption(option =>
          option.setName('message_id')
            .setDescription('The message ID of the giveaway')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('reroll')
        .setDescription('Reroll the winner of a giveaway')
        .addStringOption(option =>
          option.setName('message_id')
            .setDescription('The message ID of the giveaway')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 5,

  async execute(interaction, client) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'start') {
      await handleStart(interaction, client);
    } else if (subcommand === 'end') {
      await handleEnd(interaction, client);
    } else if (subcommand === 'reroll') {
      await handleReroll(interaction, client);
    }
  },

  async handleButton(interaction, client) {
    const [action, messageId] = interaction.customId.split('_').slice(1);
    
    if (action === 'enter') {
      const giveaway = getGiveawayByMessageId(interaction.guild.id, messageId);
      
      if (!giveaway) {
        return interaction.reply({ content: 'This giveaway no longer exists!', ephemeral: true });
      }
      
      if (giveaway.ended) {
        return interaction.reply({ content: 'This giveaway has already ended!', ephemeral: true });
      }
      
      if (giveaway.participants.includes(interaction.user.id)) {
        const newParticipants = giveaway.participants.filter(id => id !== interaction.user.id);
        updateGiveaway(interaction.guild.id, messageId, { participants: newParticipants });
        
        await updateGiveawayContainer(interaction, giveaway, newParticipants.length);
        return interaction.reply({ content: 'You have left the giveaway!', ephemeral: true });
      }
      
      const newParticipants = [...giveaway.participants, interaction.user.id];
      updateGiveaway(interaction.guild.id, messageId, { participants: newParticipants });
      
      await updateGiveawayContainer(interaction, giveaway, newParticipants.length);
      return interaction.reply({ content: 'You have entered the giveaway! Good luck!', ephemeral: true });
    }
  }
};

async function handleStart(interaction, client) {
  const prize = interaction.options.getString('prize');
  const duration = interaction.options.getInteger('duration');
  const winnersCount = interaction.options.getInteger('winners') || 1;
  const channel = interaction.options.getChannel('channel') || interaction.channel;

  const endTime = Date.now() + (duration * 60 * 1000);

  const container = new ContainerBuilder()
    .setAccentColor(0xFF69B4)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 🎉 GIVEAWAY 🎉')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Prize:** ${prize}`),
      new TextDisplayBuilder().setContent(`**Winners:** ${winnersCount}`),
      new TextDisplayBuilder().setContent(`**Entries:** 0`),
      new TextDisplayBuilder().setContent(`**Ends:** <t:${Math.floor(endTime / 1000)}:R>`),
      new TextDisplayBuilder().setContent(`**Hosted by:** ${interaction.user}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('**Click below to enter!**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId('giveaway_enter_PLACEHOLDER')
            .setLabel('Enter Giveaway')
            .setStyle(ButtonStyle.Primary)
        )
    );

  const message = await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });

  const updatedContainer = new ContainerBuilder()
    .setAccentColor(0xFF69B4)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# 🎉 GIVEAWAY 🎉')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Prize:** ${prize}`),
      new TextDisplayBuilder().setContent(`**Winners:** ${winnersCount}`),
      new TextDisplayBuilder().setContent(`**Entries:** 0`),
      new TextDisplayBuilder().setContent(`**Ends:** <t:${Math.floor(endTime / 1000)}:R>`),
      new TextDisplayBuilder().setContent(`**Hosted by:** ${interaction.user}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('**Click below to enter!**')
        )
        .setButtonAccessory(
          new ButtonBuilder()
            .setCustomId(`giveaway_enter_${message.id}`)
            .setLabel('Enter Giveaway')
            .setStyle(ButtonStyle.Primary)
        )
    );

  await message.edit({ components: [updatedContainer], flags: MessageFlags.IsComponentsV2 });

  const giveaway = {
    messageId: message.id,
    channelId: channel.id,
    prize,
    winnersCount,
    endTime,
    hostId: interaction.user.id,
    participants: [],
    ended: false,
    createdAt: Date.now()
  };

  addGiveaway(interaction.guild.id, giveaway);

  await interaction.reply({ 
    content: `Giveaway started in ${channel}! It will end <t:${Math.floor(endTime / 1000)}:R>.`, 
    ephemeral: true 
  });
}

async function handleEnd(interaction, client) {
  const messageId = interaction.options.getString('message_id');
  const giveaway = getGiveawayByMessageId(interaction.guild.id, messageId);

  if (!giveaway) {
    return interaction.reply({ content: 'Giveaway not found! Make sure you entered the correct message ID.', ephemeral: true });
  }

  if (giveaway.ended) {
    return interaction.reply({ content: 'This giveaway has already ended!', ephemeral: true });
  }

  await endGiveaway(interaction.guild, giveaway, client);
  await interaction.reply({ content: 'Giveaway ended successfully!', ephemeral: true });
}

async function handleReroll(interaction, client) {
  const messageId = interaction.options.getString('message_id');
  const giveaway = getGiveawayByMessageId(interaction.guild.id, messageId);

  if (!giveaway) {
    return interaction.reply({ content: 'Giveaway not found!', ephemeral: true });
  }

  if (!giveaway.ended) {
    return interaction.reply({ content: 'This giveaway has not ended yet!', ephemeral: true });
  }

  if (giveaway.participants.length === 0) {
    return interaction.reply({ content: 'No participants to reroll!', ephemeral: true });
  }

  const winners = selectWinners(giveaway.participants, 1);
  const channel = await interaction.guild.channels.fetch(giveaway.channelId);

  if (channel) {
    const winnerMentions = winners.map(id => `<@${id}>`).join(', ');
    await channel.send(`🎉 New winner: ${winnerMentions} won **${giveaway.prize}**!`);
  }

  await interaction.reply({ content: 'Rerolled successfully!', ephemeral: true });
}

async function updateGiveawayContainer(interaction, giveaway, participantCount) {
  try {
    const channel = await interaction.guild.channels.fetch(giveaway.channelId);
    const message = await channel.messages.fetch(giveaway.messageId);
    
    const updatedContainer = new ContainerBuilder()
      .setAccentColor(0xFF69B4)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# 🎉 GIVEAWAY 🎉')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Prize:** ${giveaway.prize}`),
        new TextDisplayBuilder().setContent(`**Winners:** ${giveaway.winnersCount}`),
        new TextDisplayBuilder().setContent(`**Entries:** ${participantCount}`),
        new TextDisplayBuilder().setContent(`**Ends:** <t:${Math.floor(giveaway.endTime / 1000)}:R>`),
        new TextDisplayBuilder().setContent(`**Hosted by:** <@${giveaway.hostId}>`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**Click below to enter!**')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId(`giveaway_enter_${giveaway.messageId}`)
              .setLabel('Enter Giveaway')
              .setStyle(ButtonStyle.Primary)
          )
      );
    
    await message.edit({ components: [updatedContainer], flags: MessageFlags.IsComponentsV2 });
  } catch (error) {
    console.error('Error updating giveaway container:', error);
  }
}

function selectWinners(participants, count) {
  const shuffled = [...participants].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

export async function endGiveaway(guild, giveaway, client) {
  try {
    const channel = await guild.channels.fetch(giveaway.channelId);
    const message = await channel.messages.fetch(giveaway.messageId);

    updateGiveaway(guild.id, giveaway.messageId, { ended: true });

    if (giveaway.participants.length === 0) {
      const endedContainer = new ContainerBuilder()
        .setAccentColor(0x808080)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 🎉 GIVEAWAY ENDED 🎉')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Prize:** ${giveaway.prize}`),
          new TextDisplayBuilder().setContent('**No valid entries!**'),
          new TextDisplayBuilder().setContent('*No one entered the giveaway.*')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('*Giveaway ended*')
            )
            .setButtonAccessory(
              new ButtonBuilder()
                .setCustomId(`giveaway_ended_${giveaway.messageId}`)
                .setLabel('Giveaway Ended')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true)
            )
        );

      await message.edit({ components: [endedContainer], flags: MessageFlags.IsComponentsV2 });
      await channel.send(`No one entered the giveaway for **${giveaway.prize}**!`);
      return;
    }

    const winners = selectWinners(giveaway.participants, giveaway.winnersCount);
    const winnerMentions = winners.map(id => `<@${id}>`).join(', ');

    const endedContainer = new ContainerBuilder()
      .setAccentColor(0x00FF00)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# 🎉 GIVEAWAY ENDED 🎉')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Prize:** ${giveaway.prize}`),
        new TextDisplayBuilder().setContent(`**Winner(s):** ${winnerMentions}`),
        new TextDisplayBuilder().setContent(`**Entries:** ${giveaway.participants.length}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('*Giveaway ended*')
          )
          .setButtonAccessory(
            new ButtonBuilder()
              .setCustomId(`giveaway_ended_${giveaway.messageId}`)
              .setLabel('Giveaway Ended')
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(true)
          )
      );

    await message.edit({ components: [endedContainer], flags: MessageFlags.IsComponentsV2 });
    await channel.send(`🎉 Congratulations ${winnerMentions}! You won **${giveaway.prize}**!`);

    for (const winnerId of winners) {
      try {
        const winner = await guild.members.fetch(winnerId);
        await winner.send(`🎉 Congratulations! You won **${giveaway.prize}** in **${guild.name}**!`);
      } catch (error) {
        console.log(`Could not DM winner ${winnerId}`);
      }
    }
  } catch (error) {
    console.error('Error ending giveaway:', error);
  }
}
