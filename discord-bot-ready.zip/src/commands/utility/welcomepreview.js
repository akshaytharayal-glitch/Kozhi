import { SlashCommandBuilder, AttachmentBuilder, PermissionFlagsBits, ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ThumbnailBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import path from 'path';
import fs from 'fs';
import { findImportantChannels, BANNER_PATH } from '../../events/guildMemberAdd.js';

export default {
  data: new SlashCommandBuilder()
    .setName('welcomepreview')
    .setDescription('Preview what the welcome message looks like when someone joins')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to preview welcome for (defaults to you)')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  
  cooldown: 10,
  
  async execute(interaction, client) {
    await interaction.deferReply();
    
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(targetUser.id) || { user: targetUser, id: targetUser.id };
    const memberCount = interaction.guild.memberCount;
    
    try {
      let attachment = null;
      let hasCustomBanner = false;
      
      if (fs.existsSync(BANNER_PATH)) {
        try {
          attachment = new AttachmentBuilder(BANNER_PATH, { name: 'banner.png' });
          hasCustomBanner = true;
        } catch (e) {
          console.error('[WelcomePreview] Failed to load banner:', e.message);
        }
      }
      
      const importantChannels = findImportantChannels(interaction.guild);
      
      let channelLinks = '';
      if (importantChannels.announcement || importantChannels.rules || importantChannels.general) {
        channelLinks = '\n\n**📌 Important Channels:**\n';
        
        if (importantChannels.announcement) {
          channelLinks += `📢 Announcements: <#${importantChannels.announcement.id}>\n`;
        }
        if (importantChannels.rules) {
          channelLinks += `📜 Rules: <#${importantChannels.rules.id}>\n`;
        }
        if (importantChannels.general) {
          channelLinks += `💬 General Chat: <#${importantChannels.general.id}>\n`;
        }
      }
      
      const channelStatus = [];
      if (importantChannels.announcement) channelStatus.push(`📢 Announcements: <#${importantChannels.announcement.id}>`);
      if (importantChannels.rules) channelStatus.push(`📜 Rules: <#${importantChannels.rules.id}>`);
      if (importantChannels.general) channelStatus.push(`💬 General: <#${importantChannels.general.id}>`);
      
      const previewContainer = new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Welcome Message Preview')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`This is what the welcome message will look like when **${targetUser.username}** joins the server.\n\nThe welcome message is automatically sent to channels named "welcome" or the system channel.`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**Target Channel:** ${getWelcomeChannelInfo(interaction.guild)}\n` +
            `**Current Member Count:** ${memberCount}\n` +
            `**Banner Status:** ${hasCustomBanner ? '✅ Loaded' : '❌ Not available'}`
          )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**Detected Channels:**\n${channelStatus.length > 0 ? channelStatus.join('\n') : 'None detected'}`
          )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('-# This is a preview only - no message was sent')
        );
      
      const welcomeContainer = new ContainerBuilder()
        .setAccentColor(0x7C3AED)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# 🎉 Welcome!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`Hey <@${member.id}>!\n\nYou are member **#${memberCount}**${channelLinks}`)
            )
            .setThumbnailAccessory(
              new ThumbnailBuilder({ media: { url: targetUser.displayAvatarURL({ dynamic: true, size: 256 }) } })
            )
        );
      
      if (hasCustomBanner && attachment) {
        welcomeContainer.addMediaGalleryComponents(
          new MediaGalleryBuilder()
            .addItems(
              new MediaGalleryItemBuilder().setURL('attachment://banner.png')
            )
        );
      }
      
      welcomeContainer.addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      );
      welcomeContainer.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`-# Welcome to ${interaction.guild.name}!`)
      );
      
      const messagePayload = {
        components: [previewContainer, welcomeContainer],
        flags: MessageFlags.IsComponentsV2
      };
      
      if (hasCustomBanner && attachment) {
        messagePayload.files = [attachment];
      }
      
      await interaction.editReply(messagePayload);
      
    } catch (error) {
      console.error('[WelcomePreview] Error:', error);
      
      const errorContainer = new ContainerBuilder()
        .setAccentColor(0xFF6B6B)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Error')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('An error occurred while generating the welcome preview.')
        );
      
      await interaction.editReply({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
    }
  },
};

function getWelcomeChannelInfo(guild) {
  const channels = guild.channels.cache.filter(
    ch => ch.type === 0 && ch.permissionsFor(guild.members.me)?.has('SendMessages')
  );
  
  const welcomeChannel = channels.find(ch => 
    ch.name.toLowerCase() === 'welcome' || 
    ch.name.toLowerCase().includes('welcome')
  );
  
  if (welcomeChannel) {
    return `<#${welcomeChannel.id}>`;
  }
  
  if (guild.systemChannel) {
    return `<#${guild.systemChannel.id}> (System Channel)`;
  }
  
  const firstChannel = channels.first();
  if (firstChannel) {
    return `<#${firstChannel.id}> (Fallback)`;
  }
  
  return 'No suitable channel found';
}
