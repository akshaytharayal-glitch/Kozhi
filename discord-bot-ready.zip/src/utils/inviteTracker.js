import { getInviteData, setInviteData, addInvite } from '../utils/database.js';

const guildInvites = new Map();

export async function cacheGuildInvites(guild) {
  try {
    const invites = await guild.invites.fetch();
    const inviteMap = new Map();
    invites.forEach(invite => {
      inviteMap.set(invite.code, {
        odId: invite.inviter?.id,
        uses: invite.uses
      });
    });
    guildInvites.set(guild.id, inviteMap);
  } catch (error) {
    console.log(`Could not cache invites for ${guild.name}:`, error.message);
  }
}

export async function handleMemberJoin(member) {
  const guildId = member.guild.id;
  
  try {
    const cachedInvites = guildInvites.get(guildId);
    const newInvites = await member.guild.invites.fetch();
    
    if (!cachedInvites) {
      await cacheGuildInvites(member.guild);
      return null;
    }
    
    let inviterOdId = null;
    
    newInvites.forEach(invite => {
      const cached = cachedInvites.get(invite.code);
      if (cached && invite.uses > cached.uses) {
        inviterOdId = cached.odId;
      }
    });
    
    if (inviterOdId && inviterOdId !== member.id) {
      addInvite(guildId, inviterOdId);
    }
    
    await cacheGuildInvites(member.guild);
    
    return inviterOdId;
  } catch (error) {
    console.log('Error tracking invite:', error.message);
    return null;
  }
}

export { guildInvites };
