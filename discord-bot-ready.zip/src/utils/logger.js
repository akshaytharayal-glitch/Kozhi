import { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { getLogSettings } from './database.js';

const LOG_COLORS = {
  memberJoin: 0x00FF00,
  memberLeave: 0xFF6B6B,
  memberBan: 0xFF0000,
  memberUnban: 0x00FF00,
  messageDelete: 0xFF6B6B,
  messageEdit: 0xFFAA00,
  channelCreate: 0x00FF00,
  channelDelete: 0xFF6B6B,
  roleCreate: 0x00FF00,
  roleDelete: 0xFF6B6B,
  voiceJoin: 0x00D4FF,
  voiceLeave: 0xFF6B6B,
  nicknameChange: 0xFFAA00,
  roleUpdate: 0x9B59B6,
  inviteCreate: 0x00D4FF,
  commandUsage: 0x5865F2
};

const LOG_EMOJIS = {
  memberJoin: '📥',
  memberLeave: '📤',
  memberBan: '🔨',
  memberUnban: '🔓',
  messageDelete: '🗑️',
  messageEdit: '✏️',
  channelCreate: '➕',
  channelDelete: '➖',
  roleCreate: '🏷️',
  roleDelete: '🗑️',
  voiceJoin: '🎤',
  voiceLeave: '🔇',
  nicknameChange: '📝',
  roleUpdate: '🔄',
  inviteCreate: '🔗',
  commandUsage: '⚡'
};

export async function sendLog(guild, logType, title, description, fields = []) {
  try {
    const settings = getLogSettings(guild.id);
    
    if (!settings.channelId || !settings.enabled?.[logType]) {
      return false;
    }

    const logChannel = await guild.channels.fetch(settings.channelId).catch(() => null);
    if (!logChannel) return false;

    const container = new ContainerBuilder()
      .setAccentColor(LOG_COLORS[logType] || 0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${LOG_EMOJIS[logType] || '📋'} ${title}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(description)
      );

    if (fields.length > 0) {
      container.addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      );
      
      const fieldText = fields.map(f => `**${f.name}:** ${f.value}`).join('\n');
      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(fieldText)
      );
    }

    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# <t:${Math.floor(Date.now() / 1000)}:F>`)
    );

    await logChannel.send({ 
      components: [container], 
      flags: MessageFlags.IsComponentsV2 
    });

    return true;
  } catch (error) {
    console.error('[Logger] Error sending log:', error.message);
    return false;
  }
}

export function isLogEnabled(guildId, logType) {
  const settings = getLogSettings(guildId);
  return settings.channelId && settings.enabled?.[logType];
}
