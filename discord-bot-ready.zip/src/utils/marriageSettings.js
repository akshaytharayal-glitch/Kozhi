import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const settingsPath = path.join(__dirname, '../../data/marriageSettings.json');

export function getSettings() {
  try {
    if (!fs.existsSync(settingsPath)) {
      fs.writeFileSync(settingsPath, '{}');
      return {};
    }
    return JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
  } catch {
    return {};
  }
}

export function saveSettings(settings) {
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
}

export function getMarriageMode(guildId) {
  const settings = getSettings();
  return settings[guildId]?.mode || 'role_based';
}

export function setMarriageMode(guildId, mode) {
  const settings = getSettings();
  settings[guildId] = { mode };
  saveSettings(settings);
}
