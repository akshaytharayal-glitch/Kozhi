import { AttachmentBuilder } from 'discord.js';
import discordTTS from 'discord-tts';
import { createWriteStream, unlinkSync, existsSync, mkdirSync, writeFileSync, readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { pipeline } from 'stream/promises';
import { exec } from 'child_process';
import { promisify } from 'util';
import { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus, entersState, NoSubscriberBehavior } from '@discordjs/voice';

const execAsync = promisify(exec);

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const TEMP_DIR = join(__dirname, '../../temp_audio');
const CUSTOM_ANNOUNCEMENT_AUDIO = join(__dirname, '../assets/ticket_announcement.mp3');

if (!existsSync(TEMP_DIR)) {
  mkdirSync(TEMP_DIR, { recursive: true });
}

export async function sendTicketVoiceMessage(ticketChannel, guild, user) {
  const timestamp = Date.now();
  const englishTTSPath = join(TEMP_DIR, `english_${timestamp}.mp3`);
  const nameTTSPath = join(TEMP_DIR, `name_${timestamp}.mp3`);
  const finalOutputPath = join(TEMP_DIR, `ticket_welcome_${timestamp}.mp3`);
  const concatListPath = join(TEMP_DIR, `concat_${timestamp}.txt`);
  
  try {
    const member = await guild.members.fetch(user.id).catch(() => null);
    const rawUserName = member?.displayName || user.username;
    const userName = formatNameForTTS(rawUserName);
    
    const englishMessage = "Welcome to the ticket section of Mandhi Spot. The support will be here soon.";
    const englishStream = discordTTS.getVoiceStream(englishMessage, 'en-US');
    const englishWriteStream = createWriteStream(englishTTSPath);
    await pipeline(englishStream, englishWriteStream);
    
    const nameMessage = `This ticket was created by ${userName}`;
    const nameStream = discordTTS.getVoiceStream(nameMessage, 'en-US');
    const nameWriteStream = createWriteStream(nameTTSPath);
    await pipeline(nameStream, nameWriteStream);

    const concatContent = `file '${englishTTSPath}'\nfile '${nameTTSPath}'`;
    writeFileSync(concatListPath, concatContent);

    try {
      await execAsync(`ffmpeg -f concat -safe 0 -i "${concatListPath}" -c copy "${finalOutputPath}" -y`, {
        timeout: 30000
      });
    } catch (ffmpegError) {
      console.log('[TTS] FFmpeg concat failed, trying with re-encoding...');
      await execAsync(`ffmpeg -f concat -safe 0 -i "${concatListPath}" -acodec libmp3lame -ar 44100 "${finalOutputPath}" -y`, {
        timeout: 30000
      });
    }

    const attachment = new AttachmentBuilder(finalOutputPath, { 
      name: 'welcome_message.mp3',
      description: `Welcome voice message for ${userName}`
    });

    await ticketChannel.send({ 
      content: '🔊 **Voice Welcome Message:**',
      files: [attachment] 
    });

    console.log(`[TTS] Sent voice message for ${userName} in ticket`);

    cleanupFiles([englishTTSPath, nameTTSPath, finalOutputPath, concatListPath]);

    return true;

  } catch (error) {
    console.error('[TTS] Error sending ticket voice message:', error);
    
    cleanupFiles([englishTTSPath, nameTTSPath, finalOutputPath, concatListPath]);
    
    return await sendFallbackTTS(ticketChannel, guild, user);
  }
}

export async function announceTicketToAdminVC(guild, user, ticketId, client) {
  try {
    if (!existsSync(CUSTOM_ANNOUNCEMENT_AUDIO)) {
      console.error('[VC Announce] Custom announcement audio file not found:', CUSTOM_ANNOUNCEMENT_AUDIO);
      return false;
    }
    
    const adminRole = guild.roles.cache.find(role => 
      role.name.toLowerCase() === 'admin' || role.name.toLowerCase() === 'administrator'
    );
    
    if (!adminRole) {
      console.log('[VC Announce] No admin role found in guild');
      return false;
    }
    
    await guild.members.fetch();
    
    const adminsInVC = guild.members.cache.filter(member => {
      const hasRole = member.roles.cache.has(adminRole.id);
      const inVoice = member.voice.channel !== null;
      const notBot = !member.user.bot;
      return hasRole && inVoice && notBot;
    });
    
    if (adminsInVC.size === 0) {
      console.log('[VC Announce] No admins found in voice channels');
      return false;
    }
    
    const firstAdmin = adminsInVC.first();
    const voiceChannel = firstAdmin.voice.channel;
    
    console.log(`[VC Announce] Found admin ${firstAdmin.user.username} in ${voiceChannel.name}`);
    
    const kazagumo = client?.kazagumo;
    if (kazagumo) {
      const existingPlayer = kazagumo.players.get(guild.id);
      if (existingPlayer) {
        console.log('[VC Announce] Music is already playing, skipping announcement');
        return false;
      }
    }
    
    console.log(`[VC Announce] Using custom audio file, connecting to ${voiceChannel.name}`);
    
    const { getVoiceConnection } = await import('@discordjs/voice');
    const existingConnection = getVoiceConnection(guild.id);
    if (existingConnection) {
      console.log('[VC Announce] Destroying existing voice connection');
      existingConnection.destroy();
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: guild.id,
      adapterCreator: guild.voiceAdapterCreator,
      selfDeaf: false,
      selfMute: false
    });
    
    connection.on('stateChange', async (oldState, newState) => {
      console.log(`[VC Announce] Connection state: ${oldState.status} -> ${newState.status}`);
      
      if (newState.status === VoiceConnectionStatus.Disconnected) {
        try {
          await Promise.race([
            entersState(connection, VoiceConnectionStatus.Signalling, 5000),
            entersState(connection, VoiceConnectionStatus.Connecting, 5000),
          ]);
        } catch (error) {
          console.log('[VC Announce] Connection lost, destroying');
          try { connection.destroy(); } catch (e) {}
        }
      }
    });
    
    try {
      await entersState(connection, VoiceConnectionStatus.Ready, 30000);
      console.log('[VC Announce] Voice connection ready');
    } catch (err) {
      console.error('[VC Announce] Failed to connect to voice channel:', err.message);
      try { connection.destroy(); } catch (e) {}
      return false;
    }
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const player = createAudioPlayer({
      behaviors: {
        noSubscriber: NoSubscriberBehavior.Play
      }
    });
    
    player.on('stateChange', (oldState, newState) => {
      console.log(`[VC Announce] Player state: ${oldState.status} -> ${newState.status}`);
    });
    
    const resource = createAudioResource(CUSTOM_ANNOUNCEMENT_AUDIO, {
      inlineVolume: true
    });
    resource.volume?.setVolume(2.0);
    
    const subscription = connection.subscribe(player);
    if (!subscription) {
      console.error('[VC Announce] Failed to subscribe player to connection');
      try { connection.destroy(); } catch (e) {}
      return false;
    }
    
    console.log(`[VC Announce] Starting playback of custom audio in ${voiceChannel.name}`);
    player.play(resource);
    
    return new Promise((resolve) => {
      let hasFinished = false;
      
      const cleanup = (success) => {
        if (hasFinished) return;
        hasFinished = true;
        console.log(`[VC Announce] Cleanup called, success: ${success}`);
        
        setTimeout(() => {
          try { 
            player.stop();
            connection.destroy(); 
          } catch (e) {}
          resolve(success);
        }, 1000);
      };
      
      player.on(AudioPlayerStatus.Idle, () => {
        console.log('[VC Announce] Custom audio finished playing, leaving voice channel');
        cleanup(true);
      });
      
      player.on('error', (error) => {
        console.error('[VC Announce] Audio player error:', error.message);
        cleanup(false);
      });
      
      setTimeout(() => {
        if (!hasFinished) {
          console.log('[VC Announce] Timeout reached (90s), forcing cleanup');
          cleanup(false);
        }
      }, 90000);
    });
    
  } catch (error) {
    console.error('[VC Announce] Error announcing ticket:', error);
    return false;
  }
}

function formatNameForTTS(name) {
  let cleanName = name;
  
  const hasNonLatin = /[^\x00-\x7F]/.test(cleanName);
  
  if (hasNonLatin) {
    cleanName = cleanName.replace(/[_\-\.]/g, ' ');
    cleanName = cleanName.replace(/\d+/g, '');
    cleanName = cleanName.replace(/\s+/g, ' ').trim();
    return cleanName.length >= 1 ? cleanName : name;
  }
  
  cleanName = cleanName.replace(/^[Xx]+|[Xx]+$/g, '');
  cleanName = cleanName.replace(/[_\-\.]/g, ' ');
  cleanName = cleanName.replace(/([a-z])([A-Z])/g, '$1 $2');
  cleanName = cleanName.replace(/([A-Za-z])(\d)/g, '$1 ');
  cleanName = cleanName.replace(/(\d)([A-Za-z])/g, ' $2');
  cleanName = cleanName.replace(/\d+/g, '');
  cleanName = cleanName.replace(/(.)\1{2,}/g, '$1');
  
  if (cleanName === cleanName.toUpperCase() && cleanName.length > 1) {
    cleanName = cleanName.charAt(0).toUpperCase() + cleanName.slice(1).toLowerCase();
  }
  
  cleanName = cleanName.replace(/[^a-zA-Z\s]/g, '');
  cleanName = cleanName.replace(/\s+/g, ' ').trim();
  
  if (cleanName.length < 2) {
    const lettersOnly = name.replace(/[^a-zA-Z]/g, '');
    if (lettersOnly.length >= 2) {
      cleanName = lettersOnly.charAt(0).toUpperCase() + lettersOnly.slice(1).toLowerCase();
    } else {
      cleanName = "User";
    }
  }
  
  return cleanName;
}

async function sendFallbackTTS(ticketChannel, guild, user) {
  const tempFilePath = join(TEMP_DIR, `ticket_fallback_${Date.now()}.mp3`);
  
  try {
    const member = await guild.members.fetch(user.id).catch(() => null);
    const rawUserName = member?.displayName || user.username;
    const userName = formatNameForTTS(rawUserName);
    
    const welcomeMessage = `Welcome to the ticket section of Mandhi Spot. The support will be here soon. Don't worry, everything will be fine. This ticket was created by ${userName}.`;

    const stream = discordTTS.getVoiceStream(welcomeMessage, 'en-US');
    
    const writeStream = createWriteStream(tempFilePath);
    await pipeline(stream, writeStream);

    const attachment = new AttachmentBuilder(tempFilePath, { 
      name: 'welcome_message.mp3',
      description: `Welcome voice message for ${userName}`
    });

    await ticketChannel.send({ 
      content: '🔊 **Voice Welcome Message:**',
      files: [attachment] 
    });

    console.log(`[TTS] Sent fallback voice message for ${userName} in ticket`);

    try {
      unlinkSync(tempFilePath);
    } catch (e) {
      console.error('[TTS] Error cleaning up fallback temp file:', e);
    }

    return true;

  } catch (error) {
    console.error('[TTS] Fallback TTS also failed:', error);
    
    try {
      if (existsSync(tempFilePath)) {
        unlinkSync(tempFilePath);
      }
    } catch (e) {
      console.error('[TTS] Error cleaning up fallback temp file:', e);
    }
    
    return false;
  }
}

function cleanupFiles(files) {
  for (const file of files) {
    try {
      if (existsSync(file)) {
        unlinkSync(file);
      }
    } catch (e) {
      console.error('[TTS] Error cleaning up file:', file, e.message);
    }
  }
}
