import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, '../../data');

function ensureFile(filename, defaultData = {}) {
  const filepath = join(dataDir, filename);
  if (!existsSync(filepath)) {
    writeFileSync(filepath, JSON.stringify(defaultData, null, 2));
  }
  return filepath;
}

function readData(filename) {
  const filepath = ensureFile(filename, {});
  try {
    return JSON.parse(readFileSync(filepath, 'utf8'));
  } catch {
    return {};
  }
}

function writeData(filename, data) {
  const filepath = join(dataDir, filename);
  writeFileSync(filepath, JSON.stringify(data, null, 2));
}

export function getBalance(guildId, userId) {
  const data = readData('economy.json');
  const key = `${guildId}-${userId}`;
  return data[key]?.balance || 0;
}

export function setBalance(guildId, userId, amount) {
  const data = readData('economy.json');
  const key = `${guildId}-${userId}`;
  if (!data[key]) {
    data[key] = { balance: 0, guildId, userId };
  }
  data[key].balance = amount;
  writeData('economy.json', data);
  return amount;
}

export function addBalance(guildId, userId, amount) {
  const current = getBalance(guildId, userId);
  return setBalance(guildId, userId, current + amount);
}

export function removeBalance(guildId, userId, amount) {
  const current = getBalance(guildId, userId);
  return setBalance(guildId, userId, Math.max(0, current - amount));
}

export function getLeaderboard(guildId, limit = 10) {
  const data = readData('economy.json');
  const guildUsers = Object.entries(data)
    .filter(([key]) => key.startsWith(`${guildId}-`))
    .map(([key, value]) => ({
      userId: key.split('-')[1],
      balance: value.balance,
    }))
    .sort((a, b) => b.balance - a.balance)
    .slice(0, limit);
  return guildUsers;
}

export function getCountGame(guildId) {
  const data = readData('countgame.json');
  return data[guildId] || { currentNumber: 0, lastUserId: null, channelId: null, highScore: 0 };
}

export function setCountGame(guildId, gameData) {
  const data = readData('countgame.json');
  data[guildId] = gameData;
  writeData('countgame.json', data);
}

export function getTickets(guildId) {
  const data = readData('tickets.json');
  return data[guildId] || { tickets: [], categoryId: null, logChannelId: null, counter: 0 };
}

export function setTickets(guildId, ticketData) {
  const data = readData('tickets.json');
  data[guildId] = ticketData;
  writeData('tickets.json', data);
}

export function addTicket(guildId, ticket) {
  const ticketData = getTickets(guildId);
  ticketData.counter++;
  ticket.id = ticketData.counter;
  ticketData.tickets.push(ticket);
  setTickets(guildId, ticketData);
  return ticket;
}

export function closeTicket(guildId, channelId) {
  const ticketData = getTickets(guildId);
  const ticketIndex = ticketData.tickets.findIndex(t => t.channelId === channelId);
  if (ticketIndex !== -1) {
    ticketData.tickets[ticketIndex].status = 'closed';
    ticketData.tickets[ticketIndex].closedAt = Date.now();
    setTickets(guildId, ticketData);
    return ticketData.tickets[ticketIndex];
  }
  return null;
}

export function getDailyReward(guildId, userId) {
  const data = readData('daily.json');
  const key = `${guildId}-${userId}`;
  return data[key] || { lastClaim: 0, streak: 0 };
}

export function setDailyReward(guildId, userId, rewardData) {
  const data = readData('daily.json');
  const key = `${guildId}-${userId}`;
  data[key] = rewardData;
  writeData('daily.json', data);
}

export function getUserStats(guildId, userId) {
  const data = readData('userstats.json');
  const key = `${guildId}-${userId}`;
  return data[key] || {
    xp: 0,
    level: 1,
    messages: 0,
    voiceTime: 0,
    invites: 0,
    joinedAt: Date.now()
  };
}

export function setUserStats(guildId, userId, stats) {
  const data = readData('userstats.json');
  const key = `${guildId}-${userId}`;
  data[key] = { ...stats, guildId, userId };
  writeData('userstats.json', data);
}

export function addXP(guildId, userId, amount) {
  const stats = getUserStats(guildId, userId);
  stats.xp += amount;
  stats.messages += 1;
  
  const xpNeeded = calculateXPForLevel(stats.level + 1);
  let leveledUp = false;
  
  while (stats.xp >= xpNeeded) {
    stats.level += 1;
    leveledUp = true;
  }
  
  setUserStats(guildId, userId, stats);
  return { stats, leveledUp };
}

export function calculateXPForLevel(level) {
  return 5 * (level * level) + 50 * level + 100;
}

export function getTotalXPForLevel(level) {
  let total = 0;
  for (let i = 1; i < level; i++) {
    total += calculateXPForLevel(i);
  }
  return total;
}

export function addVoiceTime(guildId, userId, seconds) {
  const stats = getUserStats(guildId, userId);
  stats.voiceTime = (stats.voiceTime || 0) + seconds;
  setUserStats(guildId, userId, stats);
  return stats;
}

export function addInvite(guildId, userId) {
  const stats = getUserStats(guildId, userId);
  stats.invites = (stats.invites || 0) + 1;
  setUserStats(guildId, userId, stats);
  return stats;
}

export function removeInvite(guildId, userId) {
  const stats = getUserStats(guildId, userId);
  stats.invites = Math.max(0, (stats.invites || 0) - 1);
  setUserStats(guildId, userId, stats);
  return stats;
}

export function getStatsLeaderboard(guildId, type, limit = 10) {
  const data = readData('userstats.json');
  const guildUsers = Object.entries(data)
    .filter(([key]) => key.startsWith(`${guildId}-`))
    .map(([key, value]) => ({
      userId: key.split('-')[1],
      ...value
    }));
  
  let sorted;
  switch (type) {
    case 'level':
      sorted = guildUsers.sort((a, b) => {
        if (b.level === a.level) return b.xp - a.xp;
        return b.level - a.level;
      });
      break;
    case 'messages':
      sorted = guildUsers.sort((a, b) => (b.messages || 0) - (a.messages || 0));
      break;
    case 'voice':
      sorted = guildUsers.sort((a, b) => (b.voiceTime || 0) - (a.voiceTime || 0));
      break;
    case 'invites':
      sorted = guildUsers.sort((a, b) => (b.invites || 0) - (a.invites || 0));
      break;
    case 'active':
      sorted = guildUsers.sort((a, b) => {
        const aActiveTime = (a.voiceTime || 0) + ((a.messages || 0) * 60);
        const bActiveTime = (b.voiceTime || 0) + ((b.messages || 0) * 60);
        return bActiveTime - aActiveTime;
      });
      break;
    default:
      sorted = guildUsers.sort((a, b) => b.level - a.level);
  }
  
  return sorted.slice(0, limit);
}

export function getInviteData(guildId) {
  const data = readData('invites.json');
  return data[guildId] || {};
}

export function setInviteData(guildId, inviteData) {
  const data = readData('invites.json');
  data[guildId] = inviteData;
  writeData('invites.json', data);
}

export function getGiveaways(guildId) {
  const data = readData('giveaways.json');
  return data[guildId] || [];
}

export function setGiveaways(guildId, giveaways) {
  const data = readData('giveaways.json');
  data[guildId] = giveaways;
  writeData('giveaways.json', data);
}

export function addGiveaway(guildId, giveaway) {
  const giveaways = getGiveaways(guildId);
  giveaways.push(giveaway);
  setGiveaways(guildId, giveaways);
  return giveaway;
}

export function getGiveawayByMessageId(guildId, messageId) {
  const giveaways = getGiveaways(guildId);
  return giveaways.find(g => g.messageId === messageId);
}

export function updateGiveaway(guildId, messageId, updates) {
  const giveaways = getGiveaways(guildId);
  const index = giveaways.findIndex(g => g.messageId === messageId);
  if (index !== -1) {
    giveaways[index] = { ...giveaways[index], ...updates };
    setGiveaways(guildId, giveaways);
    return giveaways[index];
  }
  return null;
}

export function removeGiveaway(guildId, messageId) {
  const giveaways = getGiveaways(guildId);
  const filtered = giveaways.filter(g => g.messageId !== messageId);
  setGiveaways(guildId, filtered);
}

export function getAllActiveGiveaways() {
  const data = readData('giveaways.json');
  const allActive = [];
  for (const guildId of Object.keys(data)) {
    const guildGiveaways = data[guildId].filter(g => !g.ended);
    for (const giveaway of guildGiveaways) {
      allActive.push({ ...giveaway, guildId });
    }
  }
  return allActive;
}

export function getScheduledAnnouncements(guildId) {
  const data = readData('announcements.json');
  return data[guildId] || [];
}

export function setScheduledAnnouncements(guildId, announcements) {
  const data = readData('announcements.json');
  data[guildId] = announcements;
  writeData('announcements.json', data);
}

export function addScheduledAnnouncement(guildId, announcement) {
  const announcements = getScheduledAnnouncements(guildId);
  announcement.id = Date.now().toString();
  announcements.push(announcement);
  setScheduledAnnouncements(guildId, announcements);
  return announcement;
}

export function removeScheduledAnnouncement(guildId, announcementId) {
  const announcements = getScheduledAnnouncements(guildId);
  const filtered = announcements.filter(a => a.id !== announcementId);
  setScheduledAnnouncements(guildId, filtered);
}

export function getAllPendingAnnouncements() {
  const data = readData('announcements.json');
  const allPending = [];
  for (const guildId of Object.keys(data)) {
    const guildAnnouncements = data[guildId].filter(a => !a.sent);
    for (const announcement of guildAnnouncements) {
      allPending.push({ ...announcement, guildId });
    }
  }
  return allPending;
}

export function markAnnouncementSent(guildId, announcementId) {
  const announcements = getScheduledAnnouncements(guildId);
  const index = announcements.findIndex(a => a.id === announcementId);
  if (index !== -1) {
    announcements[index].sent = true;
    setScheduledAnnouncements(guildId, announcements);
  }
}

export function getRecordingSettings(guildId) {
  const data = readData('recordings.json');
  return data[guildId] || { logChannelId: null, adminRoleId: null };
}

export function setRecordingSettings(guildId, settings) {
  const data = readData('recordings.json');
  data[guildId] = settings;
  writeData('recordings.json', data);
}

export function getLogSettings(guildId) {
  const data = readData('logsettings.json');
  return data[guildId] || { channelId: null, enabled: {} };
}

export function setLogSettings(guildId, settings) {
  const data = readData('logsettings.json');
  data[guildId] = settings;
  writeData('logsettings.json', data);
}
