import { ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } from 'discord.js';

export function checkVoiceChannel(interaction, player) {
  const memberVoice = interaction.member.voice.channel;
  const botVoice = interaction.guild.members.me?.voice.channel;
  
  if (!memberVoice) {
    return { 
      valid: false, 
      container: createErrorContainer('You need to be in a voice channel to use this command!')
    };
  }
  
  if (!player) {
    return { 
      valid: false, 
      container: createErrorContainer('There is no music playing in this server!')
    };
  }
  
  if (botVoice && memberVoice.id !== botVoice.id) {
    return { 
      valid: false, 
      container: createErrorContainer(`You must be in the same voice channel as me! Join <#${botVoice.id}> to control the music.`)
    };
  }
  
  return { valid: true };
}

function createErrorContainer(message) {
  return new ContainerBuilder()
    .setAccentColor(0xFF0000)
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('## Error')
        )
    )
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(message)
        )
    );
}
