import OpenAI from 'openai';

let openai = null;

function getOpenAIClient() {
  if (!process.env.OPENAI_API_KEY) {
    return null;
  }
  if (!openai) {
    openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return openai;
}

const conversationHistory = new Map();

const systemPrompt = `You are a friendly, helpful AI assistant in a Discord server. You communicate naturally like a human friend.

Key characteristics:
- Be warm, friendly, and conversational
- Understand and respond in multiple languages, especially Indian languages like Malayalam, Hindi, Tamil, Telugu, Kannada, etc.
- When users type transliterated text (Indian languages written in English letters like "njan evide aan" for Malayalam), understand and respond appropriately
- Keep responses concise but helpful (under 1500 characters for Discord)
- Use casual language and emojis when appropriate
- Remember context from recent messages in the conversation
- Be helpful with questions, jokes, casual chat, or any topic
- Never reveal that you're an AI unless directly asked
- Respond in the same language the user uses

Examples of transliterated understanding:
- "Sugham aanoo?" (Malayalam) = "Are you well?"
- "Kya haal hai?" (Hindi) = "How are you?"
- "Eppadi irukkinga?" (Tamil) = "How are you?"

Always maintain a friendly, human-like conversational tone.`;

function getConversationHistory(channelId, userId) {
  const key = `${channelId}-${userId}`;
  if (!conversationHistory.has(key)) {
    conversationHistory.set(key, []);
  }
  return conversationHistory.get(key);
}

function addToHistory(channelId, userId, role, content) {
  const history = getConversationHistory(channelId, userId);
  history.push({ role, content });
  if (history.length > 20) {
    history.splice(0, history.length - 20);
  }
}

function clearOldHistories() {
  if (conversationHistory.size > 1000) {
    const keysToDelete = [...conversationHistory.keys()].slice(0, 500);
    keysToDelete.forEach(key => conversationHistory.delete(key));
  }
}

export async function generateAIResponse(message) {
  const client = getOpenAIClient();
  if (!client) {
    return "AI chat is not configured. Please ask the bot owner to set up the OpenAI API key.";
  }
  
  const userMessage = message.content.trim();
  if (!userMessage || userMessage.length > 2000) {
    return null;
  }
  
  try {
    clearOldHistories();
    
    const history = getConversationHistory(message.channel.id, message.author.id);
    
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history,
      { role: 'user', content: userMessage }
    ];
    
    const response = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: messages,
      max_tokens: 500,
      temperature: 0.8,
    });
    
    const aiResponse = response.choices[0].message.content;
    
    addToHistory(message.channel.id, message.author.id, 'user', userMessage);
    addToHistory(message.channel.id, message.author.id, 'assistant', aiResponse);
    
    return aiResponse;
    
  } catch (error) {
    console.error('[AI Chat] Error generating response:', error.message);
    
    if (error.code === 'insufficient_quota') {
      return "I'm currently unable to respond due to API limits. Please try again later! 😊";
    }
    
    return null;
  }
}
