import { 
  PermissionFlagsBits, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle, 
  ActionRowBuilder
} from 'discord.js';
import { getVCData, updateVCData } from '../events/voiceStateUpdate.js';

export async function handleVCButton(interaction, client) {
  const customId = interaction.customId;
  const parts = customId.split('_');
  const action = parts[1];
  const voiceChannelId = parts.slice(2).join('_');
  
  const vcData = getVCData(voiceChannelId);
  
  if (!vcData) {
    return interaction.reply({ 
      content: '❌ This voice channel no longer exists!', 
      ephemeral: true 
    });
  }
  
  const voiceChannel = interaction.guild.channels.cache.get(voiceChannelId);
  
  if (!voiceChannel) {
    return interaction.reply({ 
      content: '❌ Voice channel not found!', 
      ephemeral: true 
    });
  }
  
  const isOwner = vcData.ownerId === interaction.user.id;
  const isCoOwner = vcData.coOwners?.includes(interaction.user.id);
  
  if (!isOwner && !isCoOwner) {
    return interaction.reply({ 
      content: '❌ Only the channel owner can use these controls!', 
      ephemeral: true 
    });
  }
  
  switch (action) {
    case 'lock':
      await handleLock(interaction, voiceChannel, vcData);
      break;
    case 'unlock':
      await handleUnlock(interaction, voiceChannel, vcData);
      break;
    case 'hide':
      await handleHide(interaction, voiceChannel, vcData);
      break;
    case 'show':
      await handleShow(interaction, voiceChannel, vcData);
      break;
    case 'kickall':
      await handleKickAll(interaction, voiceChannel, vcData);
      break;
    case 'rename':
      await handleRename(interaction, voiceChannel, vcData);
      break;
    case 'transfer':
      await handleTransfer(interaction, voiceChannel, vcData);
      break;
    case 'coowner':
      await handleCoOwner(interaction, voiceChannel, vcData);
      break;
    case 'limit':
      await handleLimit(interaction, voiceChannel, vcData);
      break;
    case 'permit':
      await handlePermit(interaction, voiceChannel, vcData);
      break;
    case 'block':
      await handleBlock(interaction, voiceChannel, vcData);
      break;
    default:
      await interaction.reply({ content: '❌ Unknown action!', ephemeral: true });
  }
}

async function handleLock(interaction, voiceChannel, vcData) {
  try {
    await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
      Connect: false,
    });
    
    updateVCData(voiceChannel.id, { isLocked: true });
    
    await interaction.reply({ 
      content: '🔒 Your voice channel is now **locked**. No one can join unless permitted.', 
      ephemeral: true 
    });
  } catch (error) {
    console.error('[VCControls] Lock error:', error);
    await interaction.reply({ content: '❌ Failed to lock the channel!', ephemeral: true });
  }
}

async function handleUnlock(interaction, voiceChannel, vcData) {
  try {
    await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
      Connect: null,
    });
    
    updateVCData(voiceChannel.id, { isLocked: false });
    
    await interaction.reply({ 
      content: '🔓 Your voice channel is now **unlocked**. Everyone can join!', 
      ephemeral: true 
    });
  } catch (error) {
    console.error('[VCControls] Unlock error:', error);
    await interaction.reply({ content: '❌ Failed to unlock the channel!', ephemeral: true });
  }
}

async function handleHide(interaction, voiceChannel, vcData) {
  try {
    await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
      ViewChannel: false,
    });
    
    updateVCData(voiceChannel.id, { isHidden: true });
    
    await interaction.reply({ 
      content: '👁️ Your voice channel is now **hidden**. Only permitted users can see it.', 
      ephemeral: true 
    });
  } catch (error) {
    console.error('[VCControls] Hide error:', error);
    await interaction.reply({ content: '❌ Failed to hide the channel!', ephemeral: true });
  }
}

async function handleShow(interaction, voiceChannel, vcData) {
  try {
    await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
      ViewChannel: null,
    });
    
    updateVCData(voiceChannel.id, { isHidden: false });
    
    await interaction.reply({ 
      content: '👁️ Your voice channel is now **visible** to everyone!', 
      ephemeral: true 
    });
  } catch (error) {
    console.error('[VCControls] Show error:', error);
    await interaction.reply({ content: '❌ Failed to reveal the channel!', ephemeral: true });
  }
}

async function handleKickAll(interaction, voiceChannel, vcData) {
  try {
    const members = voiceChannel.members.filter(m => m.id !== vcData.ownerId);
    
    if (members.size === 0) {
      return interaction.reply({ 
        content: '📭 There are no other members to kick!', 
        ephemeral: true 
      });
    }
    
    let kickedCount = 0;
    for (const [, member] of members) {
      try {
        await member.voice.disconnect('Kicked by channel owner');
        kickedCount++;
      } catch (e) {
        console.error(`[VCControls] Failed to kick ${member.user.tag}:`, e.message);
      }
    }
    
    await interaction.reply({ 
      content: `🚪 Kicked **${kickedCount}** member(s) from your voice channel!`, 
      ephemeral: true 
    });
  } catch (error) {
    console.error('[VCControls] KickAll error:', error);
    await interaction.reply({ content: '❌ Failed to kick members!', ephemeral: true });
  }
}

async function handleRename(interaction, voiceChannel, vcData) {
  const modal = new ModalBuilder()
    .setCustomId(`vc_rename_modal_${voiceChannel.id}`)
    .setTitle('Rename Voice Channel');
  
  const nameInput = new TextInputBuilder()
    .setCustomId('new_name')
    .setLabel('New Channel Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter new channel name...')
    .setMaxLength(100)
    .setRequired(true);
  
  const row = new ActionRowBuilder().addComponents(nameInput);
  modal.addComponents(row);
  
  await interaction.showModal(modal);
}

async function handleTransfer(interaction, voiceChannel, vcData) {
  const modal = new ModalBuilder()
    .setCustomId(`vc_transfer_modal_${voiceChannel.id}`)
    .setTitle('Transfer Channel Ownership');
  
  const userInput = new TextInputBuilder()
    .setCustomId('new_owner_id')
    .setLabel('New Owner (User ID or @mention)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter user ID or @username')
    .setRequired(true);
  
  const row = new ActionRowBuilder().addComponents(userInput);
  modal.addComponents(row);
  
  await interaction.showModal(modal);
}

async function handleCoOwner(interaction, voiceChannel, vcData) {
  const modal = new ModalBuilder()
    .setCustomId(`vc_coowner_modal_${voiceChannel.id}`)
    .setTitle('Add Co-Owner');
  
  const userInput = new TextInputBuilder()
    .setCustomId('coowner_user_id')
    .setLabel('Co-Owner (User ID or @mention)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter user ID or @username')
    .setRequired(true);
  
  const row = new ActionRowBuilder().addComponents(userInput);
  modal.addComponents(row);
  
  await interaction.showModal(modal);
}

async function handleLimit(interaction, voiceChannel, vcData) {
  const modal = new ModalBuilder()
    .setCustomId(`vc_limit_modal_${voiceChannel.id}`)
    .setTitle('Set User Limit');
  
  const limitInput = new TextInputBuilder()
    .setCustomId('user_limit')
    .setLabel('User Limit (0 = unlimited, max 99)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter a number (0-99)')
    .setValue(voiceChannel.userLimit.toString())
    .setRequired(true);
  
  const row = new ActionRowBuilder().addComponents(limitInput);
  modal.addComponents(row);
  
  await interaction.showModal(modal);
}

async function handlePermit(interaction, voiceChannel, vcData) {
  const modal = new ModalBuilder()
    .setCustomId(`vc_permit_modal_${voiceChannel.id}`)
    .setTitle('Permit User Access');
  
  const userInput = new TextInputBuilder()
    .setCustomId('permit_user_id')
    .setLabel('User to Permit (User ID or @mention)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter user ID or @username')
    .setRequired(true);
  
  const row = new ActionRowBuilder().addComponents(userInput);
  modal.addComponents(row);
  
  await interaction.showModal(modal);
}

async function handleBlock(interaction, voiceChannel, vcData) {
  const modal = new ModalBuilder()
    .setCustomId(`vc_block_modal_${voiceChannel.id}`)
    .setTitle('Ban User from Channel');
  
  const userInput = new TextInputBuilder()
    .setCustomId('block_user_id')
    .setLabel('User to Ban (User ID or @mention)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter user ID or @username')
    .setRequired(true);
  
  const row = new ActionRowBuilder().addComponents(userInput);
  modal.addComponents(row);
  
  await interaction.showModal(modal);
}

export async function handleVCModal(interaction, client) {
  const customId = interaction.customId;
  
  if (customId.startsWith('vc_rename_modal_')) {
    const voiceChannelId = customId.replace('vc_rename_modal_', '');
    const newName = interaction.fields.getTextInputValue('new_name');
    
    const voiceChannel = interaction.guild.channels.cache.get(voiceChannelId);
    const vcData = getVCData(voiceChannelId);
    
    if (!voiceChannel || !vcData) {
      return interaction.reply({ content: '❌ Channel no longer exists!', ephemeral: true });
    }
    
    try {
      await voiceChannel.setName(newName);
      
      await interaction.reply({ 
        content: `✏️ Channel renamed to **${newName}**!`, 
        ephemeral: true 
      });
    } catch (error) {
      console.error('[VCControls] Rename error:', error);
      await interaction.reply({ content: '❌ Failed to rename channel!', ephemeral: true });
    }
  }
  
  else if (customId.startsWith('vc_transfer_modal_')) {
    const voiceChannelId = customId.replace('vc_transfer_modal_', '');
    let newOwnerId = interaction.fields.getTextInputValue('new_owner_id');
    
    newOwnerId = newOwnerId.replace(/[<@!>]/g, '');
    
    const voiceChannel = interaction.guild.channels.cache.get(voiceChannelId);
    const vcData = getVCData(voiceChannelId);
    
    if (!voiceChannel || !vcData) {
      return interaction.reply({ content: '❌ Channel no longer exists!', ephemeral: true });
    }
    
    try {
      const newOwner = await interaction.guild.members.fetch(newOwnerId);
      
      if (!newOwner) {
        return interaction.reply({ content: '❌ User not found!', ephemeral: true });
      }
      
      await voiceChannel.permissionOverwrites.delete(vcData.ownerId);
      
      await voiceChannel.permissionOverwrites.edit(newOwner.id, {
        ManageChannels: true,
        MoveMembers: true,
        MuteMembers: true,
        DeafenMembers: true,
        Connect: true,
        Speak: true,
        ViewChannel: true,
        SendMessages: true,
      });
      
      updateVCData(voiceChannelId, { ownerId: newOwner.id });
      
      await interaction.reply({ 
        content: `👑 Channel ownership transferred to ${newOwner}!`, 
        ephemeral: true 
      });
      
      await voiceChannel.send({ 
        content: `👑 **Ownership transferred!** ${newOwner} is now the owner of this channel.` 
      });
    } catch (error) {
      console.error('[VCControls] Transfer error:', error);
      await interaction.reply({ content: '❌ Failed to transfer ownership! Make sure the user ID is valid.', ephemeral: true });
    }
  }
  
  else if (customId.startsWith('vc_limit_modal_')) {
    const voiceChannelId = customId.replace('vc_limit_modal_', '');
    const limitStr = interaction.fields.getTextInputValue('user_limit');
    const limit = parseInt(limitStr, 10);
    
    if (isNaN(limit) || limit < 0 || limit > 99) {
      return interaction.reply({ content: '❌ Please enter a valid number between 0 and 99!', ephemeral: true });
    }
    
    const voiceChannel = interaction.guild.channels.cache.get(voiceChannelId);
    
    if (!voiceChannel) {
      return interaction.reply({ content: '❌ Channel no longer exists!', ephemeral: true });
    }
    
    try {
      await voiceChannel.setUserLimit(limit);
      
      await interaction.reply({ 
        content: limit === 0 
          ? '🔢 User limit removed! Unlimited users can join.' 
          : `🔢 User limit set to **${limit}** members!`, 
        ephemeral: true 
      });
    } catch (error) {
      console.error('[VCControls] Limit error:', error);
      await interaction.reply({ content: '❌ Failed to set user limit!', ephemeral: true });
    }
  }
  
  else if (customId.startsWith('vc_permit_modal_')) {
    const voiceChannelId = customId.replace('vc_permit_modal_', '');
    let userId = interaction.fields.getTextInputValue('permit_user_id');
    
    userId = userId.replace(/[<@!>]/g, '');
    
    const voiceChannel = interaction.guild.channels.cache.get(voiceChannelId);
    const vcData = getVCData(voiceChannelId);
    
    if (!voiceChannel || !vcData) {
      return interaction.reply({ content: '❌ Channel no longer exists!', ephemeral: true });
    }
    
    try {
      const user = await interaction.guild.members.fetch(userId);
      
      if (!user) {
        return interaction.reply({ content: '❌ User not found!', ephemeral: true });
      }
      
      await voiceChannel.permissionOverwrites.edit(user.id, {
        Connect: true,
        ViewChannel: true,
        Speak: true,
      });
      
      await interaction.reply({ 
        content: `✅ ${user} has been **permitted** to join your channel!`, 
        ephemeral: true 
      });
    } catch (error) {
      console.error('[VCControls] Permit error:', error);
      await interaction.reply({ content: '❌ Failed to permit user! Make sure the user ID is valid.', ephemeral: true });
    }
  }
  
  else if (customId.startsWith('vc_block_modal_')) {
    const voiceChannelId = customId.replace('vc_block_modal_', '');
    let userId = interaction.fields.getTextInputValue('block_user_id');
    
    userId = userId.replace(/[<@!>]/g, '');
    
    const voiceChannel = interaction.guild.channels.cache.get(voiceChannelId);
    const vcData = getVCData(voiceChannelId);
    
    if (!voiceChannel || !vcData) {
      return interaction.reply({ content: '❌ Channel no longer exists!', ephemeral: true });
    }
    
    if (userId === vcData.ownerId) {
      return interaction.reply({ content: '❌ You cannot ban yourself!', ephemeral: true });
    }
    
    try {
      const user = await interaction.guild.members.fetch(userId);
      
      if (!user) {
        return interaction.reply({ content: '❌ User not found!', ephemeral: true });
      }
      
      await voiceChannel.permissionOverwrites.edit(user.id, {
        Connect: false,
        ViewChannel: false,
        Speak: false,
      });
      
      if (user.voice?.channelId === voiceChannelId) {
        await user.voice.disconnect('Banned by channel owner');
      }
      
      const bannedUsers = vcData.bannedUsers || [];
      if (!bannedUsers.includes(userId)) {
        bannedUsers.push(userId);
        updateVCData(voiceChannelId, { bannedUsers });
      }
      
      await interaction.reply({ 
        content: `🚫 ${user} has been **banned** from your channel!`, 
        ephemeral: true 
      });
    } catch (error) {
      console.error('[VCControls] Block error:', error);
      await interaction.reply({ content: '❌ Failed to ban user! Make sure the user ID is valid.', ephemeral: true });
    }
  }
  
  else if (customId.startsWith('vc_coowner_modal_')) {
    const voiceChannelId = customId.replace('vc_coowner_modal_', '');
    let userId = interaction.fields.getTextInputValue('coowner_user_id');
    
    userId = userId.replace(/[<@!>]/g, '');
    
    const voiceChannel = interaction.guild.channels.cache.get(voiceChannelId);
    const vcData = getVCData(voiceChannelId);
    
    if (!voiceChannel || !vcData) {
      return interaction.reply({ content: '❌ Channel no longer exists!', ephemeral: true });
    }
    
    if (userId === vcData.ownerId) {
      return interaction.reply({ content: '❌ You are already the owner!', ephemeral: true });
    }
    
    try {
      const user = await interaction.guild.members.fetch(userId);
      
      if (!user) {
        return interaction.reply({ content: '❌ User not found!', ephemeral: true });
      }
      
      const coOwners = vcData.coOwners || [];
      
      if (coOwners.includes(userId)) {
        const index = coOwners.indexOf(userId);
        coOwners.splice(index, 1);
        updateVCData(voiceChannelId, { coOwners });
        
        await voiceChannel.permissionOverwrites.edit(user.id, {
          ManageChannels: false,
          MoveMembers: false,
          MuteMembers: false,
          DeafenMembers: false,
        });
        
        await interaction.reply({ 
          content: `👑 ${user} has been **removed** as Co-Owner!`, 
          ephemeral: true 
        });
      } else {
        coOwners.push(userId);
        updateVCData(voiceChannelId, { coOwners });
        
        await voiceChannel.permissionOverwrites.edit(user.id, {
          ManageChannels: true,
          MoveMembers: true,
          MuteMembers: true,
          DeafenMembers: true,
          Connect: true,
          Speak: true,
          ViewChannel: true,
          SendMessages: true,
        });
        
        await interaction.reply({ 
          content: `👑 ${user} is now a **Co-Owner** of your channel!`, 
          ephemeral: true 
        });
        
        await voiceChannel.send({ 
          content: `👑 **New Co-Owner!** ${user} can now manage this channel.` 
        });
      }
    } catch (error) {
      console.error('[VCControls] CoOwner error:', error);
      await interaction.reply({ content: '❌ Failed to add co-owner! Make sure the user ID is valid.', ephemeral: true });
    }
  }
}
