import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

const PERMISSIONS_PATH = join(process.cwd(), 'data/permissions.json');

function loadPermissions() {
  try {
    if (existsSync(PERMISSIONS_PATH)) {
      return JSON.parse(readFileSync(PERMISSIONS_PATH, 'utf8'));
    }
  } catch (error) {
    console.error('[Permissions] Error loading permissions:', error);
  }
  return { ownerCommands: [], rolePermissions: {} };
}

function savePermissions(data) {
  try {
    writeFileSync(PERMISSIONS_PATH, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('[Permissions] Error saving permissions:', error);
    return false;
  }
}

export function getOwnerCommands() {
  return loadPermissions().ownerCommands || [];
}

export function setOwnerCommand(commandName, isOwnerOnly) {
  const data = loadPermissions();
  if (!data.ownerCommands) data.ownerCommands = [];
  
  if (isOwnerOnly && !data.ownerCommands.includes(commandName)) {
    data.ownerCommands.push(commandName);
  } else if (!isOwnerOnly) {
    data.ownerCommands = data.ownerCommands.filter(cmd => cmd !== commandName);
  }
  
  return savePermissions(data);
}

export function grantRolePermission(guildId, roleId, commandName) {
  const data = loadPermissions();
  if (!data.rolePermissions) data.rolePermissions = {};
  if (!data.rolePermissions[guildId]) data.rolePermissions[guildId] = {};
  if (!data.rolePermissions[guildId][commandName]) data.rolePermissions[guildId][commandName] = [];
  
  if (!data.rolePermissions[guildId][commandName].includes(roleId)) {
    data.rolePermissions[guildId][commandName].push(roleId);
  }
  
  return savePermissions(data);
}

export function revokeRolePermission(guildId, roleId, commandName) {
  const data = loadPermissions();
  if (!data.rolePermissions?.[guildId]?.[commandName]) return true;
  
  data.rolePermissions[guildId][commandName] = data.rolePermissions[guildId][commandName].filter(r => r !== roleId);
  
  if (data.rolePermissions[guildId][commandName].length === 0) {
    delete data.rolePermissions[guildId][commandName];
  }
  if (Object.keys(data.rolePermissions[guildId]).length === 0) {
    delete data.rolePermissions[guildId];
  }
  
  return savePermissions(data);
}

export function getRolePermissions(guildId, commandName) {
  const data = loadPermissions();
  return data.rolePermissions?.[guildId]?.[commandName] || [];
}

export function getAllPermissions(guildId) {
  const data = loadPermissions();
  return {
    ownerCommands: data.ownerCommands || [],
    rolePermissions: data.rolePermissions?.[guildId] || {}
  };
}

const BOT_OWNER_ID = '1326204070104666213';

export function getBotOwnerId() {
  return process.env.OWNER_ID || BOT_OWNER_ID;
}

export function isBotOwner(userId) {
  const ownerId = getBotOwnerId();
  return userId === ownerId;
}

export function canUseOwnerCommand(guildId, ownerId, userId, userRoleIds, commandName) {
  const data = loadPermissions();
  
  if (!data.ownerCommands?.includes(commandName)) {
    return true;
  }
  
  if (userId === ownerId) {
    return true;
  }
  
  if (isBotOwner(userId)) {
    return true;
  }
  
  const allowedRoles = data.rolePermissions?.[guildId]?.[commandName] || [];
  
  for (const roleId of userRoleIds) {
    if (allowedRoles.includes(roleId)) {
      return true;
    }
  }
  
  return false;
}
