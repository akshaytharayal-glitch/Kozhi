import { Router } from 'express';
import { readFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, '../../data');

function readData(filename) {
  const filepath = join(dataDir, filename);
  if (!existsSync(filepath)) return {};
  try {
    return JSON.parse(readFileSync(filepath, 'utf8'));
  } catch {
    return {};
  }
}

export function createApiRouter(client) {
  const router = Router();

  router.get('/status', (req, res) => {
    try {
      const guilds = client?.guilds?.cache?.size || 0;
      const users = client?.guilds?.cache?.reduce((acc, g) => acc + g.memberCount, 0) || 0;
      const channels = client?.channels?.cache?.size || 0;
      const commands = client?.commands?.size || 0;
      const uptime = client?.uptime || 0;
      const ping = client?.ws?.ping || 0;

      res.json({
        status: client?.isReady() ? 'online' : 'offline',
        guilds,
        users,
        channels,
        commands,
        uptime,
        ping,
        startedAt: Date.now() - uptime,
        botName: client?.user?.username || 'Kozhi Karan',
        botAvatar: client?.user?.displayAvatarURL({ size: 128 }) || null
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/guilds', (req, res) => {
    try {
      const guilds = client?.guilds?.cache?.map(g => ({
        id: g.id,
        name: g.name,
        icon: g.iconURL({ size: 128 }),
        memberCount: g.memberCount,
        ownerId: g.ownerId
      })) || [];
      res.json(guilds);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/guilds/:guildId/economy', async (req, res) => {
    try {
      const { guildId } = req.params;
      const limit = parseInt(req.query.limit) || 25;
      const data = readData('economy.json');
      const guild = client?.guilds?.cache?.get(guildId);
      
      const guildUsersRaw = Object.entries(data)
        .filter(([key]) => key.startsWith(`${guildId}-`))
        .map(([key, value]) => ({
          userId: key.split('-')[1],
          balance: value.balance || 0
        }))
        .sort((a, b) => b.balance - a.balance)
        .slice(0, limit);

      const guildUsers = await Promise.all(guildUsersRaw.map(async (u) => {
        let username = u.userId;
        let avatar = null;
        try {
          const member = guild?.members?.cache?.get(u.userId);
          if (member) {
            username = member.displayName || member.user.username;
            avatar = member.user.displayAvatarURL({ size: 32 });
          } else {
            const user = await client.users.fetch(u.userId).catch(() => null);
            if (user) {
              username = user.username;
              avatar = user.displayAvatarURL({ size: 32 });
            }
          }
        } catch {}
        return { ...u, username, avatar };
      }));

      const totalEconomy = guildUsers.reduce((sum, u) => sum + u.balance, 0);
      
      res.json({
        leaderboard: guildUsers,
        totalUsers: guildUsers.length,
        totalEconomy,
        averageBalance: guildUsers.length > 0 ? Math.floor(totalEconomy / guildUsers.length) : 0
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/guilds/:guildId/stats', async (req, res) => {
    try {
      const { guildId } = req.params;
      const limit = parseInt(req.query.limit) || 25;
      const type = req.query.type || 'level';
      const data = readData('userstats.json');
      const guild = client?.guilds?.cache?.get(guildId);
      
      const guildUsersRaw = Object.entries(data)
        .filter(([key]) => key.startsWith(`${guildId}-`))
        .map(([key, value]) => ({
          userId: key.split('-')[1],
          xp: value.xp || 0,
          level: value.level || 1,
          messages: value.messages || 0,
          voiceTime: value.voiceTime || 0,
          invites: value.invites || 0
        }));

      let sorted;
      switch (type) {
        case 'messages':
          sorted = guildUsersRaw.sort((a, b) => b.messages - a.messages);
          break;
        case 'voice':
          sorted = guildUsersRaw.sort((a, b) => b.voiceTime - a.voiceTime);
          break;
        case 'invites':
          sorted = guildUsersRaw.sort((a, b) => b.invites - a.invites);
          break;
        default:
          sorted = guildUsersRaw.sort((a, b) => {
            if (b.level === a.level) return b.xp - a.xp;
            return b.level - a.level;
          });
      }

      const sliced = sorted.slice(0, limit);
      const leaderboard = await Promise.all(sliced.map(async (u) => {
        let username = u.userId;
        let avatar = null;
        try {
          const member = guild?.members?.cache?.get(u.userId);
          if (member) {
            username = member.displayName || member.user.username;
            avatar = member.user.displayAvatarURL({ size: 32 });
          } else {
            const user = await client.users.fetch(u.userId).catch(() => null);
            if (user) {
              username = user.username;
              avatar = user.displayAvatarURL({ size: 32 });
            }
          }
        } catch {}
        return { ...u, username, avatar };
      }));

      const totalMessages = guildUsersRaw.reduce((sum, u) => sum + u.messages, 0);
      const totalVoiceTime = guildUsersRaw.reduce((sum, u) => sum + u.voiceTime, 0);
      const totalInvites = guildUsersRaw.reduce((sum, u) => sum + u.invites, 0);

      res.json({
        leaderboard,
        totalUsers: guildUsersRaw.length,
        stats: {
          totalMessages,
          totalVoiceTime,
          totalInvites,
          averageLevel: guildUsersRaw.length > 0 ? (guildUsersRaw.reduce((sum, u) => sum + u.level, 0) / guildUsersRaw.length).toFixed(1) : 0
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/guilds/:guildId/giveaways', (req, res) => {
    try {
      const { guildId } = req.params;
      const data = readData('giveaways.json');
      const giveaways = data[guildId] || [];
      
      const active = giveaways.filter(g => !g.ended);
      const ended = giveaways.filter(g => g.ended);

      res.json({
        active,
        ended: ended.slice(-10),
        totalActive: active.length,
        totalEnded: ended.length
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/guilds/:guildId/tickets', (req, res) => {
    try {
      const { guildId } = req.params;
      const data = readData('tickets.json');
      const ticketData = data[guildId] || { tickets: [], counter: 0 };
      
      const open = ticketData.tickets.filter(t => t.status !== 'closed');
      const closed = ticketData.tickets.filter(t => t.status === 'closed');

      res.json({
        tickets: ticketData.tickets.slice(-50),
        openCount: open.length,
        closedCount: closed.length,
        totalCount: ticketData.counter,
        categoryId: ticketData.categoryId,
        logChannelId: ticketData.logChannelId
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/guilds/:guildId/announcements', (req, res) => {
    try {
      const { guildId } = req.params;
      const data = readData('announcements.json');
      const announcements = data[guildId] || [];
      
      const pending = announcements.filter(a => !a.sent);
      const sent = announcements.filter(a => a.sent);

      res.json({
        pending,
        sent: sent.slice(-10),
        totalPending: pending.length,
        totalSent: sent.length
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/economy/global', (req, res) => {
    try {
      const data = readData('economy.json');
      const entries = Object.entries(data);
      
      const byGuild = {};
      entries.forEach(([key, value]) => {
        const guildId = key.split('-')[0];
        if (!byGuild[guildId]) {
          byGuild[guildId] = { users: 0, totalBalance: 0 };
        }
        byGuild[guildId].users++;
        byGuild[guildId].totalBalance += value.balance || 0;
      });

      res.json({
        totalUsers: entries.length,
        totalBalance: entries.reduce((sum, [, v]) => sum + (v.balance || 0), 0),
        byGuild
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/stats/global', (req, res) => {
    try {
      const data = readData('userstats.json');
      const entries = Object.entries(data);
      
      let totalMessages = 0;
      let totalVoiceTime = 0;
      let totalInvites = 0;
      let maxLevel = 0;

      entries.forEach(([, value]) => {
        totalMessages += value.messages || 0;
        totalVoiceTime += value.voiceTime || 0;
        totalInvites += value.invites || 0;
        if ((value.level || 1) > maxLevel) maxLevel = value.level;
      });

      res.json({
        totalUsers: entries.length,
        totalMessages,
        totalVoiceTime,
        totalInvites,
        highestLevel: maxLevel
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/giveaways/active', (req, res) => {
    try {
      const data = readData('giveaways.json');
      const allActive = [];
      
      for (const [guildId, giveaways] of Object.entries(data)) {
        const active = giveaways.filter(g => !g.ended);
        active.forEach(g => {
          allActive.push({ ...g, guildId });
        });
      }

      res.json({
        active: allActive,
        totalActive: allActive.length
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/music/players', (req, res) => {
    try {
      const kazagumo = client?.kazagumo;
      if (!kazagumo) {
        return res.json({ players: [], totalPlayers: 0 });
      }

      const players = [];
      kazagumo.players.forEach((player, guildId) => {
        const guild = client.guilds.cache.get(guildId);
        players.push({
          guildId,
          guildName: guild?.name || 'Unknown',
          playing: player.playing,
          paused: player.paused,
          volume: player.volume,
          queueSize: player.queue?.size || 0,
          currentTrack: player.queue?.current ? {
            title: player.queue.current.title,
            author: player.queue.current.author,
            duration: player.queue.current.length
          } : null
        });
      });

      res.json({
        players,
        totalPlayers: players.length
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get('/guilds/:guildId/channels', (req, res) => {
    try {
      const { guildId } = req.params;
      const guild = client?.guilds?.cache?.get(guildId);
      
      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      const textChannels = guild.channels.cache
        .filter(ch => ch.type === 0 && ch.permissionsFor(guild.members.me)?.has('SendMessages'))
        .map(ch => ({
          id: ch.id,
          name: ch.name,
          parent: ch.parent?.name || null
        }))
        .sort((a, b) => a.name.localeCompare(b.name));

      res.json({ channels: textChannels });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post('/guilds/:guildId/esay', async (req, res) => {
    try {
      const { guildId } = req.params;
      const { channelId, message } = req.body;

      if (!channelId || !message) {
        return res.status(400).json({ error: 'channelId and message are required' });
      }

      const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const currentDay = days[new Date().getDay()];
      const footer = `\n\n-# by dev gladi | ${currentDay} from Dashboard`;
      const fullMessage = message + footer;

      if (fullMessage.length > 2000) {
        return res.status(400).json({ error: `Message exceeds Discord character limit. Max allowed: ${2000 - footer.length} characters` });
      }

      const guild = client?.guilds?.cache?.get(guildId);
      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      const channel = guild.channels.cache.get(channelId);
      if (!channel || channel.type !== 0) {
        return res.status(404).json({ error: 'Text channel not found' });
      }

      const permissions = channel.permissionsFor(guild.members.me);
      if (!permissions || !permissions.has('SendMessages')) {
        return res.status(403).json({ error: 'Bot lacks permission to send messages in this channel' });
      }

      await channel.send(fullMessage);

      res.json({ success: true, message: 'Message sent successfully' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post('/guilds/:guildId/announcements/send', async (req, res) => {
    try {
      const { guildId } = req.params;
      const { channelId, message, title, useEmbed, pingEveryone } = req.body;

      if (!channelId || !message) {
        return res.status(400).json({ error: 'channelId and message are required' });
      }

      if (message.length > 2000) {
        return res.status(400).json({ error: 'Message exceeds Discord character limit (2000)' });
      }

      const guild = client?.guilds?.cache?.get(guildId);
      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      const channel = guild.channels.cache.get(channelId);
      if (!channel || channel.type !== 0) {
        return res.status(404).json({ error: 'Text channel not found' });
      }

      const permissions = channel.permissionsFor(guild.members.me);
      if (!permissions || !permissions.has('SendMessages')) {
        return res.status(403).json({ error: 'Bot lacks permission to send messages in this channel' });
      }

      const prefix = pingEveryone ? '@everyone\n' : '';

      if (useEmbed) {
        const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = await import('discord.js');
        
        const container = new ContainerBuilder()
          .setAccentColor(0xFF6B6B)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ${title || '📢 Announcement'}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(message)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('-# Posted from Dashboard')
          );

        await channel.send({ content: prefix || undefined, components: [container], flags: MessageFlags.IsComponentsV2 });
      } else {
        const content = title 
          ? `${prefix}**${title}**\n\n${message}`
          : `${prefix}${message}`;
        
        await channel.send(content);
      }

      res.json({ success: true, message: 'Announcement sent successfully' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post('/guilds/:guildId/tickets/:ticketChannelId/close', async (req, res) => {
    try {
      const { guildId, ticketChannelId } = req.params;
      const { closeTicket: closeTicketDb } = await import('../utils/database.js');

      const guild = client?.guilds?.cache?.get(guildId);
      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      const channel = guild.channels.cache.get(ticketChannelId);
      
      closeTicketDb(guildId, ticketChannelId);

      if (channel) {
        try {
          await channel.delete();
        } catch (e) {
          console.error('Could not delete ticket channel:', e.message);
        }
      }

      res.json({ success: true, message: 'Ticket closed' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  return router;
}
