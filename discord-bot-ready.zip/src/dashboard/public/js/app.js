let currentPage = 'overview';
let botData = {};
let selectedGuild = null;

async function fetchApi(endpoint) {
  try {
    const res = await fetch(`/api${endpoint}`);
    if (!res.ok) throw new Error(`API error: ${res.status}`);
    return await res.json();
  } catch (error) {
    console.error(`Failed to fetch ${endpoint}:`, error);
    return null;
  }
}

async function loadBotStatus() {
  const status = await fetchApi('/status');
  if (status) {
    botData.status = status;
    updateStatusIndicator(status);
    updateBotInfo(status);
  }
}

function updateBotInfo(status) {
  const avatarEl = document.getElementById('botAvatar');
  const nameEl = document.getElementById('botName');
  if (status.botAvatar && avatarEl) {
    avatarEl.src = status.botAvatar;
  }
  if (status.botName && nameEl) {
    nameEl.textContent = status.botName;
  }
}

function updateStatusIndicator(status) {
  const statusEl = document.getElementById('botStatus');
  const isOnline = status.status === 'online';
  statusEl.innerHTML = `
    <span class="status-dot ${isOnline ? 'online' : 'offline'}"></span>
    <span>${isOnline ? 'Online' : 'Offline'} - ${status.ping}ms</span>
  `;
}

function formatNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num?.toString() || '0';
}

function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d ${hours % 24}h`;
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  return `${minutes}m ${seconds % 60}s`;
}

function formatVoiceTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

function formatDuration(ms) {
  const minutes = Math.floor(ms / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

function getRankClass(index) {
  if (index === 0) return 'gold';
  if (index === 1) return 'silver';
  if (index === 2) return 'bronze';
  return 'default';
}

async function renderOverview() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const [status, guilds, globalEconomy, globalStats, activeGiveaways, musicPlayers] = await Promise.all([
    fetchApi('/status'),
    fetchApi('/guilds'),
    fetchApi('/economy/global'),
    fetchApi('/stats/global'),
    fetchApi('/giveaways/active'),
    fetchApi('/music/players')
  ]);

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon blue"><i class="fas fa-cubes"></i></div>
        <div class="value">${formatNumber(status?.guilds || 0)}</div>
        <div class="label">Servers</div>
      </div>
      <div class="stat-card">
        <div class="icon green"><i class="fas fa-users"></i></div>
        <div class="value">${formatNumber(status?.users || 0)}</div>
        <div class="label">Total Players</div>
      </div>
      <div class="stat-card">
        <div class="icon yellow"><i class="fas fa-book"></i></div>
        <div class="value">${status?.commands || 0}</div>
        <div class="label">Commands</div>
      </div>
      <div class="stat-card">
        <div class="icon red"><i class="fas fa-hourglass-half"></i></div>
        <div class="value">${formatUptime(status?.uptime || 0)}</div>
        <div class="label">Uptime</div>
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon yellow"><i class="fas fa-gem"></i></div>
        <div class="value">${formatNumber(globalEconomy?.totalBalance || 0)}</div>
        <div class="label">Total Economy</div>
      </div>
      <div class="stat-card">
        <div class="icon blue"><i class="fas fa-comment-dots"></i></div>
        <div class="value">${formatNumber(globalStats?.totalMessages || 0)}</div>
        <div class="label">Messages Tracked</div>
      </div>
      <div class="stat-card">
        <div class="icon green"><i class="fas fa-gift"></i></div>
        <div class="value">${activeGiveaways?.totalActive || 0}</div>
        <div class="label">Active Giveaways</div>
      </div>
      <div class="stat-card">
        <div class="icon red"><i class="fas fa-music"></i></div>
        <div class="value">${musicPlayers?.totalPlayers || 0}</div>
        <div class="label">Active Players</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Recent Servers</h2>
      </div>
      <div class="card-body">
        ${guilds && guilds.length > 0 ? `
          <div class="server-grid">
            ${guilds.slice(0, 6).map(g => `
              <div class="server-card" onclick="selectGuild('${g.id}')">
                <div class="header">
                  <div class="avatar">
                    ${g.icon ? `<img src="${g.icon}" alt="${g.name}">` : g.name.charAt(0)}
                  </div>
                  <div class="info">
                    <h3>${g.name}</h3>
                    <span>${formatNumber(g.memberCount)} players</span>
                  </div>
                </div>
              </div>
            `).join('')}
          </div>
        ` : `
          <div class="empty-state">
            <i class="fas fa-cubes"></i>
            <h3>No Servers</h3>
            <p>The bot is not in any servers yet.</p>
          </div>
        `}
      </div>
    </div>
  `;
}

async function renderServers() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const guilds = await fetchApi('/guilds');

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon blue"><i class="fas fa-server"></i></div>
        <div class="value">${guilds?.length || 0}</div>
        <div class="label">Total Servers</div>
      </div>
      <div class="stat-card">
        <div class="icon green"><i class="fas fa-users"></i></div>
        <div class="value">${formatNumber(guilds?.reduce((a, g) => a + g.memberCount, 0) || 0)}</div>
        <div class="label">Total Members</div>
      </div>
    </div>

    ${guilds && guilds.length > 0 ? `
      <div class="server-grid">
        ${guilds.map(g => `
          <div class="server-card" onclick="selectGuild('${g.id}')">
            <div class="header">
              <div class="avatar">
                ${g.icon ? `<img src="${g.icon}" alt="${g.name}">` : g.name.charAt(0)}
              </div>
              <div class="info">
                <h3>${g.name}</h3>
                <span>ID: ${g.id}</span>
              </div>
            </div>
            <div class="stats">
              <div class="stat">
                <i class="fas fa-users"></i>
                ${formatNumber(g.memberCount)}
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    ` : `
      <div class="empty-state">
        <i class="fas fa-server"></i>
        <h3>No Servers</h3>
        <p>The bot is not in any servers yet.</p>
      </div>
    `}
  `;
}

async function renderEconomy() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const [globalEconomy, guilds] = await Promise.all([
    fetchApi('/economy/global'),
    fetchApi('/guilds')
  ]);

  let guildSelect = '';
  if (guilds && guilds.length > 0) {
    guildSelect = `
      <div class="select-wrapper">
        <select id="guildSelect" onchange="loadGuildEconomy(this.value)">
          <option value="">Select a server</option>
          ${guilds.map(g => `<option value="${g.id}">${g.name}</option>`).join('')}
        </select>
      </div>
    `;
  }

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon yellow"><i class="fas fa-coins"></i></div>
        <div class="value">${formatNumber(globalEconomy?.totalBalance || 0)}</div>
        <div class="label">Total Eggs in Economy</div>
      </div>
      <div class="stat-card">
        <div class="icon blue"><i class="fas fa-users"></i></div>
        <div class="value">${globalEconomy?.totalUsers || 0}</div>
        <div class="label">Users with Balance</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Server Economy</h2>
        ${guildSelect}
      </div>
      <div class="card-body" id="economyContent">
        <div class="empty-state">
          <i class="fas fa-coins"></i>
          <h3>Select a Server</h3>
          <p>Choose a server to view its economy leaderboard.</p>
        </div>
      </div>
    </div>
  `;
}

async function loadGuildEconomy(guildId) {
  if (!guildId) return;
  
  const economyContent = document.getElementById('economyContent');
  economyContent.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i></div>';
  
  const data = await fetchApi(`/guilds/${guildId}/economy`);
  
  if (!data || data.leaderboard.length === 0) {
    economyContent.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-coins"></i>
        <h3>No Economy Data</h3>
        <p>No users have earned eggs in this server yet.</p>
      </div>
    `;
    return;
  }

  economyContent.innerHTML = `
    <div class="stats-grid" style="margin-bottom: 20px;">
      <div class="stat-card">
        <div class="icon yellow"><i class="fas fa-coins"></i></div>
        <div class="value">${formatNumber(data.totalEconomy)}</div>
        <div class="label">Total Server Eggs</div>
      </div>
      <div class="stat-card">
        <div class="icon blue"><i class="fas fa-calculator"></i></div>
        <div class="value">${formatNumber(data.averageBalance)}</div>
        <div class="label">Average Balance</div>
      </div>
    </div>
    <table class="table">
      <thead>
        <tr>
          <th>Rank</th>
          <th>User</th>
          <th>Balance</th>
        </tr>
      </thead>
      <tbody>
        ${data.leaderboard.map((u, i) => `
          <tr>
            <td><div class="rank ${getRankClass(i)}">${i + 1}</div></td>
            <td class="user-cell">${u.avatar ? `<img src="${u.avatar}" class="user-avatar">` : ''}<span>${u.username}</span></td>
            <td><i class="fas fa-egg" style="color: var(--warning); margin-right: 6px;"></i>${formatNumber(u.balance)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

async function renderLeaderboards() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const [globalStats, guilds] = await Promise.all([
    fetchApi('/stats/global'),
    fetchApi('/guilds')
  ]);

  let guildSelect = '';
  if (guilds && guilds.length > 0) {
    guildSelect = `
      <div class="select-wrapper">
        <select id="guildSelect" onchange="loadGuildStats(this.value)">
          <option value="">Select a server</option>
          ${guilds.map(g => `<option value="${g.id}">${g.name}</option>`).join('')}
        </select>
      </div>
    `;
  }

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon blue"><i class="fas fa-comment"></i></div>
        <div class="value">${formatNumber(globalStats?.totalMessages || 0)}</div>
        <div class="label">Total Messages</div>
      </div>
      <div class="stat-card">
        <div class="icon green"><i class="fas fa-headphones"></i></div>
        <div class="value">${formatVoiceTime(globalStats?.totalVoiceTime || 0)}</div>
        <div class="label">Total Voice Time</div>
      </div>
      <div class="stat-card">
        <div class="icon yellow"><i class="fas fa-user-plus"></i></div>
        <div class="value">${globalStats?.totalInvites || 0}</div>
        <div class="label">Total Invites</div>
      </div>
      <div class="stat-card">
        <div class="icon red"><i class="fas fa-star"></i></div>
        <div class="value">${globalStats?.highestLevel || 1}</div>
        <div class="label">Highest Level</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Server Leaderboards</h2>
        <div style="display: flex; gap: 12px;">
          ${guildSelect}
          <div class="select-wrapper">
            <select id="typeSelect" onchange="updateLeaderboardType()">
              <option value="level">Level</option>
              <option value="messages">Messages</option>
              <option value="voice">Voice Time</option>
              <option value="invites">Invites</option>
            </select>
          </div>
        </div>
      </div>
      <div class="card-body" id="statsContent">
        <div class="empty-state">
          <i class="fas fa-trophy"></i>
          <h3>Select a Server</h3>
          <p>Choose a server to view its leaderboards.</p>
        </div>
      </div>
    </div>
  `;
}

async function loadGuildStats(guildId) {
  if (!guildId) return;
  selectedGuild = guildId;
  
  const type = document.getElementById('typeSelect')?.value || 'level';
  const statsContent = document.getElementById('statsContent');
  statsContent.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i></div>';
  
  const data = await fetchApi(`/guilds/${guildId}/stats?type=${type}`);
  
  if (!data || data.leaderboard.length === 0) {
    statsContent.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-trophy"></i>
        <h3>No Stats Data</h3>
        <p>No user activity has been tracked in this server yet.</p>
      </div>
    `;
    return;
  }

  const headers = {
    level: ['Rank', 'User', 'Level', 'XP'],
    messages: ['Rank', 'User', 'Messages'],
    voice: ['Rank', 'User', 'Voice Time'],
    invites: ['Rank', 'User', 'Invites']
  };

  statsContent.innerHTML = `
    <table class="table">
      <thead>
        <tr>
          ${headers[type].map(h => `<th>${h}</th>`).join('')}
        </tr>
      </thead>
      <tbody>
        ${data.leaderboard.map((u, i) => `
          <tr>
            <td><div class="rank ${getRankClass(i)}">${i + 1}</div></td>
            <td class="user-cell">${u.avatar ? `<img src="${u.avatar}" class="user-avatar">` : ''}<span>${u.username}</span></td>
            ${type === 'level' ? `
              <td><span class="badge info">Lv. ${u.level}</span></td>
              <td>${formatNumber(u.xp)} XP</td>
            ` : ''}
            ${type === 'messages' ? `<td>${formatNumber(u.messages)}</td>` : ''}
            ${type === 'voice' ? `<td>${formatVoiceTime(u.voiceTime)}</td>` : ''}
            ${type === 'invites' ? `<td>${u.invites}</td>` : ''}
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function updateLeaderboardType() {
  if (selectedGuild) {
    loadGuildStats(selectedGuild);
  }
}

async function renderGiveaways() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const [activeGiveaways, guilds] = await Promise.all([
    fetchApi('/giveaways/active'),
    fetchApi('/guilds')
  ]);

  const guildMap = {};
  guilds?.forEach(g => guildMap[g.id] = g.name);

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon green"><i class="fas fa-gift"></i></div>
        <div class="value">${activeGiveaways?.totalActive || 0}</div>
        <div class="label">Active Giveaways</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Active Giveaways</h2>
      </div>
      <div class="card-body">
        ${activeGiveaways?.active?.length > 0 ? `
          ${activeGiveaways.active.map(g => `
            <div class="giveaway-card">
              <div class="prize"><i class="fas fa-gift" style="color: var(--accent); margin-right: 8px;"></i>${g.prize}</div>
              <div class="details">
                <span><i class="fas fa-server"></i> ${guildMap[g.guildId] || 'Unknown Server'}</span>
                <span><i class="fas fa-users"></i> ${g.winners || 1} winner(s)</span>
                <span><i class="fas fa-clock"></i> Ends ${new Date(g.endTime).toLocaleString()}</span>
              </div>
            </div>
          `).join('')}
        ` : `
          <div class="empty-state">
            <i class="fas fa-gift"></i>
            <h3>No Active Giveaways</h3>
            <p>There are no giveaways running right now.</p>
          </div>
        `}
      </div>
    </div>
  `;
}

async function renderMusic() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const musicPlayers = await fetchApi('/music/players');

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon red"><i class="fas fa-music"></i></div>
        <div class="value">${musicPlayers?.totalPlayers || 0}</div>
        <div class="label">Active Music Players</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Active Players</h2>
      </div>
      <div class="card-body">
        ${musicPlayers?.players?.length > 0 ? `
          ${musicPlayers.players.map(p => `
            <div class="music-player">
              <div class="guild-name">
                <i class="fas fa-server"></i>
                ${p.guildName}
                <span class="badge ${p.playing ? 'success' : 'warning'}">${p.playing ? 'Playing' : 'Paused'}</span>
              </div>
              ${p.currentTrack ? `
                <div class="track-info">
                  <i class="fas ${p.playing ? 'fa-play-circle' : 'fa-pause-circle'}"></i>
                  <div class="track-details">
                    <h4>${p.currentTrack.title}</h4>
                    <span>${p.currentTrack.author} • ${formatDuration(p.currentTrack.duration)}</span>
                  </div>
                </div>
              ` : `
                <div class="track-info">
                  <i class="fas fa-music"></i>
                  <div class="track-details">
                    <h4>No track playing</h4>
                    <span>Queue: ${p.queueSize} tracks</span>
                  </div>
                </div>
              `}
            </div>
          `).join('')}
        ` : `
          <div class="empty-state">
            <i class="fas fa-music"></i>
            <h3>No Active Players</h3>
            <p>No music is currently playing in any server.</p>
          </div>
        `}
      </div>
    </div>
  `;
}

function selectGuild(guildId) {
  selectedGuild = guildId;
  switchPage('economy');
  setTimeout(() => {
    const select = document.getElementById('guildSelect');
    if (select) {
      select.value = guildId;
      loadGuildEconomy(guildId);
    }
  }, 100);
}

async function renderAnnouncements() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const guilds = await fetchApi('/guilds');

  let guildSelect = '';
  if (guilds && guilds.length > 0) {
    guildSelect = `
      <div class="select-wrapper">
        <select id="guildSelect" onchange="loadGuildAnnouncements(this.value)">
          <option value="">Select a server</option>
          ${guilds.map(g => `<option value="${g.id}">${g.name}</option>`).join('')}
        </select>
      </div>
    `;
  }

  content.innerHTML = `
    <div class="card">
      <div class="card-header">
        <h2>Send Announcement</h2>
        ${guildSelect}
      </div>
      <div class="card-body" id="announcementContent">
        <div class="empty-state">
          <i class="fas fa-bullhorn"></i>
          <h3>Select a Server</h3>
          <p>Choose a server to send announcements.</p>
        </div>
      </div>
    </div>
  `;
}

async function loadGuildAnnouncements(guildId) {
  if (!guildId) return;
  selectedGuild = guildId;
  
  const announcementContent = document.getElementById('announcementContent');
  announcementContent.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i></div>';
  
  const [channels, announcements] = await Promise.all([
    fetchApi(`/guilds/${guildId}/channels`),
    fetchApi(`/guilds/${guildId}/announcements`)
  ]);
  
  const channelOptions = channels?.channels?.map(ch => 
    `<option value="${ch.id}">#${ch.name}${ch.parent ? ` (${ch.parent})` : ''}</option>`
  ).join('') || '';

  announcementContent.innerHTML = `
    <div class="form-section">
      <h3><i class="fas fa-paper-plane"></i> New Announcement</h3>
      <div class="form-group">
        <label>Channel</label>
        <select id="annChannel" class="form-control">
          <option value="">Select channel</option>
          ${channelOptions}
        </select>
      </div>
      <div class="form-group">
        <label>Title (optional)</label>
        <input type="text" id="annTitle" class="form-control" placeholder="Announcement title...">
      </div>
      <div class="form-group">
        <label>Message</label>
        <textarea id="annMessage" class="form-control" rows="4" placeholder="Your announcement message..."></textarea>
      </div>
      <div class="form-row">
        <label class="checkbox-label">
          <input type="checkbox" id="annEmbed" checked>
          Use Container v2 Style
        </label>
        <label class="checkbox-label">
          <input type="checkbox" id="annPing">
          Ping @everyone
        </label>
      </div>
      <button class="btn btn-primary" onclick="sendAnnouncement('${guildId}')">
        <i class="fas fa-bullhorn"></i> Send Announcement
      </button>
      <div id="annStatus" class="status-message"></div>
    </div>
    
    ${announcements?.pending?.length > 0 ? `
      <div class="form-section" style="margin-top: 24px;">
        <h3><i class="fas fa-clock"></i> Scheduled Announcements</h3>
        <div class="list-items">
          ${announcements.pending.map(a => `
            <div class="list-item">
              <div class="item-info">
                <strong>${a.title || 'No Title'}</strong>
                <span>${a.message.substring(0, 50)}${a.message.length > 50 ? '...' : ''}</span>
                <small>Posts: ${new Date(a.publishTime).toLocaleString()}</small>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    ` : ''}
  `;
}

async function sendAnnouncement(guildId) {
  const channelId = document.getElementById('annChannel').value;
  const title = document.getElementById('annTitle').value;
  const message = document.getElementById('annMessage').value;
  const useEmbed = document.getElementById('annEmbed').checked;
  const pingEveryone = document.getElementById('annPing').checked;
  const statusEl = document.getElementById('annStatus');
  
  if (!channelId || !message) {
    statusEl.innerHTML = '<span class="error">Please select a channel and enter a message</span>';
    return;
  }
  
  statusEl.innerHTML = '<span class="loading-text"><i class="fas fa-spinner fa-spin"></i> Sending...</span>';
  
  try {
    const res = await fetch(`/api/guilds/${guildId}/announcements/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channelId, title, message, useEmbed, pingEveryone })
    });
    
    const data = await res.json();
    
    if (data.success) {
      statusEl.innerHTML = '<span class="success"><i class="fas fa-check"></i> Announcement sent!</span>';
      document.getElementById('annTitle').value = '';
      document.getElementById('annMessage').value = '';
    } else {
      statusEl.innerHTML = `<span class="error"><i class="fas fa-times"></i> ${data.error}</span>`;
    }
  } catch (error) {
    statusEl.innerHTML = `<span class="error"><i class="fas fa-times"></i> ${error.message}</span>`;
  }
}

async function renderEsay() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const guilds = await fetchApi('/guilds');

  let guildSelect = '';
  if (guilds && guilds.length > 0) {
    guildSelect = `
      <div class="select-wrapper">
        <select id="guildSelect" onchange="loadGuildEsay(this.value)">
          <option value="">Select a server</option>
          ${guilds.map(g => `<option value="${g.id}">${g.name}</option>`).join('')}
        </select>
      </div>
    `;
  }

  content.innerHTML = `
    <div class="card">
      <div class="card-header">
        <h2>Say Exclusive</h2>
        ${guildSelect}
      </div>
      <div class="card-body" id="esayContent">
        <div class="empty-state">
          <i class="fas fa-comment-dots"></i>
          <h3>Select a Server</h3>
          <p>Choose a server to send messages as the bot.</p>
        </div>
      </div>
    </div>
  `;
}

async function loadGuildEsay(guildId) {
  if (!guildId) return;
  selectedGuild = guildId;
  
  const esayContent = document.getElementById('esayContent');
  esayContent.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i></div>';
  
  const channels = await fetchApi(`/guilds/${guildId}/channels`);
  
  const channelOptions = channels?.channels?.map(ch => 
    `<option value="${ch.id}">#${ch.name}${ch.parent ? ` (${ch.parent})` : ''}</option>`
  ).join('') || '';

  esayContent.innerHTML = `
    <div class="form-section">
      <h3><i class="fas fa-robot"></i> Send Message as Bot</h3>
      <p class="form-description">This allows you to send a message to any channel as the bot. The message will appear as if the bot sent it directly.</p>
      <div class="form-group">
        <label>Channel</label>
        <select id="esayChannel" class="form-control">
          <option value="">Select channel</option>
          ${channelOptions}
        </select>
      </div>
      <div class="form-group">
        <label>Message</label>
        <textarea id="esayMessage" class="form-control" rows="4" placeholder="Type your message here... Supports Discord markdown!"></textarea>
      </div>
      <button class="btn btn-primary" onclick="sendEsay('${guildId}')">
        <i class="fas fa-paper-plane"></i> Send Message
      </button>
      <div id="esayStatus" class="status-message"></div>
    </div>
    
    <div class="form-section" style="margin-top: 24px;">
      <h3><i class="fas fa-info-circle"></i> Formatting Tips</h3>
      <div class="tips-grid">
        <div class="tip"><code>**bold**</code> - <strong>bold</strong></div>
        <div class="tip"><code>*italic*</code> - <em>italic</em></div>
        <div class="tip"><code>~~strike~~</code> - <del>strike</del></div>
        <div class="tip"><code>\`code\`</code> - <code>code</code></div>
      </div>
    </div>
  `;
}

async function sendEsay(guildId) {
  const channelId = document.getElementById('esayChannel').value;
  const message = document.getElementById('esayMessage').value;
  const statusEl = document.getElementById('esayStatus');
  
  if (!channelId || !message) {
    statusEl.innerHTML = '<span class="error">Please select a channel and enter a message</span>';
    return;
  }
  
  statusEl.innerHTML = '<span class="loading-text"><i class="fas fa-spinner fa-spin"></i> Sending...</span>';
  
  try {
    const res = await fetch(`/api/guilds/${guildId}/esay`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channelId, message })
    });
    
    const data = await res.json();
    
    if (data.success) {
      statusEl.innerHTML = '<span class="success"><i class="fas fa-check"></i> Message sent!</span>';
      document.getElementById('esayMessage').value = '';
    } else {
      statusEl.innerHTML = `<span class="error"><i class="fas fa-times"></i> ${data.error}</span>`;
    }
  } catch (error) {
    statusEl.innerHTML = `<span class="error"><i class="fas fa-times"></i> ${error.message}</span>`;
  }
}

async function renderTickets() {
  const content = document.getElementById('content');
  content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><span>Loading...</span></div>';
  
  const guilds = await fetchApi('/guilds');

  let guildSelect = '';
  if (guilds && guilds.length > 0) {
    guildSelect = `
      <div class="select-wrapper">
        <select id="guildSelect" onchange="loadGuildTickets(this.value)">
          <option value="">Select a server</option>
          ${guilds.map(g => `<option value="${g.id}">${g.name}</option>`).join('')}
        </select>
      </div>
    `;
  }

  content.innerHTML = `
    <div class="card">
      <div class="card-header">
        <h2>Ticket Management</h2>
        ${guildSelect}
      </div>
      <div class="card-body" id="ticketContent">
        <div class="empty-state">
          <i class="fas fa-ticket-alt"></i>
          <h3>Select a Server</h3>
          <p>Choose a server to manage tickets.</p>
        </div>
      </div>
    </div>
  `;
}

async function loadGuildTickets(guildId) {
  if (!guildId) return;
  selectedGuild = guildId;
  
  const ticketContent = document.getElementById('ticketContent');
  ticketContent.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i></div>';
  
  const data = await fetchApi(`/guilds/${guildId}/tickets`);
  
  if (!data) {
    ticketContent.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle"></i>
        <h3>Error Loading Tickets</h3>
        <p>Could not fetch ticket data.</p>
      </div>
    `;
    return;
  }

  const openTickets = data.tickets?.filter(t => t.status !== 'closed') || [];
  const closedTickets = data.tickets?.filter(t => t.status === 'closed') || [];

  ticketContent.innerHTML = `
    <div class="stats-grid" style="margin-bottom: 20px;">
      <div class="stat-card">
        <div class="icon green"><i class="fas fa-folder-open"></i></div>
        <div class="value">${data.openCount || 0}</div>
        <div class="label">Open Tickets</div>
      </div>
      <div class="stat-card">
        <div class="icon red"><i class="fas fa-folder"></i></div>
        <div class="value">${data.closedCount || 0}</div>
        <div class="label">Closed Tickets</div>
      </div>
      <div class="stat-card">
        <div class="icon blue"><i class="fas fa-hashtag"></i></div>
        <div class="value">${data.totalCount || 0}</div>
        <div class="label">Total Created</div>
      </div>
    </div>

    <div class="form-section">
      <h3><i class="fas fa-folder-open"></i> Open Tickets</h3>
      ${openTickets.length > 0 ? `
        <div class="ticket-list">
          ${openTickets.map(t => `
            <div class="ticket-item">
              <div class="ticket-info">
                <strong>#${t.id}</strong>
                <span>User: ${t.userId}</span>
                <small>Created: ${new Date(t.createdAt).toLocaleString()}</small>
              </div>
              <div class="ticket-actions">
                <button class="btn btn-danger btn-sm" onclick="closeTicket('${guildId}', '${t.channelId}')">
                  <i class="fas fa-times"></i> Close
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      ` : `
        <div class="empty-state small">
          <i class="fas fa-check-circle"></i>
          <p>No open tickets</p>
        </div>
      `}
    </div>

    <div class="form-section" style="margin-top: 24px;">
      <h3><i class="fas fa-history"></i> Recently Closed</h3>
      ${closedTickets.length > 0 ? `
        <div class="ticket-list">
          ${closedTickets.slice(-10).reverse().map(t => `
            <div class="ticket-item closed">
              <div class="ticket-info">
                <strong>#${t.id}</strong>
                <span>User: ${t.userId}</span>
                <small>Created: ${new Date(t.createdAt).toLocaleString()}</small>
              </div>
              <span class="badge warning">Closed</span>
            </div>
          `).join('')}
        </div>
      ` : `
        <div class="empty-state small">
          <i class="fas fa-inbox"></i>
          <p>No closed tickets yet</p>
        </div>
      `}
    </div>
  `;
}

async function closeTicket(guildId, channelId) {
  if (!confirm('Are you sure you want to close this ticket?')) return;
  
  try {
    const res = await fetch(`/api/guilds/${guildId}/tickets/${channelId}/close`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    
    const data = await res.json();
    
    if (data.success) {
      loadGuildTickets(guildId);
    } else {
      alert('Error: ' + data.error);
    }
  } catch (error) {
    alert('Error: ' + error.message);
  }
}

function switchPage(page) {
  currentPage = page;
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.page === page);
  });
  
  const titles = {
    overview: 'Overview',
    servers: 'Servers',
    economy: 'Economy',
    leaderboards: 'Leaderboards',
    giveaways: 'Giveaways',
    music: 'Music',
    announcements: 'Announcements',
    esay: 'Say Exclusive',
    tickets: 'Tickets'
  };
  
  document.getElementById('pageTitle').textContent = titles[page] || page.charAt(0).toUpperCase() + page.slice(1);
  
  switch (page) {
    case 'overview': renderOverview(); break;
    case 'servers': renderServers(); break;
    case 'economy': renderEconomy(); break;
    case 'leaderboards': renderLeaderboards(); break;
    case 'giveaways': renderGiveaways(); break;
    case 'music': renderMusic(); break;
    case 'announcements': renderAnnouncements(); break;
    case 'esay': renderEsay(); break;
    case 'tickets': renderTickets(); break;
  }
}

function refreshData() {
  loadBotStatus();
  switchPage(currentPage);
}

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', (e) => {
    e.preventDefault();
    switchPage(item.dataset.page);
  });
});

loadBotStatus();
renderOverview();

setInterval(loadBotStatus, 30000);

function createSnow() {
  const snowContainer = document.createElement('div');
  snowContainer.className = 'snow-container';
  document.body.appendChild(snowContainer);

  const snowflakes = ['❄', '❅', '❆', '✻', '✼', '❋'];
  const maxSnowflakes = 35;

  function createSnowflake() {
    if (snowContainer.children.length >= maxSnowflakes) return;

    const snowflake = document.createElement('div');
    snowflake.className = 'snowflake';
    snowflake.textContent = snowflakes[Math.floor(Math.random() * snowflakes.length)];
    snowflake.style.left = Math.random() * 100 + 'vw';
    snowflake.style.fontSize = (Math.random() * 10 + 8) + 'px';
    snowflake.style.opacity = Math.random() * 0.6 + 0.4;
    snowflake.style.animationDuration = (Math.random() * 5 + 8) + 's';

    snowContainer.appendChild(snowflake);

    snowflake.addEventListener('animationend', () => {
      snowflake.remove();
    });
  }

  for (let i = 0; i < 15; i++) {
    setTimeout(createSnowflake, i * 300);
  }

  setInterval(createSnowflake, 400);
}

createSnow();
