import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { createApiRouter } from './api.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export function createDashboardServer(client) {
  const app = express();
  const PORT = process.env.DASHBOARD_PORT || 5000;

  app.use(cors());
  app.use(express.json());
  app.use(cookieParser());

  app.use(express.static(join(__dirname, 'public')));

  app.use('/api', createApiRouter(client));

  app.use((req, res, next) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(join(__dirname, 'public', 'index.html'));
    } else {
      next();
    }
  });

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Dashboard] Running on http://0.0.0.0:${PORT}`);
  });

  return server;
}
