import { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags, ThumbnailBuilder, SectionBuilder } from 'discord.js';
import { getCountGame, setCountGame, addBalance, removeBalance, getBalance, getLeaderboard, getDailyReward, setDailyReward, addXP, getUserStats, calculateXPForLevel, getStatsLeaderboard } from '../utils/database.js';
import { isCommandAllowedInChannel } from '../config/channelRestrictions.js';
import { getAIChannelSettings } from '../commands/utility/ai.js';
import { generateAIResponse } from '../utils/aiChat.js';
import { getBannedWords, isFilterEnabled } from '../commands/management/wordfilter.js';
import { isBotOwner } from '../utils/permissions.js';
import https from 'https';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DEFAULT_PREFIX = 'e';
const cooldowns = new Map();
const xpCooldowns = new Map();

const PREFIXES_FILE = path.join(__dirname, '../../data/prefixes.json');

let prefixCache = null;

function loadPrefixes() {
  if (prefixCache !== null) {
    return prefixCache;
  }
  try {
    if (fs.existsSync(PREFIXES_FILE)) {
      prefixCache = JSON.parse(fs.readFileSync(PREFIXES_FILE, 'utf8'));
    } else {
      prefixCache = {};
    }
  } catch (error) {
    console.error('[Prefixes] Error loading prefixes:', error);
    prefixCache = {};
  }
  return prefixCache;
}

function savePrefixes(prefixes) {
  try {
    fs.writeFileSync(PREFIXES_FILE, JSON.stringify(prefixes, null, 2));
    prefixCache = prefixes;
  } catch (error) {
    console.error('[Prefixes] Error saving prefixes:', error);
  }
}

export function getPrefix(guildId) {
  const prefixes = loadPrefixes();
  return prefixes[guildId] || DEFAULT_PREFIX;
}

export function setPrefix(guildId, newPrefix) {
  const prefixes = loadPrefixes();
  prefixes[guildId] = newPrefix;
  savePrefixes(prefixes);
}

const OWNER_ID = process.env.OWNER_ID || '';

const OWNER_REACTIONS = ['👑', '✨', '💎', '🔥', '⭐'];

export default {
  name: 'messageCreate',
  async execute(message, client) {
    try {
      if (message.author.bot) return;
      if (!message.guild) return;
      
      if (isFilterEnabled(message.guild.id)) {
        const bannedWords = getBannedWords(message.guild.id);
        const messageContent = message.content.toLowerCase();
        
        for (const word of bannedWords) {
          if (messageContent.includes(word.toLowerCase())) {
            try {
              await message.delete();
              
              try {
                await message.author.send({
                  content: `**athokke nende serveril** - Your message in **${message.guild.name}** was deleted because it contained a restricted word/phrase.`
                });
              } catch (dmError) {
                console.log(`[WordFilter] Could not DM ${message.author.username} - DMs may be disabled`);
              }
              
              console.log(`[WordFilter] Deleted message from ${message.author.username} containing banned word in ${message.guild.name}`);
            } catch (deleteError) {
              console.error('[WordFilter] Error deleting message:', deleteError.message);
            }
            return;
          }
        }
      }
      
      if (OWNER_ID && message.mentions.users.has(OWNER_ID)) {
        try {
          for (const reaction of OWNER_REACTIONS) {
            await message.react(reaction);
          }
        } catch (error) {
          console.error('Failed to add owner reactions:', error);
        }
      }
      
      const aiSettings = getAIChannelSettings();
      const guildAISettings = aiSettings[message.guild.id];
      if (guildAISettings?.enabled && guildAISettings?.channelId === message.channel.id) {
        try {
          await message.channel.sendTyping();
          const response = await generateAIResponse(message);
          if (response) {
            if (response.length > 2000) {
              const chunks = response.match(/.{1,1990}/gs) || [];
              for (const chunk of chunks) {
                await message.reply(chunk);
              }
            } else {
              await message.reply(response);
            }
          }
        } catch (error) {
          console.error('[AI Chat] Error:', error);
        }
        return;
      }
      
      try {
        await handleXP(message, client);
      } catch (error) {
        console.error('[XP Handler] Error:', error);
      }
      
      const prefix = getPrefix(message.guild.id);
      if (message.content.toLowerCase().startsWith(prefix.toLowerCase())) {
        try {
          await handlePrefixCommand(message, client, prefix);
        } catch (error) {
          console.error('[Prefix Command] Error:', error);
        }
      }
      
      try {
        const countGame = getCountGame(message.guild.id);
        
        if (countGame.channelId && message.channel.id === countGame.channelId) {
          const number = parseInt(message.content);
          
          if (isNaN(number)) return;
          
          if (message.author.id === countGame.lastUserId) {
            await message.react('❌').catch(() => {});
            await message.reply(`You can't count twice in a row! The count has been reset. We reached **${countGame.currentNumber}**!`).catch(() => {});
            
            if (countGame.currentNumber > countGame.highScore) {
              countGame.highScore = countGame.currentNumber;
            }
            countGame.currentNumber = 0;
            countGame.lastUserId = null;
            setCountGame(message.guild.id, countGame);
            return;
          }
          
          if (number === countGame.currentNumber + 1) {
            await message.react('✅').catch(() => {});
            countGame.currentNumber = number;
            countGame.lastUserId = message.author.id;
        
        if (number > countGame.highScore) {
          countGame.highScore = number;
        }
        
        if (number % 10 === 0) {
          addBalance(message.guild.id, message.author.id, 10);
          await message.reply(`Milestone! You earned **10 eggs** for reaching ${number}!`);
        } else if (number % 5 === 0) {
          addBalance(message.guild.id, message.author.id, 5);
        }
        
        setCountGame(message.guild.id, countGame);
      } else {
        await message.react('❌').catch(() => {});
        await message.reply(`pottan ano budhi elle\n\nWrong number! Expected **${countGame.currentNumber + 1}**. The count has been reset. We reached **${countGame.currentNumber}**!`).catch(() => {});
        
        if (countGame.currentNumber > countGame.highScore) {
          countGame.highScore = countGame.currentNumber;
        }
        countGame.currentNumber = 0;
        countGame.lastUserId = null;
        setCountGame(message.guild.id, countGame);
      }
    }
      } catch (error) {
        console.error('[Count Game] Error:', error);
      }
    } catch (error) {
      console.error('[MessageCreate] Error:', error);
    }
  },
};

const commandAliasMap = {
  'balance': 'balance', 'bal': 'balance',
  'daily': 'daily',
  'gather': 'gather',
  'rob': 'rob',
  'give': 'give',
  'leaderboard': 'leaderboard', 'lb': 'leaderboard',
  'coinflip': 'coinflip', 'cf': 'coinflip', 'flip': 'coinflip',
  'dice': 'dice', 'roll': 'dice',
  'slots': 'slots', 'slot': 'slots', 'gamble': 'slots',
  'level': 'level', 'lvl': 'level', 'rank': 'level',
  'stats': 'stats', 'mystats': 'stats',
  'leaderboards': 'leaderboards', 'lbs': 'leaderboards',
  'truthordare': 'truthordare', 'tod': 'truthordare', 'tord': 'truthordare',
  'gay': 'gay', 'howgay': 'gay', 'gaymeter': 'gay',
  'marriage': 'marriage', 'marry': 'marriage', 'ship': 'marriage', 'love': 'marriage',
  'meme': 'meme', 'memes': 'meme', 'reddit': 'meme', 'funny': 'meme',
  'joke': 'joke', 'jokes': 'joke', 'lol': 'joke', 'haha': 'joke',
  'dadjoke': 'dadjoke', 'dad': 'dadjoke', 'dj': 'dadjoke', 'fatherjoke': 'dadjoke',
  'jokeoftheday': 'jokeoftheday', 'jotd': 'jokeoftheday', 'dailyjoke': 'jokeoftheday', 'todaysjoke': 'jokeoftheday',
  'rps': 'rps', 'rockpaperscissors': 'rps', 'roshambo': 'rps',
  'trivia': 'trivia', 'quiz': 'trivia', 'question': 'trivia', 'q': 'trivia',
  'wouldyourather': 'wouldyourather', 'wyr': 'wouldyourather', 'rather': 'wouldyourather', 'wouldurather': 'wouldyourather',
  'hangman': 'hangman', 'hang': 'hangman', 'hm': 'hangman',
  'play': 'play', 'p': 'play',
  'skip': 'skip', 's': 'skip', 'next': 'skip',
  'stop': 'stop', 'disconnect': 'stop', 'dc': 'stop', 'leave': 'stop',
  'pause': 'pause',
  'resume': 'resume', 'unpause': 'resume',
  'queue': 'queue', 'q': 'queue',
  'nowplaying': 'nowplaying', 'np': 'nowplaying', 'current': 'nowplaying',
  'volume': 'volume', 'vol': 'volume', 'v': 'volume',
  'shuffle': 'shuffle', 'mix': 'shuffle',
  'kick': 'kick',
  'ban': 'ban',
  'mute': 'mute', 'timeout': 'mute',
  'unmute': 'unmute', 'untimeout': 'unmute',
  'clear': 'clear', 'purge': 'clear', 'delete': 'clear',
  'ping': 'ping', 'latency': 'ping',
  'serverinfo': 'serverinfo', 'si': 'serverinfo', 'server': 'serverinfo',
  'userinfo': 'userinfo', 'ui': 'userinfo', 'user': 'userinfo', 'whois': 'userinfo',
  'help': 'help', 'commands': 'help', 'cmds': 'help',
  'announce': 'announce', 'announcement': 'announce',
  'giveaway': 'giveaway', 'gw': 'giveaway',
  'ticket': 'ticket', 'tickets': 'ticket',
  'count': 'count', 'counting': 'count',
  'karaoke': 'karaoke', 'sing': 'karaoke', 'singalong': 'karaoke',
  'setprefix': 'setprefix', 'prefix': 'setprefix', 'changeprefix': 'setprefix',
};

async function handlePrefixCommand(message, client, prefix = DEFAULT_PREFIX) {
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift()?.toLowerCase() || '';
  
  if (!commandName) {
    return;
  }
  
  console.log(`[Prefix] Command received: ${prefix}${commandName} from ${message.author.username}`);
  
  const guildId = message.guild.id;
  const userId = message.author.id;
  
  const mappedCommand = commandAliasMap[commandName];
  if (mappedCommand) {
    const channelCheck = isCommandAllowedInChannel(mappedCommand, message.channel.id);
    if (!channelCheck.allowed) {
      return message.reply(`This command can only be used in <#${channelCheck.requiredChannel}>!`);
    }
  }
  
  if (commandName === 'balance' || commandName === 'bal') {
    const target = message.mentions.users.first() || message.author;
    const balance = getBalance(guildId, target.id);
    
    const container = new ContainerBuilder()
      .setAccentColor(0xFFD700)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Balance')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**${target.username}** has **${balance.toLocaleString()}** eggs`)
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'daily') {
    const dailyData = getDailyReward(guildId, userId);
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const twoDays = 48 * 60 * 60 * 1000;
    
    if (dailyData.lastClaim && now - dailyData.lastClaim < oneDay) {
      const timeLeft = oneDay - (now - dailyData.lastClaim);
      const hours = Math.floor(timeLeft / (60 * 60 * 1000));
      const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
      return message.reply(`You've already claimed your daily reward! Come back in **${hours}h ${minutes}m**`);
    }
    
    let streak = dailyData.streak || 0;
    if (dailyData.lastClaim && now - dailyData.lastClaim > twoDays) {
      streak = 0;
    }
    streak++;
    
    const baseReward = 100;
    const streakBonus = Math.min(streak * 10, 100);
    const totalReward = baseReward + streakBonus;
    
    addBalance(guildId, userId, totalReward);
    setDailyReward(guildId, userId, { lastClaim: now, streak });
    
    const container = new ContainerBuilder()
      .setAccentColor(0x00FF00)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Daily Reward Claimed!')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`You received **${totalReward}** eggs!`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Base Reward:** ${baseReward} eggs\n**Streak Bonus:** +${streakBonus} eggs\n**Current Streak:** ${streak} days`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('*Come back tomorrow to keep your streak!*')
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'gather') {
    const cooldownKey = `gather-${userId}`;
    const cooldownTime = 30000;
    
    if (cooldowns.has(cooldownKey)) {
      const expiration = cooldowns.get(cooldownKey);
      if (Date.now() < expiration) {
        const remaining = Math.ceil((expiration - Date.now()) / 1000);
        return message.reply(`Please wait **${remaining}s** before gathering again!`);
      }
    }
    
    cooldowns.set(cooldownKey, Date.now() + cooldownTime);
    
    const eggsCollected = Math.floor(Math.random() * 60) + 1;
    const newBalance = addBalance(guildId, userId, eggsCollected);
    
    const container = new ContainerBuilder()
      .setAccentColor(0xFFA500)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Farm Gathering')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`You've collected **${eggsCollected}** eggs from the farm!`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Eggs Collected:** ${eggsCollected}\n**Total Eggs:** ${newBalance.toLocaleString()}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('*Keep gathering to get more eggs!*')
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'rob') {
    const cooldownKey = `rob-${userId}`;
    const cooldownTime = 60000;
    
    if (cooldowns.has(cooldownKey)) {
      const expiration = cooldowns.get(cooldownKey);
      if (Date.now() < expiration) {
        const remaining = Math.ceil((expiration - Date.now()) / 1000);
        return message.reply(`Please wait **${remaining}s** before robbing again!`);
      }
    }
    
    const target = message.mentions.users.first();
    
    if (!target) {
      return message.reply('You need to mention a user to rob! Usage: `erob @user`');
    }
    
    if (target.id === userId) {
      return message.reply('You cannot rob yourself!');
    }
    
    if (target.bot) {
      return message.reply('You cannot rob bots!');
    }
    
    const targetBalance = getBalance(guildId, target.id);
    
    if (targetBalance < 10) {
      return message.reply(`**${target.username}** doesn't have enough eggs to rob!`);
    }
    
    cooldowns.set(cooldownKey, Date.now() + cooldownTime);
    
    const successChance = Math.random();
    
    if (successChance < 0.4) {
      const eggsRobbed = Math.floor(Math.random() * 71) + 10;
      const actualRobbed = Math.min(eggsRobbed, targetBalance);
      
      removeBalance(guildId, target.id, actualRobbed);
      const newBalance = addBalance(guildId, userId, actualRobbed);
      
      const container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Fox Heist Success!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`With the help of fox you've robbed **${actualRobbed}** eggs from **${target.username}**!`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Eggs Stolen:** ${actualRobbed}\n**Your Total Eggs:** ${newBalance.toLocaleString()}`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('*The fox disappears into the shadows...*')
        );
      
      await message.reply({ content: `<@${target.id}>`, components: [container], flags: MessageFlags.IsComponentsV2 });
    } else {
      const eggsLost = Math.floor(Math.random() * 21) + 10;
      const robberBalance = getBalance(guildId, userId);
      const actualLost = Math.min(eggsLost, robberBalance);
      
      const newBalance = removeBalance(guildId, userId, actualLost);
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Caught Red-Handed!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`You tried to rob **${target.username}** but got caught! You lost **${actualLost}** eggs as a fine!`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Eggs Lost:** -${actualLost}\n**Your Total Eggs:** ${newBalance.toLocaleString()}`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('*The fox abandoned you and ran away!*')
        );
      
      await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  }
  
  else if (commandName === 'give') {
    const target = message.mentions.users.first();
    const amount = parseInt(args[1]) || parseInt(args[0]);
    
    if (!target) {
      return message.reply('You need to mention a user! Usage: `egive @user amount`');
    }
    
    if (!amount || amount < 1) {
      return message.reply('You need to specify a valid amount! Usage: `egive @user amount`');
    }
    
    if (target.id === userId) {
      return message.reply('You cannot give eggs to yourself!');
    }
    
    if (target.bot) {
      return message.reply('You cannot give eggs to bots!');
    }
    
    const senderBalance = getBalance(guildId, userId);
    
    if (senderBalance < amount) {
      return message.reply(`You don't have enough eggs! Your balance: **${senderBalance}** eggs`);
    }
    
    removeBalance(guildId, userId, amount);
    addBalance(guildId, target.id, amount);
    
    await message.reply(`**${message.author.username}** gave **${amount.toLocaleString()}** eggs to **${target.username}**!`);
  }
  
  else if (commandName === 'leaderboard' || commandName === 'lb') {
    const leaderboard = getLeaderboard(guildId, 10);
    
    if (leaderboard.length === 0) {
      return message.reply('No one has collected any eggs yet!');
    }
    
    const medals = ['🥇', '🥈', '🥉'];
    
    const leaderboardText = await Promise.all(
      leaderboard.map(async (entry, index) => {
        try {
          const user = await client.users.fetch(entry.userId);
          const medal = medals[index] || `**${index + 1}.**`;
          return `${medal} ${user.username} - **${entry.balance.toLocaleString()}** eggs`;
        } catch {
          return `**${index + 1}.** Unknown User - **${entry.balance.toLocaleString()}** eggs`;
        }
      })
    );
    
    const container = new ContainerBuilder()
      .setAccentColor(0xFFD700)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Egg Leaderboard')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(leaderboardText.join('\n'))
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*${message.guild.name}*`)
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'help') {
    const currentPrefix = getPrefix(guildId);
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# Prefix Commands (${currentPrefix})`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`Use these commands with the \`${currentPrefix}\` prefix!`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Economy:** \`${currentPrefix}balance\` \`${currentPrefix}daily\` \`${currentPrefix}gather\` \`${currentPrefix}rob @user\` \`${currentPrefix}give @user amount\` \`${currentPrefix}leaderboard\``)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Stats & Levels:** \`${currentPrefix}level\` \`${currentPrefix}stats\` \`${currentPrefix}leaderboards <type>\``)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Games:** \`${currentPrefix}hangman\` \`${currentPrefix}rps\` \`${currentPrefix}trivia\` \`${currentPrefix}wyr\` \`${currentPrefix}tod\``)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Fun:** \`${currentPrefix}gay [@user]\` \`${currentPrefix}marriage @user1 @user2\` \`${currentPrefix}meme\` \`${currentPrefix}joke\` \`${currentPrefix}dadjoke\``)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Music:** \`${currentPrefix}play\` \`${currentPrefix}skip\` \`${currentPrefix}stop\` \`${currentPrefix}pause\` \`${currentPrefix}resume\` \`${currentPrefix}queue\` \`${currentPrefix}karaoke\``)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Utility:** \`${currentPrefix}ping\` \`${currentPrefix}serverinfo\` \`${currentPrefix}userinfo\` \`${currentPrefix}mcstatus <server>\``)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Admin:** \`${currentPrefix}setprefix <new prefix>\` - Change the bot prefix`)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Aliases:** \`${currentPrefix}bal\` = balance, \`${currentPrefix}lb\` = leaderboard, \`${currentPrefix}hm\` = hangman`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('*You can also use /slash commands!*')
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'setprefix') {
    const hasManageGuild = message.member.permissions.has('ManageGuild');
    const isBotOwnerUser = isBotOwner(message.author.id);
    
    if (!hasManageGuild && !isBotOwnerUser) {
      return message.reply('You need **Manage Server** permission to change the prefix!');
    }
    
    const newPrefix = args[0];
    
    if (!newPrefix) {
      const currentPrefix = getPrefix(guildId);
      return message.reply(`Current prefix is \`${currentPrefix}\`\nUsage: \`${currentPrefix}setprefix <new prefix>\``);
    }
    
    if (newPrefix.length > 5) {
      return message.reply('Prefix cannot be longer than 5 characters!');
    }
    
    if (newPrefix.includes(' ')) {
      return message.reply('Prefix cannot contain spaces!');
    }
    
    setPrefix(guildId, newPrefix);
    
    const container = new ContainerBuilder()
      .setAccentColor(0x00FF00)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Prefix Changed!')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`The bot prefix has been changed to \`${newPrefix}\``)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Example:** \`${newPrefix}help\` to see all commands`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*Changed by ${message.author.username}*`)
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'level' || commandName === 'lvl' || commandName === 'rank') {
    const target = message.mentions.users.first() || message.author;
    const stats = getUserStats(guildId, target.id);
    
    const nextLevelXP = calculateXPForLevel(stats.level + 1);
    const progress = Math.min(100, Math.floor((stats.xp / nextLevelXP) * 100));
    
    const progressBar = createProgressBar(progress);
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${target.username}'s Level`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Level:** ${stats.level}\n**Total XP:** ${stats.xp.toLocaleString()}\n**Messages:** ${stats.messages.toLocaleString()}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Progress to Next Level:**\n${progressBar}\n${stats.xp.toLocaleString()} / ${nextLevelXP.toLocaleString()} XP (${progress}%)`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('*Keep chatting to level up!*')
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'stats') {
    const target = message.mentions.users.first() || message.author;
    const stats = getUserStats(guildId, target.id);
    
    const member = await message.guild.members.fetch(target.id).catch(() => null);
    const joinedAt = member?.joinedAt || new Date(stats.joinedAt);
    const daysInServer = Math.floor((Date.now() - joinedAt.getTime()) / (1000 * 60 * 60 * 24));
    
    const voiceHours = (stats.voiceTime / 3600).toFixed(2);
    
    const nextLevelXP = calculateXPForLevel(stats.level + 1);
    const progress = Math.min(100, Math.floor((stats.xp / nextLevelXP) * 100));
    
    const container = new ContainerBuilder()
      .setAccentColor(0x00D4FF)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${target.username}'s Statistics`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Level & XP:** Level **${stats.level}** (${stats.xp.toLocaleString()} XP)\nProgress: ${progress}% to Level ${stats.level + 1}`)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Messages Sent:** ${stats.messages.toLocaleString()} messages\n**Voice Time:** ${voiceHours} hours (${Math.floor(stats.voiceTime / 60)} minutes total)\n**Invites:** ${stats.invites || 0} members invited`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Server Activity:**\nJoined: <t:${Math.floor(joinedAt.getTime() / 1000)}:R>\nDays in server: **${daysInServer}** days`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*Stats for ${message.guild.name}*`)
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'leaderboards' || commandName === 'lbs') {
    const type = args[0]?.toLowerCase() || 'level';
    const validTypes = ['level', 'levels', 'messages', 'msg', 'voice', 'vc', 'invites', 'invite', 'eggs', 'egg', 'active', 'activity'];
    
    if (!validTypes.includes(type)) {
      return message.reply('Invalid leaderboard type! Use: `level`, `messages`, `voice`, `invites`, `eggs`, or `active`');
    }
    
    let actualType = type;
    if (type === 'levels') actualType = 'level';
    if (type === 'msg') actualType = 'messages';
    if (type === 'vc') actualType = 'voice';
    if (type === 'invite') actualType = 'invites';
    if (type === 'egg') actualType = 'eggs';
    if (type === 'activity') actualType = 'active';
    
    let leaderboard;
    let title;
    let color;
    let formatValue;
    
    if (actualType === 'eggs') {
      leaderboard = getLeaderboard(guildId, 10).map(entry => ({
        odId: entry.userId,
        value: entry.balance
      }));
      title = 'Egg Leaderboard';
      color = 0xFFD700;
      formatValue = (val) => `${val.toLocaleString()} eggs`;
    } else {
      const stats = getStatsLeaderboard(guildId, actualType, 10);
      
      switch (actualType) {
        case 'level':
          leaderboard = stats.map(s => ({ odId: s.userId, value: s.level, xp: s.xp }));
          title = 'Level Leaderboard';
          color = 0x5865F2;
          formatValue = (val, entry) => `Level ${val} (${entry.xp?.toLocaleString() || 0} XP)`;
          break;
        case 'messages':
          leaderboard = stats.map(s => ({ odId: s.userId, value: s.messages || 0 }));
          title = 'Messages Leaderboard';
          color = 0x00FF00;
          formatValue = (val) => `${val.toLocaleString()} messages`;
          break;
        case 'voice':
          leaderboard = stats.map(s => ({ odId: s.userId, value: s.voiceTime || 0 }));
          title = 'Voice Time Leaderboard';
          color = 0xFF69B4;
          formatValue = (val) => {
            const hours = (val / 3600).toFixed(1);
            return `${hours} hours`;
          };
          break;
        case 'invites':
          leaderboard = stats.map(s => ({ odId: s.userId, value: s.invites || 0 }));
          title = 'Invites Leaderboard';
          color = 0x00D4FF;
          formatValue = (val) => `${val} invites`;
          break;
        case 'active':
          leaderboard = stats.map(s => ({ 
            odId: s.userId, 
            value: (s.voiceTime || 0) + ((s.messages || 0) * 60),
            voiceTime: s.voiceTime || 0,
            messages: s.messages || 0
          }));
          title = 'Active Time Leaderboard';
          color = 0x9B59B6;
          formatValue = (val, entry) => {
            const hours = (val / 3600).toFixed(1);
            return `${hours} hours active (${entry.messages?.toLocaleString() || 0} msgs, ${((entry.voiceTime || 0) / 3600).toFixed(1)}h VC)`;
          };
          break;
      }
    }
    
    if (!leaderboard || leaderboard.length === 0) {
      return message.reply(`No data yet for this leaderboard!`);
    }
    
    const medals = ['🥇', '🥈', '🥉'];
    
    const leaderboardText = await Promise.all(
      leaderboard.map(async (entry, index) => {
        try {
          const user = await client.users.fetch(entry.odId);
          const medal = medals[index] || `**${index + 1}.**`;
          const valueStr = formatValue(entry.value, entry);
          return `${medal} ${user.username} - ${valueStr}`;
        } catch {
          const valueStr = formatValue(entry.value, entry);
          return `**${index + 1}.** Unknown User - ${valueStr}`;
        }
      })
    );
    
    const container = new ContainerBuilder()
      .setAccentColor(color)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${title}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(leaderboardText.join('\n') || 'No entries yet!')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`*${message.guild.name}*`)
      );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'mcstatus' || commandName === 'mc') {
    const serverInput = args[0];
    
    if (!serverInput) {
      return message.reply('Please provide a server address! Usage: `emcstatus play.hypixel.net`');
    }
    
    let host = serverInput;
    let port = 25565;
    
    if (serverInput.includes(':')) {
      const parts = serverInput.split(':');
      host = parts[0];
      port = parseInt(parts[1]) || 25565;
    }
    
    const loadingMsg = await message.reply('Fetching server status...');
    
    try {
      const status = await fetchMCServerStatus(host, port);
      
      if (status.online) {
        let playerList = '';
        if (status.players.list && status.players.list.length > 0) {
          playerList = `\n**Online Players:** ${status.players.list.slice(0, 20).join(', ')}${status.players.list.length > 20 ? ` and ${status.players.list.length - 20} more...` : ''}`;
        }
        
        const container = new ContainerBuilder()
          .setAccentColor(0x00FF00)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ${host}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(status.motd || 'Minecraft Server')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Players:** ${status.players.online} / ${status.players.max}\n**Version:** ${status.version || 'Unknown'}\n**Address:** \`${host}:${port}\`${playerList}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('*Server is online!*')
          );
        
        await loadingMsg.edit({ content: null, components: [container], flags: MessageFlags.IsComponentsV2 });
      } else {
        const container = new ContainerBuilder()
          .setAccentColor(0xFF0000)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ${host}`)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('Server appears to be offline or unreachable.')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Address:** \`${host}:${port}\``)
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('*Could not connect to server*')
          );
        
        await loadingMsg.edit({ content: null, components: [container], flags: MessageFlags.IsComponentsV2 });
      }
    } catch (error) {
      console.error('MC Status error:', error);
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Error')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Could not fetch server status for \`${host}\`.\n\nMake sure the server address is correct.`)
        );
      
      await loadingMsg.edit({ content: null, components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  }
  
  else if (commandName === 'ping') {
    const sent = await message.reply('Pinging...');
    const roundtrip = sent.createdTimestamp - message.createdTimestamp;
    const wsLatency = client.ws.ping;
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# Pong!')
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Roundtrip Latency:** ${roundtrip}ms\n**WebSocket Latency:** ${wsLatency}ms`)
      );
    
    await sent.edit({ content: null, components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'serverinfo' || commandName === 'server') {
    const { guild } = message;
    
    const verificationLevels = {
      0: 'None',
      1: 'Low',
      2: 'Medium',
      3: 'High',
      4: 'Very High',
    };
    
    const createdAt = Math.floor(guild.createdTimestamp / 1000);
    
    const container = new ContainerBuilder()
      .setAccentColor(0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${guild.name}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      );
    
    if (guild.description) {
      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(guild.description)
      ).addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      );
    }
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Owner:** <@${guild.ownerId}>\n**Created:** <t:${createdAt}:R>\n**Server ID:** ${guild.id}`)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Members:** ${guild.memberCount}\n**Channels:** ${guild.channels.cache.size}\n**Emojis:** ${guild.emojis.cache.size}`)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Roles:** ${guild.roles.cache.size}\n**Verification:** ${verificationLevels[guild.verificationLevel]}\n**Boosts:** ${guild.premiumSubscriptionCount || 0}`)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`*Requested by ${message.author.username}*`)
    );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'userinfo' || commandName === 'user' || commandName === 'whois') {
    const user = message.mentions.users.first() || message.author;
    const member = message.guild.members.cache.get(user.id);
    
    const createdAt = Math.floor(user.createdTimestamp / 1000);
    
    const container = new ContainerBuilder()
      .setAccentColor(member?.displayColor || 0x5865F2)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# ${user.username}`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**User ID:** ${user.id}\n**Account Created:** <t:${createdAt}:R>\n**Bot:** ${user.bot ? 'Yes' : 'No'}`)
      );
    
    if (member) {
      const joinedAt = Math.floor(member.joinedTimestamp / 1000);
      const roles = member.roles.cache
        .filter(role => role.id !== message.guild.id)
        .sort((a, b) => b.position - a.position)
        .map(role => role.toString())
        .slice(0, 10);
      
      container.addSeparatorComponents(
        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Joined Server:** <t:${joinedAt}:R>\n**Nickname:** ${member.nickname || 'None'}\n**Color:** ${member.displayHexColor}`)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`**Roles [${member.roles.cache.size - 1}]:** ${roles.length ? roles.join(' ') : 'None'}`)
      );
      
      if (member.premiumSince) {
        const boostingSince = Math.floor(member.premiumSinceTimestamp / 1000);
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Boosting Since:** <t:${boostingSince}:R>`)
        );
      }
    }
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`*Requested by ${message.author.username}*`)
    );
    
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
  
  else if (commandName === 'gay' || commandName === 'howgay' || commandName === 'gaymeter') {
    const gayCommand = client.commands.get('gay');
    if (gayCommand) {
      const target = message.mentions.users.first() || message.author;
      
      const fakeInteraction = {
        user: message.author,
        options: {
          getUser: () => target,
        },
        reply: async (options) => {
          await message.reply(options);
        },
        guild: message.guild,
      };
      
      try {
        await gayCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Gay command error:', error);
        await message.reply('An error occurred while running this command.');
      }
    }
  }
  
  else if (commandName === 'marriage' || commandName === 'marry' || commandName === 'ship' || commandName === 'love') {
    const marriageCommand = client.commands.get('marriage');
    if (marriageCommand) {
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        options: {},
        deferReply: async () => {
          replyMessage = await message.reply('Finding your match...');
        },
        editReply: async (options) => {
          if (replyMessage) {
            await replyMessage.edit({ content: null, ...options });
          } else {
            await message.reply(options);
          }
        },
        reply: async (options) => {
          await message.reply(options);
        },
        guild: message.guild,
      };
      
      try {
        await marriageCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Marriage command error:', error);
        if (replyMessage) {
          await replyMessage.edit('An error occurred while running this command.');
        } else {
          await message.reply('An error occurred while running this command.');
        }
      }
    }
  }
  
  else if (commandName === 'meme' || commandName === 'memes' || commandName === 'reddit') {
    const memeCommand = client.commands.get('meme');
    if (memeCommand) {
      const category = args[0] || 'random';
      
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        options: {
          getString: () => category,
          getInteger: () => 1,
        },
        deferReply: async () => {
          try {
            replyMessage = await message.reply('Fetching meme...');
          } catch (error) {
            console.error('[Prefix meme] DeferReply error:', error);
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix meme] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        followUp: async (options) => {
          try {
            await message.channel.send(options);
          } catch (error) {
            console.error('[Prefix meme] FollowUp error:', error);
          }
        },
        reply: async (options) => {
          try {
            await message.reply(options);
          } catch (error) {
            console.error('[Prefix meme] Reply error:', error);
          }
        },
        guild: message.guild,
      };
      
      try {
        await memeCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Meme command error:', error);
        try {
          if (replyMessage) {
            await replyMessage.edit('An error occurred while running this command.');
          } else {
            await message.reply('An error occurred while running this command.');
          }
        } catch {}
      }
    }
  }
  
  else if (commandName === 'hangman' || commandName === 'hang' || commandName === 'hm') {
    const hangmanCommand = client.commands.get('hangman');
    if (hangmanCommand) {
      const category = args[0] || 'random';
      let replyMessage = null;
      
      const validCategories = ['animals', 'countries', 'food', 'movies', 'sports', 'technology', 'random'];
      
      const fakeInteraction = {
        user: message.author,
        channel: message.channel,
        options: {
          getString: () => validCategories.includes(category.toLowerCase()) ? category.toLowerCase() : 'random',
        },
        reply: async (options) => {
          try {
            if (options.ephemeral) {
              return message.reply(options.content);
            }
            replyMessage = await message.reply(options);
            return replyMessage;
          } catch (error) {
            console.error('[Prefix hangman] Reply error:', error);
            return null;
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix hangman] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        guild: message.guild,
      };
      
      try {
        await hangmanCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Hangman command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'rps' || commandName === 'rockpaperscissors' || commandName === 'roshambo') {
    const rpsCommand = client.commands.get('rps');
    if (rpsCommand) {
      const choice = args[0]?.toLowerCase();
      const validChoices = ['rock', 'paper', 'scissors'];
      
      const fakeInteraction = {
        user: message.author,
        options: {
          getString: () => validChoices.includes(choice) ? choice : null,
        },
        reply: async (options) => {
          try {
            await message.reply(options);
          } catch (error) {
            console.error('[Prefix rps] Reply error:', error);
          }
        },
        guild: message.guild,
      };
      
      try {
        await rpsCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('RPS command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'trivia' || commandName === 'quiz' || commandName === 'question') {
    const triviaCommand = client.commands.get('trivia');
    if (triviaCommand) {
      const category = args[0]?.toLowerCase();
      const difficulty = args[1]?.toLowerCase();
      let replyMessage = null;
      
      const validCategories = ['general', 'books', 'film', 'music', 'theatre', 'television', 'videogames', 'boardgames', 'science', 'computers', 'math', 'mythology', 'sports', 'geography', 'history', 'politics', 'art', 'celebrities', 'animals', 'vehicles', 'comics', 'anime', 'cartoons'];
      const validDifficulties = ['easy', 'medium', 'hard'];
      
      const fakeInteraction = {
        user: message.author,
        channel: message.channel,
        options: {
          getString: (name) => {
            if (name === 'category') return validCategories.includes(category) ? category : null;
            if (name === 'difficulty') return validDifficulties.includes(difficulty) ? difficulty : null;
            return null;
          },
        },
        deferReply: async () => {
          try {
            replyMessage = await message.reply('Loading trivia question...');
          } catch (error) {
            console.error('[Prefix trivia] DeferReply error:', error);
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix trivia] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        reply: async (options) => {
          try {
            await message.reply(options);
          } catch (error) {
            console.error('[Prefix trivia] Reply error:', error);
          }
        },
        guild: message.guild,
      };
      
      try {
        await triviaCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Trivia command error:', error);
        try {
          if (replyMessage) {
            await replyMessage.edit('An error occurred while running this command.');
          } else {
            await message.reply('An error occurred while running this command.');
          }
        } catch {}
      }
    }
  }
  
  else if (commandName === 'wouldyourather' || commandName === 'wyr' || commandName === 'rather' || commandName === 'wouldurather') {
    const wyrCommand = client.commands.get('wouldyourather');
    if (wyrCommand) {
      const mode = args[0]?.toLowerCase() === 'poll' ? 'poll' : 'random';
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        channel: message.channel,
        options: {
          getString: () => mode,
        },
        reply: async (options) => {
          try {
            replyMessage = await message.reply(options);
            return replyMessage;
          } catch (error) {
            console.error('[Prefix wyr] Reply error:', error);
            return null;
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix wyr] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        guild: message.guild,
      };
      
      try {
        await wyrCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Would you rather command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'truthordare' || commandName === 'tod' || commandName === 'tord') {
    const todCommand = client.commands.get('truthordare');
    if (todCommand) {
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        channel: message.channel,
        options: {
          getString: () => null,
        },
        reply: async (options) => {
          try {
            replyMessage = await message.reply(options);
            return replyMessage;
          } catch (error) {
            console.error('[Prefix tod] Reply error:', error);
            return null;
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix tod] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        guild: message.guild,
      };
      
      try {
        await todCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Truth or dare command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'joke' || commandName === 'jokes' || commandName === 'lol' || commandName === 'haha') {
    const jokeCommand = client.commands.get('joke');
    if (jokeCommand) {
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        options: {
          getString: () => null,
        },
        deferReply: async () => {
          try {
            replyMessage = await message.reply('Finding a joke...');
          } catch (error) {
            console.error('[Prefix joke] DeferReply error:', error);
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix joke] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        reply: async (options) => {
          try {
            await message.reply(options);
          } catch (error) {
            console.error('[Prefix joke] Reply error:', error);
          }
        },
        guild: message.guild,
      };
      
      try {
        await jokeCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Joke command error:', error);
        try {
          if (replyMessage) {
            await replyMessage.edit('An error occurred while running this command.');
          } else {
            await message.reply('An error occurred while running this command.');
          }
        } catch {}
      }
    }
  }
  
  else if (commandName === 'dadjoke' || commandName === 'dad' || commandName === 'dj' || commandName === 'fatherjoke') {
    const dadjokeCommand = client.commands.get('dadjoke');
    if (dadjokeCommand) {
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        options: {},
        deferReply: async () => {
          try {
            replyMessage = await message.reply('Finding a dad joke...');
          } catch (error) {
            console.error('[Prefix dadjoke] DeferReply error:', error);
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix dadjoke] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        reply: async (options) => {
          try {
            await message.reply(options);
          } catch (error) {
            console.error('[Prefix dadjoke] Reply error:', error);
          }
        },
        guild: message.guild,
      };
      
      try {
        await dadjokeCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Dad joke command error:', error);
        try {
          if (replyMessage) {
            await replyMessage.edit('An error occurred while running this command.');
          } else {
            await message.reply('An error occurred while running this command.');
          }
        } catch {}
      }
    }
  }
  
  else if (commandName === 'jokeoftheday' || commandName === 'jotd' || commandName === 'dailyjoke' || commandName === 'todaysjoke') {
    const jotdCommand = client.commands.get('jokeoftheday');
    if (jotdCommand) {
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        options: {},
        deferReply: async () => {
          try {
            replyMessage = await message.reply('Getting joke of the day...');
          } catch (error) {
            console.error('[Prefix jotd] DeferReply error:', error);
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix jotd] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        reply: async (options) => {
          try {
            await message.reply(options);
          } catch (error) {
            console.error('[Prefix jotd] Reply error:', error);
          }
        },
        guild: message.guild,
      };
      
      try {
        await jotdCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Joke of the day command error:', error);
        try {
          if (replyMessage) {
            await replyMessage.edit('An error occurred while running this command.');
          } else {
            await message.reply('An error occurred while running this command.');
          }
        } catch {}
      }
    }
  }
  
  else if (commandName === 'karaoke' || commandName === 'sing' || commandName === 'singalong') {
    const karaokeCommand = client.commands.get('karaoke');
    if (karaokeCommand) {
      const query = args.join(' ');
      
      if (!query) {
        return message.reply('Please provide a song! Usage: `ekaraoke <song name or YouTube URL>`').catch(() => {});
      }
      
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        channel: message.channel,
        guildId: message.guild.id,
        options: {
          getString: () => query,
        },
        deferReply: async () => {
          try {
            replyMessage = await message.reply('Starting karaoke session...');
          } catch (error) {
            console.error('[Prefix karaoke] DeferReply error:', error);
          }
        },
        editReply: async (options) => {
          try {
            if (replyMessage) {
              await replyMessage.edit({ content: null, ...options });
            } else {
              await message.channel.send(options);
            }
          } catch (error) {
            console.error('[Prefix karaoke] EditReply error:', error);
            try {
              await message.channel.send(options);
            } catch {}
          }
        },
        reply: async (options) => {
          try {
            if (options.ephemeral) {
              return message.reply(options.content);
            }
            replyMessage = await message.reply(options);
            return replyMessage;
          } catch (error) {
            console.error('[Prefix karaoke] Reply error:', error);
            return null;
          }
        },
        guild: message.guild,
      };
      
      try {
        await karaokeCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Karaoke command error:', error);
        try {
          if (replyMessage) {
            await replyMessage.edit('An error occurred while running this command.');
          } else {
            await message.reply('An error occurred while running this command.');
          }
        } catch {}
      }
    }
  }
  
  else if (commandName === 'coinflip' || commandName === 'cf' || commandName === 'flip') {
    const coinflipCommand = client.commands.get('coinflip');
    if (coinflipCommand) {
      const bet = parseInt(args[0]) || 10;
      const side = args[1]?.toLowerCase() || 'heads';
      
      const fakeInteraction = {
        user: message.author,
        options: {
          getInteger: () => bet,
          getString: () => ['heads', 'tails'].includes(side) ? side : 'heads',
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await coinflipCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Coinflip command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'dice' || commandName === 'roll') {
    const diceCommand = client.commands.get('dice');
    if (diceCommand) {
      const bet = parseInt(args[0]) || 10;
      const guess = parseInt(args[1]) || 4;
      
      const fakeInteraction = {
        user: message.author,
        options: {
          getInteger: (name) => name === 'bet' ? bet : Math.min(Math.max(guess, 1), 6),
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await diceCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Dice command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'slots' || commandName === 'slot' || commandName === 'gamble') {
    const slotsCommand = client.commands.get('slots');
    if (slotsCommand) {
      const bet = parseInt(args[0]) || 10;
      
      const fakeInteraction = {
        user: message.author,
        options: {
          getInteger: () => bet,
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await slotsCommand.execute(fakeInteraction);
      } catch (error) {
        console.error('Slots command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'play' || commandName === 'p') {
    const query = args.join(' ');
    if (!query) {
      return message.reply('Please provide a song name or URL! Usage: `eplay <song name>`');
    }
    
    const playCommand = client.commands.get('play');
    if (playCommand) {
      let replyMessage = null;
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        channel: message.channel,
        options: {
          getString: () => query,
        },
        deferReply: async () => {
          replyMessage = await message.reply('Searching...');
        },
        editReply: async (options) => {
          if (replyMessage) {
            await replyMessage.edit({ content: null, ...options }).catch(() => {});
          } else {
            await message.reply(options).catch(() => {});
          }
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await playCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Play command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'skip' || commandName === 's' || commandName === 'next') {
    const skipCommand = client.commands.get('skip');
    if (skipCommand) {
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {},
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await skipCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Skip command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'stop' || commandName === 'disconnect' || commandName === 'dc' || commandName === 'leave') {
    const stopCommand = client.commands.get('stop');
    if (stopCommand) {
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {},
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await stopCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Stop command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'pause') {
    const pauseCommand = client.commands.get('pause');
    if (pauseCommand) {
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {},
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await pauseCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Pause command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'resume' || commandName === 'unpause') {
    const resumeCommand = client.commands.get('resume');
    if (resumeCommand) {
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {},
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await resumeCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Resume command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'queue' || commandName === 'q') {
    const queueCommand = client.commands.get('queue');
    if (queueCommand) {
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {},
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await queueCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Queue command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'nowplaying' || commandName === 'np' || commandName === 'current') {
    const npCommand = client.commands.get('nowplaying');
    if (npCommand) {
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {},
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await npCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Nowplaying command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'volume' || commandName === 'vol' || commandName === 'v') {
    const volumeCommand = client.commands.get('volume');
    if (volumeCommand) {
      const vol = parseInt(args[0]) || 50;
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {
          getInteger: () => Math.min(Math.max(vol, 0), 100),
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await volumeCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Volume command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'shuffle' || commandName === 'mix') {
    const shuffleCommand = client.commands.get('shuffle');
    if (shuffleCommand) {
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {},
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await shuffleCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Shuffle command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'kick') {
    const kickCommand = client.commands.get('kick');
    if (kickCommand) {
      const targetUser = message.mentions.users.first();
      const reason = args.slice(1).join(' ') || 'No reason provided';
      
      if (!targetUser) {
        return message.reply('Please mention a user to kick! Usage: `ekick @user [reason]`');
      }
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {
          getUser: () => targetUser,
          getString: () => reason,
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await kickCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Kick command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'ban') {
    const banCommand = client.commands.get('ban');
    if (banCommand) {
      const targetUser = message.mentions.users.first();
      const reason = args.slice(1).join(' ') || 'No reason provided';
      
      if (!targetUser) {
        return message.reply('Please mention a user to ban! Usage: `eban @user [reason]`');
      }
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {
          getUser: () => targetUser,
          getString: () => reason,
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await banCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Ban command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'mute' || commandName === 'timeout') {
    const muteCommand = client.commands.get('mute');
    if (muteCommand) {
      const targetUser = message.mentions.users.first();
      const duration = parseInt(args[1]) || 10;
      const reason = args.slice(2).join(' ') || 'No reason provided';
      
      if (!targetUser) {
        return message.reply('Please mention a user to mute! Usage: `emute @user [duration in minutes] [reason]`');
      }
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {
          getUser: () => targetUser,
          getInteger: () => duration,
          getString: () => reason,
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await muteCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Mute command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'unmute' || commandName === 'untimeout') {
    const unmuteCommand = client.commands.get('unmute');
    if (unmuteCommand) {
      const targetUser = message.mentions.users.first();
      
      if (!targetUser) {
        return message.reply('Please mention a user to unmute! Usage: `eunmute @user`');
      }
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {
          getUser: () => targetUser,
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await unmuteCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Unmute command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'clear' || commandName === 'purge' || commandName === 'delete') {
    const clearCommand = client.commands.get('clear');
    if (clearCommand) {
      const amount = parseInt(args[0]) || 10;
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        channel: message.channel,
        options: {
          getInteger: () => Math.min(Math.max(amount, 1), 100),
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await clearCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Clear command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'announce') {
    const announceCommand = client.commands.get('announce');
    if (announceCommand) {
      const channelMention = message.mentions.channels.first();
      const announcementText = args.slice(1).join(' ');
      
      if (!channelMention || !announcementText) {
        return message.reply('Usage: `eannounce #channel Your announcement message`');
      }
      
      const fakeInteraction = {
        user: message.author,
        member: message.member,
        options: {
          getChannel: () => channelMention,
          getString: () => announcementText,
        },
        reply: async (options) => message.reply(options),
        guild: message.guild,
      };
      
      try {
        await announceCommand.execute(fakeInteraction, client);
      } catch (error) {
        console.error('Announce command error:', error);
        await message.reply('An error occurred while running this command.').catch(() => {});
      }
    }
  }
  
  else if (commandName === 'giveaway' || commandName === 'gw') {
    const giveawayCommand = client.commands.get('giveaway');
    if (giveawayCommand) {
      return message.reply('Please use the slash command `/giveaway` for full functionality!');
    }
  }
  
  else if (commandName === 'ticket' || commandName === 'tickets') {
    const ticketCommand = client.commands.get('ticket');
    if (ticketCommand) {
      return message.reply('Please use the slash command `/ticket` for full functionality!');
    }
  }
  
  else if (commandName === 'count' || commandName === 'counting') {
    const countCommand = client.commands.get('count');
    if (countCommand) {
      const subcommand = args[0]?.toLowerCase();
      
      if (subcommand === 'setup' && message.mentions.channels.first()) {
        const channelMention = message.mentions.channels.first();
        
        const fakeInteraction = {
          user: message.author,
          member: message.member,
          options: {
            getSubcommand: () => 'setup',
            getChannel: () => channelMention,
          },
          reply: async (options) => message.reply(options),
          guild: message.guild,
        };
        
        try {
          await countCommand.execute(fakeInteraction, client);
        } catch (error) {
          console.error('Count command error:', error);
          await message.reply('An error occurred while running this command.').catch(() => {});
        }
      } else {
        return message.reply('Usage: `ecount setup #channel` or use `/count` for more options!');
      }
    }
  }
}

async function handleXP(message, client) {
  const guildId = message.guild.id;
  const userId = message.author.id;
  
  const cooldownKey = `xp-${guildId}-${userId}`;
  const now = Date.now();
  
  if (xpCooldowns.has(cooldownKey)) {
    const expiration = xpCooldowns.get(cooldownKey);
    if (now < expiration) return;
  }
  
  xpCooldowns.set(cooldownKey, now + 60000);
  
  const xpGain = Math.floor(Math.random() * 11) + 15;
  
  const result = addXP(guildId, userId, xpGain);
  
  if (result.leveledUp) {
    try {
      const container = new ContainerBuilder()
        .setAccentColor(0x00FF00)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Level Up!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Congratulations ${message.author}! You've reached **Level ${result.newLevel}**!`)
        );
      
      await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    } catch (error) {
      console.error('[XP] Failed to send level up message:', error);
    }
  }
}

function createProgressBar(percentage) {
  const filled = Math.floor(percentage / 10);
  const empty = 10 - filled;
  return '█'.repeat(filled) + '░'.repeat(empty);
}

function fetchMCServerStatus(host, port) {
  return new Promise((resolve, reject) => {
    const url = `https://api.mcsrvstat.us/2/${host}:${port}`;
    
    https.get(url, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve(json);
        } catch (error) {
          reject(error);
        }
      });
    }).on('error', (error) => {
      reject(error);
    });
  });
}
