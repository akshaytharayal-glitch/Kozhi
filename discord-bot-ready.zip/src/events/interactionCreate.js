import { Collection } from 'discord.js';
import { isCommandAllowedInChannel } from '../config/channelRestrictions.js';
import { canUseOwnerCommand } from '../utils/permissions.js';
import { handleVCButton, handleVCModal } from '../utils/vcControls.js';
import { sendLog } from '../utils/logger.js';

export default {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (command?.autocomplete) {
        try {
          await command.autocomplete(interaction);
        } catch (error) {
          console.error('Autocomplete error:', error);
        }
      }
      return;
    }
    
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      
      if (!command) {
        return interaction.reply({ content: 'Command not found!', ephemeral: true });
      }
      
      const channelCheck = isCommandAllowedInChannel(interaction.commandName, interaction.channelId);
      if (!channelCheck.allowed) {
        return interaction.reply({ 
          content: `❌ This command can only be used in <#${channelCheck.requiredChannel}>!`, 
          ephemeral: true 
        });
      }
      
      const userRoleIds = interaction.member?.roles?.cache?.map(r => r.id) || [];
      const canUse = canUseOwnerCommand(
        interaction.guild.id,
        interaction.guild.ownerId,
        interaction.user.id,
        userRoleIds,
        interaction.commandName
      );
      
      if (!canUse) {
        return interaction.reply({ 
          content: '🔒 This command is restricted. Only the server owner or authorized roles can use it.', 
          ephemeral: true 
        });
      }
      
      const { cooldowns } = client;
      
      if (!cooldowns.has(command.data.name)) {
        cooldowns.set(command.data.name, new Collection());
      }
      
      const now = Date.now();
      const timestamps = cooldowns.get(command.data.name);
      const cooldownAmount = (command.cooldown || 3) * 1000;
      
      if (timestamps.has(interaction.user.id)) {
        const expirationTime = timestamps.get(interaction.user.id) + cooldownAmount;
        
        if (now < expirationTime) {
          const timeLeft = (expirationTime - now) / 1000;
          return interaction.reply({
            content: `Please wait ${timeLeft.toFixed(1)} seconds before using \`/${command.data.name}\` again.`,
            ephemeral: true,
          });
        }
      }
      
      timestamps.set(interaction.user.id, now);
      setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);
      
      try {
        await command.execute(interaction, client);
        
        sendLog(
          interaction.guild,
          'commandUsage',
          'Command Used',
          `**${interaction.user.tag}** used a command.`,
          [
            { name: 'Command', value: `\`/${interaction.commandName}\`` },
            { name: 'Channel', value: `<#${interaction.channelId}>` }
          ]
        ).catch(() => {});
      } catch (error) {
        console.error(`Error executing ${interaction.commandName}:`, error);
        const errorMessage = { content: 'There was an error executing this command!', ephemeral: true };
        
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(errorMessage);
        } else {
          await interaction.reply(errorMessage);
        }
      }
    } else if (interaction.isButton()) {
      const handleButtonSafely = async (handler, handlerName) => {
        try {
          if (handler?.handleButton) {
            await handler.handleButton(interaction, client);
          }
        } catch (error) {
          console.error(`[Button:${handlerName}] Error:`, error);
          try {
            if (!interaction.replied && !interaction.deferred) {
              await interaction.reply({ content: '❌ This interaction expired or encountered an error. Please try again!', ephemeral: true });
            } else if (interaction.deferred) {
              await interaction.editReply({ content: '❌ This interaction expired or encountered an error. Please try again!' }).catch(() => {});
            }
          } catch {}
        }
      };

      try {
        if (interaction.customId.startsWith('ticket_')) {
          await handleButtonSafely(client.commands.get('ticket'), 'ticket');
        } else if (interaction.customId.startsWith('tod_')) {
          await handleButtonSafely(client.commands.get('truthordare'), 'truthordare');
        } else if (interaction.customId.startsWith('giveaway_')) {
          await handleButtonSafely(client.commands.get('giveaway'), 'giveaway');
        } else if (interaction.customId.startsWith('meme_')) {
          const channelCheck = isCommandAllowedInChannel('meme', interaction.channelId);
          if (!channelCheck.allowed) {
            return interaction.reply({ 
              content: `❌ Meme commands can only be used in <#${channelCheck.requiredChannel}>!`, 
              ephemeral: true 
            }).catch(() => {});
          }
          await handleButtonSafely(client.commands.get('meme'), 'meme');
        } else if (interaction.customId.startsWith('joke_')) {
          await handleButtonSafely(client.commands.get('joke'), 'joke');
        } else if (interaction.customId.startsWith('dadjoke_')) {
          await handleButtonSafely(client.commands.get('dadjoke'), 'dadjoke');
        } else if (interaction.customId.startsWith('jotd_')) {
          await handleButtonSafely(client.commands.get('jokeoftheday'), 'jokeoftheday');
        } else if (interaction.customId.startsWith('rps_')) {
          await handleButtonSafely(client.commands.get('rps'), 'rps');
        } else if (interaction.customId.startsWith('trivia_')) {
          await handleButtonSafely(client.commands.get('trivia'), 'trivia');
        } else if (interaction.customId.startsWith('wyr_')) {
          await handleButtonSafely(client.commands.get('wouldyourather'), 'wouldyourather');
        } else if (interaction.customId.startsWith('hm_')) {
          await handleButtonSafely(client.commands.get('hangman'), 'hangman');
        } else if (interaction.customId.startsWith('help_')) {
          await handleButtonSafely(client.commands.get('help'), 'help');
        } else if (interaction.customId.startsWith('karaoke_')) {
          await handleButtonSafely(client.commands.get('karaoke'), 'karaoke');
        } else if (interaction.customId.startsWith('coinflip_')) {
          await handleButtonSafely(client.commands.get('coinflip'), 'coinflip');
        } else if (interaction.customId.startsWith('vc_')) {
          try {
            await handleVCButton(interaction, client);
          } catch (error) {
            console.error('[Button:vc] Error:', error);
            if (!interaction.replied && !interaction.deferred) {
              await interaction.reply({ content: '❌ Failed to process voice channel control!', ephemeral: true });
            }
          }
        }
      } catch (error) {
        console.error('[Button] Outer error:', error);
        try {
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: '❌ There was an error processing this button!', ephemeral: true });
          }
        } catch {}
      }
    } else if (interaction.isModalSubmit()) {
      if (interaction.customId.startsWith('vc_')) {
        try {
          await handleVCModal(interaction, client);
        } catch (error) {
          console.error('[Modal:vc] Error:', error);
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: '❌ Failed to process your input!', ephemeral: true });
          }
        }
      }
    }
  },
};
