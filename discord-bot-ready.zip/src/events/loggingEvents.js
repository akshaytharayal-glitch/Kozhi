import { Events } from 'discord.js';
import { sendLog, isLogEnabled } from '../utils/logger.js';

export default {
  name: 'ready',
  once: true,
  async execute(client) {
    client.on(Events.GuildMemberRemove, async (member) => {
      if (member.user.bot) return;
      
      await sendLog(
        member.guild,
        'memberLeave',
        'Member Left',
        `**${member.user.tag}** has left the server.`,
        [
          { name: 'User ID', value: member.id },
          { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` },
          { name: 'Joined Server', value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Unknown' }
        ]
      );
    });

    client.on(Events.GuildBanAdd, async (ban) => {
      await sendLog(
        ban.guild,
        'memberBan',
        'Member Banned',
        `**${ban.user.tag}** has been banned from the server.`,
        [
          { name: 'User ID', value: ban.user.id },
          { name: 'Reason', value: ban.reason || 'No reason provided' }
        ]
      );
    });

    client.on(Events.GuildBanRemove, async (ban) => {
      await sendLog(
        ban.guild,
        'memberUnban',
        'Member Unbanned',
        `**${ban.user.tag}** has been unbanned from the server.`,
        [
          { name: 'User ID', value: ban.user.id }
        ]
      );
    });

    client.on(Events.MessageDelete, async (message) => {
      if (!message.guild || message.author?.bot) return;
      if (!message.content && !message.attachments.size) return;

      const content = message.content || '*No text content*';
      const truncated = content.length > 500 ? content.substring(0, 500) + '...' : content;

      await sendLog(
        message.guild,
        'messageDelete',
        'Message Deleted',
        `A message was deleted in <#${message.channel.id}>`,
        [
          { name: 'Author', value: message.author ? `<@${message.author.id}>` : 'Unknown' },
          { name: 'Content', value: `\`\`\`${truncated}\`\`\`` },
          { name: 'Attachments', value: message.attachments.size > 0 ? message.attachments.map(a => a.name).join(', ') : 'None' }
        ]
      );
    });

    client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
      if (!newMessage.guild || newMessage.author?.bot) return;
      if (oldMessage.content === newMessage.content) return;

      const oldContent = oldMessage.content || '*Empty*';
      const newContent = newMessage.content || '*Empty*';
      const truncateOld = oldContent.length > 250 ? oldContent.substring(0, 250) + '...' : oldContent;
      const truncateNew = newContent.length > 250 ? newContent.substring(0, 250) + '...' : newContent;

      await sendLog(
        newMessage.guild,
        'messageEdit',
        'Message Edited',
        `A message was edited in <#${newMessage.channel.id}>`,
        [
          { name: 'Author', value: `<@${newMessage.author.id}>` },
          { name: 'Before', value: `\`\`\`${truncateOld}\`\`\`` },
          { name: 'After', value: `\`\`\`${truncateNew}\`\`\`` },
          { name: 'Jump to Message', value: `[Click Here](${newMessage.url})` }
        ]
      );
    });

    client.on(Events.ChannelCreate, async (channel) => {
      if (!channel.guild) return;

      await sendLog(
        channel.guild,
        'channelCreate',
        'Channel Created',
        `A new channel has been created.`,
        [
          { name: 'Channel', value: `<#${channel.id}>` },
          { name: 'Type', value: channel.type.toString() },
          { name: 'Category', value: channel.parent?.name || 'None' }
        ]
      );
    });

    client.on(Events.ChannelDelete, async (channel) => {
      if (!channel.guild) return;

      await sendLog(
        channel.guild,
        'channelDelete',
        'Channel Deleted',
        `A channel has been deleted.`,
        [
          { name: 'Channel Name', value: channel.name },
          { name: 'Type', value: channel.type.toString() },
          { name: 'Category', value: channel.parent?.name || 'None' }
        ]
      );
    });

    client.on(Events.GuildRoleCreate, async (role) => {
      await sendLog(
        role.guild,
        'roleCreate',
        'Role Created',
        `A new role has been created.`,
        [
          { name: 'Role', value: `<@&${role.id}>` },
          { name: 'Color', value: role.hexColor },
          { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No' }
        ]
      );
    });

    client.on(Events.GuildRoleDelete, async (role) => {
      await sendLog(
        role.guild,
        'roleDelete',
        'Role Deleted',
        `A role has been deleted.`,
        [
          { name: 'Role Name', value: role.name },
          { name: 'Color', value: role.hexColor }
        ]
      );
    });

    client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
      if (oldMember.nickname !== newMember.nickname) {
        await sendLog(
          newMember.guild,
          'nicknameChange',
          'Nickname Changed',
          `**${newMember.user.tag}** changed their nickname.`,
          [
            { name: 'Old Nickname', value: oldMember.nickname || '*None*' },
            { name: 'New Nickname', value: newMember.nickname || '*None*' }
          ]
        );
      }

      const oldRoles = oldMember.roles.cache;
      const newRoles = newMember.roles.cache;
      
      const addedRoles = newRoles.filter(r => !oldRoles.has(r.id));
      const removedRoles = oldRoles.filter(r => !newRoles.has(r.id));

      if (addedRoles.size > 0 || removedRoles.size > 0) {
        const changes = [];
        if (addedRoles.size > 0) {
          changes.push(`**Added:** ${addedRoles.map(r => `<@&${r.id}>`).join(', ')}`);
        }
        if (removedRoles.size > 0) {
          changes.push(`**Removed:** ${removedRoles.map(r => `<@&${r.id}>`).join(', ')}`);
        }

        await sendLog(
          newMember.guild,
          'roleUpdate',
          'Member Roles Updated',
          `**${newMember.user.tag}**'s roles were updated.`,
          [
            { name: 'Changes', value: changes.join('\n') }
          ]
        );
      }
    });

    client.on(Events.InviteCreate, async (invite) => {
      if (!invite.guild) return;

      await sendLog(
        invite.guild,
        'inviteCreate',
        'Invite Created',
        `A new invite has been created.`,
        [
          { name: 'Code', value: invite.code },
          { name: 'Channel', value: `<#${invite.channel.id}>` },
          { name: 'Created By', value: invite.inviter ? `<@${invite.inviter.id}>` : 'Unknown' },
          { name: 'Max Uses', value: invite.maxUses === 0 ? 'Unlimited' : invite.maxUses.toString() },
          { name: 'Expires', value: invite.expiresAt ? `<t:${Math.floor(invite.expiresAt.getTime() / 1000)}:R>` : 'Never' }
        ]
      );
    });

    console.log('[Logging] Event listeners registered');
  }
};
