import { addVoiceTime } from '../utils/database.js';
import { sendLog } from '../utils/logger.js';
import { 
  ChannelType, 
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ActionRowBuilder
} from 'discord.js';

const voiceSessions = new Map();
const temporaryChannels = new Map();

const CONTROL_PANEL_CHANNELS = [
  '1446204533972668498',
  '1446204713711177848',
  '1446204899858845708',
  '1446204997288067114',
  '1446205098576445461'
];

export default {
  name: 'voiceStateUpdate',
  async execute(oldState, newState, client) {
    const userId = newState.member?.id || oldState.member?.id;
    const guildId = newState.guild?.id || oldState.guild?.id;
    
    if (!userId || !guildId) return;
    if (newState.member?.user?.bot) return;
    
    const sessionKey = `${guildId}-${userId}`;
    const member = newState.member || oldState.member;
    
    if (!oldState.channelId && newState.channelId) {
      voiceSessions.set(sessionKey, Date.now());
      
      await sendLog(
        newState.guild,
        'voiceJoin',
        'Voice Channel Join',
        `**${member.user.tag}** joined a voice channel.`,
        [
          { name: 'Channel', value: `<#${newState.channelId}>` }
        ]
      );
    }
    else if (oldState.channelId && !newState.channelId) {
      const startTime = voiceSessions.get(sessionKey);
      if (startTime) {
        const duration = Math.floor((Date.now() - startTime) / 1000);
        if (duration > 0) {
          addVoiceTime(guildId, userId, duration);
        }
        voiceSessions.delete(sessionKey);
      }
      
      await sendLog(
        oldState.guild,
        'voiceLeave',
        'Voice Channel Leave',
        `**${member.user.tag}** left a voice channel.`,
        [
          { name: 'Channel', value: `<#${oldState.channelId}>` }
        ]
      );
    }
    
    if (newState.channelId && CONTROL_PANEL_CHANNELS.includes(newState.channelId)) {
      await createPersonalChannel(newState, client);
    }
    
    if (oldState.channelId && temporaryChannels.has(oldState.channelId)) {
      await checkAndDeleteEmptyChannel(oldState, client);
    }
  },
};

async function createPersonalChannel(state, client) {
  try {
    const member = state.member;
    const guild = state.guild;
    const parentChannel = state.channel;
    
    if (!member || !guild || !parentChannel) return;
    
    const channelName = `${parentChannel.name}-${member.displayName}`;
    
    const permissionOverwrites = [];
    
    if (parentChannel.parent) {
      const category = parentChannel.parent;
      category.permissionOverwrites.cache.forEach((overwrite) => {
        permissionOverwrites.push({
          id: overwrite.id,
          allow: overwrite.allow.toArray(),
          deny: overwrite.deny.toArray(),
        });
      });
    }
    
    permissionOverwrites.push({
      id: member.id,
      allow: [
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.MoveMembers,
        PermissionFlagsBits.MuteMembers,
        PermissionFlagsBits.DeafenMembers,
        PermissionFlagsBits.Connect,
        PermissionFlagsBits.Speak,
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
      ],
    });
    
    const voiceChannel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildVoice,
      parent: parentChannel.parent,
      permissionOverwrites: permissionOverwrites,
      userLimit: parentChannel.userLimit || 0,
      bitrate: parentChannel.bitrate || 64000,
    });
    
    temporaryChannels.set(voiceChannel.id, {
      ownerId: member.id,
      createdAt: Date.now(),
      guildId: guild.id,
      isLocked: false,
      isHidden: false,
      coOwners: [],
      bannedUsers: [],
    });
    
    await member.voice.setChannel(voiceChannel);
    
    await sendControlPanel(voiceChannel, member);
    
    console.log(`[VoiceChannels] Created temporary channel "${channelName}" for ${member.user.tag}`);
    
  } catch (error) {
    console.error('[VoiceChannels] Error creating personal channel:', error.message);
  }
}

async function sendControlPanel(voiceChannel, owner) {
  const container = new ContainerBuilder()
    .setAccentColor(0x5865F2);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`# 🎛️ ${owner.displayName}'s VC\n## Control Panel`)
  );
  
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('*Manage your voice channel below.*')
  );
  
  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );
  
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`**Channel:** 🔊${voiceChannel.name}\n**Owner:** ${owner}`)
  );
  
  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`vc_lock_${voiceChannel.id}`)
      .setLabel('Lock')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`vc_unlock_${voiceChannel.id}`)
      .setLabel('Unlock')
      .setEmoji('🔓')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`vc_kickall_${voiceChannel.id}`)
      .setLabel('Kick All')
      .setEmoji('🚪')
      .setStyle(ButtonStyle.Danger)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`vc_rename_${voiceChannel.id}`)
      .setLabel('Edit Name')
      .setEmoji('✏️')
      .setStyle(ButtonStyle.Primary)
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`vc_coowner_${voiceChannel.id}`)
      .setLabel('Co-Owner')
      .setEmoji('👑')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`vc_block_${voiceChannel.id}`)
      .setLabel('Ban')
      .setEmoji('⛔')
      .setStyle(ButtonStyle.Danger)
  );

  const row4 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`vc_hide_${voiceChannel.id}`)
      .setLabel('Hide')
      .setEmoji('👁️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`vc_show_${voiceChannel.id}`)
      .setLabel('Show')
      .setEmoji('👀')
      .setStyle(ButtonStyle.Primary)
  );

  const row5 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`vc_permit_${voiceChannel.id}`)
      .setLabel('Access')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`vc_limit_${voiceChannel.id}`)
      .setLabel('Limit')
      .setEmoji('🔢')
      .setStyle(ButtonStyle.Secondary)
  );

  await voiceChannel.send({ 
    components: [container, row1, row2, row3, row4, row5],
    flags: MessageFlags.IsComponentsV2 
  });
}

async function checkAndDeleteEmptyChannel(state, client) {
  try {
    const channelId = state.channelId;
    const guild = state.guild;
    
    if (!guild) return;
    
    const channel = guild.channels.cache.get(channelId);
    
    if (!channel) {
      temporaryChannels.delete(channelId);
      return;
    }
    
    if (channel.members.size === 0) {
      await channel.delete('Temporary voice channel - all users left');
      temporaryChannels.delete(channelId);
      console.log(`[VoiceChannels] Deleted empty temporary channel "${channel.name}"`);
    }
    
  } catch (error) {
    console.error('[VoiceChannels] Error deleting empty channel:', error.message);
  }
}

export function getTemporaryChannels() {
  return temporaryChannels;
}

export function isTemporaryChannel(channelId) {
  return temporaryChannels.has(channelId);
}

export function getChannelOwner(channelId) {
  const data = temporaryChannels.get(channelId);
  return data ? data.ownerId : null;
}

export function getVCData(channelId) {
  return temporaryChannels.get(channelId);
}

export function updateVCData(channelId, data) {
  const existing = temporaryChannels.get(channelId);
  if (existing) {
    temporaryChannels.set(channelId, { ...existing, ...data });
  }
}
