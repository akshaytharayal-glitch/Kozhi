import { ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import { readFileSync, existsSync } from 'fs';

const JOTD_FILE = './data/jokeoftheday.json';

const dailyJokes = [
  { setup: "Why don't scientists trust atoms?", punchline: "Because they make up everything!", category: "Science" },
  { setup: "What do you call a fake noodle?", punchline: "An impasta!", category: "Food" },
  { setup: "Why did the scarecrow win an award?", punchline: "Because he was outstanding in his field!", category: "Farm" },
  { setup: "Why don't eggs tell jokes?", punchline: "They'd crack each other up!", category: "Food" },
  { setup: "What do you call a bear with no teeth?", punchline: "A gummy bear!", category: "Animals" },
  { setup: "Why did the bicycle fall over?", punchline: "Because it was two-tired!", category: "Transport" },
  { setup: "What did the ocean say to the beach?", punchline: "Nothing, it just waved!", category: "Nature" },
  { setup: "Why can't you give Elsa a balloon?", punchline: "Because she will let it go!", category: "Movies" },
  { setup: "What do you call a sleeping dinosaur?", punchline: "A dino-snore!", category: "Animals" },
  { setup: "Why did the cookie go to the hospital?", punchline: "Because it was feeling crummy!", category: "Food" },
  { setup: "What's the best thing about Switzerland?", punchline: "I don't know, but the flag is a big plus!", category: "Geography" },
  { setup: "I'm reading a book about anti-gravity.", punchline: "It's impossible to put down!", category: "Science" },
  { setup: "How do you organize a space party?", punchline: "You planet!", category: "Space" },
  { setup: "What do you call cheese that isn't yours?", punchline: "Nacho cheese!", category: "Food" },
  { setup: "Why don't skeletons fight each other?", punchline: "They don't have the guts!", category: "Spooky" },
  { setup: "What do you call a fish without eyes?", punchline: "A fsh!", category: "Animals" },
  { setup: "Why did the golfer bring two pairs of pants?", punchline: "In case he got a hole in one!", category: "Sports" },
  { setup: "What do you call a man with no arms and no legs in a pool?", punchline: "Bob!", category: "Classic" },
  { setup: "Why do fathers take an extra pair of socks when they go golfing?", punchline: "In case they get a hole in one!", category: "Sports" },
  { setup: "I used to hate facial hair...", punchline: "But then it grew on me.", category: "Puns" },
  { setup: "What did the buffalo say to his son when he left?", punchline: "Bison!", category: "Animals" },
  { setup: "Why couldn't the bicycle stand up by itself?", punchline: "It was two tired.", category: "Transport" },
  { setup: "I'm afraid for the calendar.", punchline: "Its days are numbered.", category: "Time" },
  { setup: "Why do dads take an extra pair of socks when they play golf?", punchline: "In case they get a hole in one!", category: "Sports" },
  { setup: "What's brown and sticky?", punchline: "A stick!", category: "Classic" },
  { setup: "Did you hear about the claustrophobic astronaut?", punchline: "He just needed a little space.", category: "Space" },
  { setup: "I told my wife she should embrace her mistakes.", punchline: "She hugged me.", category: "Marriage" },
  { setup: "What's the best time to go to the dentist?", punchline: "Tooth-hurty!", category: "Health" },
  { setup: "I'm thinking of taking up meditation.", punchline: "I figure it's better than sitting around doing nothing.", category: "Mindfulness" },
  { setup: "Why do programmers prefer dark mode?", punchline: "Because light attracts bugs!", category: "Tech" },
  { setup: "Why do Java developers wear glasses?", punchline: "Because they don't C#!", category: "Tech" },
];

function getJOTDData() {
  if (!existsSync(JOTD_FILE)) {
    return {};
  }
  try {
    return JSON.parse(readFileSync(JOTD_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function getTodayString() {
  return new Date().toISOString().split('T')[0];
}

function getDailyJoke() {
  const today = getTodayString();
  const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24));
  const jokeIndex = dayOfYear % dailyJokes.length;
  return { joke: dailyJokes[jokeIndex], date: today };
}

async function checkAndPostJOTD(client) {
  const data = getJOTDData();
  const now = new Date();
  const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const today = getTodayString();
  
  for (const [guildId, settings] of Object.entries(data)) {
    if (!settings.enabled) continue;
    if (settings.lastPosted === today) continue;
    if (settings.time !== currentTime) continue;
    
    try {
      const channel = await client.channels.fetch(settings.channelId);
      if (!channel) continue;
      
      const { joke } = getDailyJoke();
      
      const container = new ContainerBuilder()
        .setAccentColor(0xFFD700)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('# Joke of the Day!')
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Question:** ${joke.setup}`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Answer:** ||${joke.punchline}||`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`**Category:** ${joke.category}`)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`*Click the spoiler to reveal! | ${today}*`)
        );
      
      await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
      
      data[guildId].lastPosted = today;
      const { writeFileSync } = await import('fs');
      writeFileSync(JOTD_FILE, JSON.stringify(data, null, 2));
      
      console.log(`[JOTD] Posted joke of the day in guild ${guildId}`);
    } catch (error) {
      console.error(`[JOTD] Failed to post in guild ${guildId}:`, error.message);
    }
  }
}

export default {
  name: 'clientReady',
  once: true,
  execute(client) {
    console.log(`Bot is online! Logged in as ${client.user.tag}`);
    console.log(`Serving ${client.guilds.cache.size} servers`);
    
    client.user.setPresence({
      activities: [{ name: '/help | All-in-One Bot', type: 0 }],
      status: 'online',
    });
    
    setInterval(() => {
      checkAndPostJOTD(client);
    }, 60000);
    
    console.log('[JOTD] Joke of the Day scheduler initialized');
    
    checkAndPostJOTD(client);
  },
};
