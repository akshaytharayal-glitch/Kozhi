import { ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, ThumbnailBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder, AttachmentBuilder, MessageFlags, SeparatorSpacingSize } from 'discord.js';
import path from 'path';
import fs from 'fs';
import { sendLog } from '../utils/logger.js';

const BANNER_PATH = path.join(process.cwd(), 'attached_assets/generated_images/mandhi_spot_neon_banner.png');

export default {
  name: 'guildMemberAdd',
  async execute(member, client) {
    try {
      await sendLog(
        member.guild,
        'memberJoin',
        'Member Joined',
        `**${member.user.tag}** has joined the server!`,
        [
          { name: 'User ID', value: member.id },
          { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` },
          { name: 'Member Count', value: member.guild.memberCount.toString() }
        ]
      );

      const channels = member.guild.channels.cache.filter(
        ch => ch.type === 0 && ch.permissionsFor(member.guild.members.me).has('SendMessages')
      );
      
      const welcomeChannel = channels.find(ch => 
        ch.name.toLowerCase() === 'welcome' || 
        ch.name.toLowerCase().includes('welcome')
      );
      
      if (welcomeChannel) {
        await sendWelcomeMessage(welcomeChannel, member);
      } else {
        const fallbackChannel = member.guild.systemChannel || channels.first();
        if (fallbackChannel) {
          await sendWelcomeMessage(fallbackChannel, member);
        }
      }
    } catch (error) {
      console.error('[Welcome] Error:', error);
    }
  },
};

export { BANNER_PATH };

export function findImportantChannels(guild) {
  const textChannels = guild.channels.cache.filter(ch => ch.type === 0);
  
  const announcementChannel = textChannels.find(ch => 
    ch.name.toLowerCase() === 'announcements' ||
    ch.name.toLowerCase() === 'announcement' ||
    ch.name.toLowerCase().includes('announce')
  );
  
  const rulesChannel = textChannels.find(ch => 
    ch.name.toLowerCase() === 'rules' ||
    ch.name.toLowerCase().includes('rule')
  ) || guild.rulesChannel;
  
  const generalChannel = textChannels.find(ch => 
    ch.name.toLowerCase() === 'general' ||
    ch.name.toLowerCase() === 'general-chat' ||
    ch.name.toLowerCase() === 'chat' ||
    ch.name.toLowerCase().includes('general')
  );

  return {
    announcement: announcementChannel,
    rules: rulesChannel,
    general: generalChannel
  };
}

async function sendWelcomeMessage(channel, member) {
  const memberCount = member.guild.memberCount;
  
  let attachment = null;
  let hasCustomBanner = false;
  
  if (fs.existsSync(BANNER_PATH)) {
    try {
      attachment = new AttachmentBuilder(BANNER_PATH, { name: 'banner.png' });
      hasCustomBanner = true;
    } catch (e) {
      console.error('[Welcome] Failed to load banner:', e.message);
    }
  }
  
  const importantChannels = findImportantChannels(member.guild);
  
  let channelLinks = '';
  if (importantChannels.announcement || importantChannels.rules || importantChannels.general) {
    channelLinks = '\n\n**Important Channels:**\n';
    
    if (importantChannels.announcement) {
      channelLinks += `Announcements: <#${importantChannels.announcement.id}>\n`;
    }
    if (importantChannels.rules) {
      channelLinks += `Rules: <#${importantChannels.rules.id}>\n`;
    }
    if (importantChannels.general) {
      channelLinks += `General Chat: <#${importantChannels.general.id}>\n`;
    }
  }
  
  const welcomeText = `Welcome to Mandhi Spot! It's a great place for finding new friends, playing new games, and chill!`;
  
  const container = new ContainerBuilder()
    .setAccentColor(0x7C3AED)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('# Welcome to Mandhi Spot!')
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Hey <@${member.id}>!\n\n${welcomeText}\n\nYou are member **#${memberCount}**${channelLinks}`)
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder({ media: { url: member.user.displayAvatarURL({ size: 256 }) } })
        )
    );
  
  if (hasCustomBanner) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL('attachment://banner.png')
      )
    );
  }
  
  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );
  
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`-# Welcome to ${member.guild.name}!`)
  );
  
  const messagePayload = {
    content: `<@${member.id}>`,
    components: [container],
    flags: MessageFlags.IsComponentsV2
  };
  
  if (hasCustomBanner && attachment) {
    messagePayload.files = [attachment];
  }
  
  await channel.send(messagePayload);
}

function getOrdinalSuffix(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}
