import { createContainer } from './structures/Container.js';

let container = null;

async function main() {
  try {
    console.log('========================================');
    console.log('     Discord Bot - Container v2');
    console.log('========================================');
    
    container = await createContainer();
    
    console.log('[Bot] Successfully started and ready!');
    
  } catch (error) {
    console.error('[Bot] Failed to start:', error);
    process.exit(1);
  }
}

process.on('SIGINT', async () => {
  console.log('\n[Bot] Received SIGINT, shutting down gracefully...');
  if (container) {
    await container.shutdown();
  }
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('\n[Bot] Received SIGTERM, shutting down gracefully...');
  if (container) {
    await container.shutdown();
  }
  process.exit(0);
});

process.on('unhandledRejection', (error) => {
  console.error('[Bot] Unhandled promise rejection:', error);
});

process.on('uncaughtException', (error) => {
  console.error('[Bot] Uncaught exception:', error);
});

main();
