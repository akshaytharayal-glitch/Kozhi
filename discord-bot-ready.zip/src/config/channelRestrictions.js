const channelRestrictions = {
  '1445381638233002054': ['truthordare'],
  
  '1445393993767845930': ['level', 'stats', 'leaderboards'],
  
  '1445405139698716672': ['balance', 'daily', 'gather', 'give', 'leaderboard', 'rob', 'addeggs', 'removeeggs', 'coinflip', 'dice', 'slots'],
  
  '1445659048346390709': ['marriage'],
  
  '1445660183299756095': ['meme'],
};

const commandToChannel = {};
for (const [channelId, commands] of Object.entries(channelRestrictions)) {
  for (const cmd of commands) {
    commandToChannel[cmd] = channelId;
  }
}

export function isCommandAllowedInChannel(commandName, channelId) {
  const requiredChannel = commandToChannel[commandName];
  
  if (!requiredChannel) {
    return { allowed: true };
  }
  
  if (channelId === requiredChannel) {
    return { allowed: true };
  }
  
  return { 
    allowed: false, 
    requiredChannel 
  };
}

export function getChannelForCommand(commandName) {
  return commandToChannel[commandName] || null;
}

export { channelRestrictions, commandToChannel };
