import discord
from discord import app_commands
from discord.ext import commands
import random

# ==========================================
# 1. DATABASE MOCK (Replace with your actual DB logic)
# ==========================================
# The JS code imported these from '../../utils/database.js'.
# I have included placeholders here so the code runs without errors.

def get_balance(guild_id: int, user_id: int) -> int:
    # TODO: Connect to your real database here
    # For testing, we return a fake balance of 5000 eggs
    return 5000 

def add_balance(guild_id: int, user_id: int, amount: int):
    # TODO: Add logic to save new balance to DB
    print(f"Added {amount} to {user_id}")

def remove_balance(guild_id: int, user_id: int, amount: int):
    # TODO: Add logic to remove balance from DB
    print(f"Removed {amount} from {user_id}")

# ==========================================
# 2. THE COINFLIP GAME LOGIC
# ==========================================

class CoinflipGame:
    """Handles the core logic to keep the View clean."""
    @staticmethod
    def flip():
        return random.choice(["heads", "tails"])

    @staticmethod
    def get_result_embed(winner: bool, choice: str, result: str, bet: int, new_balance: int):
        embed = discord.Embed(title="# Coin Flip Result")
        
        # Set color: Green for win, Red for loss
        embed.color = discord.Color.green() if winner else discord.Color.red()
        
        # Thumbnail (The coin image from your JS code)
        embed.set_thumbnail(url='https://em-content.zobj.net/source/twitter/376/coin_1fa99.png')
        
        # Main Result Text
        result_emoji = "🪙"
        embed.add_field(
            name="Outcome", 
            value=f"{result_emoji} **{result.upper()}** {result_emoji}\n\nYou chose: **{choice.upper()}**", 
            inline=False
        )
        
        # Win/Loss Message
        if winner:
            embed.add_field(
                name="You Won!", 
                value=f"**+{bet:,}** eggs\n**New Balance:** {new_balance:,} eggs", 
                inline=False
            )
        else:
            embed.add_field(
                name="You Lost!", 
                value=f"**-{bet:,}** eggs\n**New Balance:** {new_balance:,} eggs", 
                inline=False
            )
            
        return embed

# ==========================================
# 3. DISCORD UI VIEWS (Buttons)
# ==========================================

class PlayAgainView(discord.ui.View):
    def __init__(self, bot, user_id, bet):
        super().__init__(timeout=60)
        self.bot = bot
        self.user_id = user_id
        self.bet = bet

    @discord.ui.button(label="Play Again", style=discord.ButtonStyle.success, emoji="🔄")
    async def play_again(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This isn't your game!", ephemeral=True)
            return

        # Restart the game loop by calling the command logic again
        # We verify balance again inside the new game instance
        await start_coinflip_game(interaction, self.bet)

class ChoiceView(discord.ui.View):
    def __init__(self, bet, user_id):
        super().__init__(timeout=30)
        self.bet = bet
        self.user_id = user_id
        self.choice = None

    async def handle_flip(self, interaction: discord.Interaction, choice: str):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This isn't your game!", ephemeral=True)
            return

        # 1. Flip the coin
        result = CoinflipGame.flip()
        won = (choice == result)
        
        # 2. Update Database
        guild_id = interaction.guild.id
        user_id = interaction.user.id
        
        if won:
            add_balance(guild_id, user_id, self.bet)
            # Fetch new balance (simulated)
            new_bal = get_balance(guild_id, user_id) 
        else:
            remove_balance(guild_id, user_id, self.bet)
            new_bal = get_balance(guild_id, user_id) 

        # 3. Create Result Embed
        embed = CoinflipGame.get_result_embed(won, choice, result, self.bet, new_bal)
        
        # 4. Create "Play Again" View
        view = PlayAgainView(interaction.client, user_id, self.bet)
        
        # 5. Update the message
        await interaction.response.edit_message(embed=embed, view=view)
        self.stop()

    @discord.ui.button(label="Heads", style=discord.ButtonStyle.primary, emoji="🗣️")
    async def heads(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_flip(interaction, "heads")

    @discord.ui.button(label="Tails", style=discord.ButtonStyle.secondary, emoji="🐍")
    async def tails(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_flip(interaction, "tails")

# ==========================================
# 4. COMMAND LOGIC
# ==========================================

async def start_coinflip_game(interaction: discord.Interaction, bet: int):
    """Reusable function to start the game (used by command AND play again button)."""
    
    # 1. Check Balance
    balance = get_balance(interaction.guild.id, interaction.user.id)
    
    if balance < bet:
        embed = discord.Embed(
            title="Insufficient Eggs",
            description=f"You don't have enough eggs!\n\n**Your Balance:** {balance:,} eggs",
            color=discord.Color.red()
        )
        # If this is a button click (Play Again), we edit. If command, we send new.
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, ephemeral=True)
        else:
            # Try to edit if possible (for Play Again flow) or send new
            try:
                await interaction.response.send_message(embed=embed, ephemeral=True)
            except:
                await interaction.followup.send(embed=embed, ephemeral=True)
        return

    # 2. Send Game Board
    embed = discord.Embed(
        title="Coin Flip",
        description=f"Placing bet: **{bet:,}** eggs\nChoose a side!",
        color=discord.Color.gold()
    )
    view = ChoiceView(bet, interaction.user.id)
    
    # Handle both initial command response and "Play Again" button update
    if interaction.type == discord.InteractionType.component:
        # If coming from "Play Again" button, we update the message
        await interaction.response.edit_message(embed=embed, view=view)
    else:
        # If coming from slash command
        await interaction.response.send_message(embed=embed, view=view)

# ==========================================
# 5. THE BOT CLASS & SETUP
# ==========================================

class CoinflipBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=discord.Intents.default())

    async def setup_hook(self):
        await self.add_cog(CoinflipCog(self))
        # Sync commands globally (for testing) or to specific guild
        await self.tree.sync()

class CoinflipCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="coinflip", description="Flip a coin and bet your eggs")
    @app_commands.describe(bet="Amount to bet")
    async def coinflip(self, interaction: discord.Interaction, bet: int):
        # Validation
        if bet < 10:
            await interaction.response.send_message("Minimum bet is 10 eggs!", ephemeral=True)
            return
            
        await start_coinflip_game(interaction, bet)

# ==========================================
# 6. RUN THE BOT
# ==========================================

if __name__ == "__main__":
    # Replace with your actual token
    TOKEN = "YOUR_BOT_TOKEN_HERE"
    
    bot = CoinflipBot()
    bot.run(TOKEN)