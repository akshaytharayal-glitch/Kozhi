import discord
import random
import aiosqlite

# ======================================================
# 1. DATABASE HELPERS (Real aiosqlite logic)
# ======================================================

async def get_balance(db: aiosqlite.Connection, user_id: int) -> int:
    """Fetches user balance from the database."""
    async with db.execute("SELECT balance FROM economy WHERE user_id = ?", (user_id,)) as cursor:
        row = await cursor.fetchone()
        return row[0] if row else 0

async def update_balance(db: aiosqlite.Connection, user_id: int, amount: int):
    """Updates the user balance safely."""
    # Check if user exists first
    current = await get_balance(db, user_id)
    new_bal = current + amount
    
    # Insert or Replace logic
    await db.execute("""
        INSERT OR REPLACE INTO economy (user_id, balance) 
        VALUES (?, ?)
    """, (user_id, new_bal))
    await db.commit()

# ======================================================
# 2. CONTAINER V2 (The Embed Builder)
# ======================================================
def create_game_container(title: str, description: str, color: discord.Color):
    embed = discord.Embed(
        title=title,
        description=description,
        color=color
    )
    embed.set_thumbnail(url='https://em-content.zobj.net/source/twitter/376/coin_1fa99.png')
    embed.set_footer(text="OwO Coinflip", icon_url="https://cdn.discordapp.com/emojis/123456789.png") 
    return embed

# ======================================================
# 3. GAME START FUNCTION
# ======================================================
async def start_coinflip_game(interaction: discord.Interaction, bet: int):
    user_id = interaction.user.id
    db = interaction.client.db  # ACCESS THE DB FROM MAIN.PY
    
    # Check Balance (Added await)
    balance = await get_balance(db, user_id)
    
    if balance < bet:
        embed = create_game_container(
            title="Insufficient Eggs",
            description=f"You need **{bet:,}** eggs but only have **{balance:,}**.",
            color=discord.Color.red()
        )
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    embed = create_game_container(
        title="Coin Flip",
        description=f"Placing bet: **{bet:,}** eggs\nChoose a side to win!",
        color=discord.Color.gold()
    )
    view = ChoiceView(bet, user_id)

    if interaction.type == discord.InteractionType.component:
        await interaction.followup.send(embed=embed, view=view)
    else:
        await interaction.response.send_message(embed=embed, view=view)

# ======================================================
# 4. VIEW CLASSES (Buttons)
# ======================================================

class PlayAgainView(discord.ui.View):
    def __init__(self, user_id, bet):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.bet = bet

    @discord.ui.button(label="Play Again", style=discord.ButtonStyle.success, emoji="🔄")
    async def play_again(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This isn't your game!", ephemeral=True)
            return
        
        button.disabled = True
        await interaction.response.edit_message(view=self)
        await start_coinflip_game(interaction, self.bet)

class ChoiceView(discord.ui.View):
    def __init__(self, bet, user_id):
        super().__init__(timeout=30)
        self.bet = bet
        self.user_id = user_id

    async def handle_flip(self, interaction: discord.Interaction, choice: str):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This isn't your game!", ephemeral=True)
            return

        # Access DB from the interaction client
        db = interaction.client.db

        result = random.choice(["heads", "tails"])
        winner = (choice == result)
        
        if winner:
            await update_balance(db, self.user_id, self.bet) # Added await
            color = discord.Color.green()
            title = "You Won!"
            math = f"+{self.bet:,}"
        else:
            await update_balance(db, self.user_id, -self.bet) # Added await
            color = discord.Color.red()
            title = "You Lost!"
            math = f"-{self.bet:,}"

        new_bal = await get_balance(db, self.user_id) # Added await

        description = (
            f"**Outcome:** 🪙 {result.upper()}\n"
            f"**You Picked:** {choice.upper()}\n\n"
            f"**{math}** eggs\n"
            f"Current Balance: {new_bal:,} eggs"
        )
        embed = create_game_container(title, description, color)

        view = PlayAgainView(self.user_id, self.bet)
        await interaction.response.edit_message(embed=embed, view=view)
        self.stop()

    @discord.ui.button(label="Heads", style=discord.ButtonStyle.primary, emoji="🗣️")
    async def heads(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_flip(interaction, "heads")

    @discord.ui.button(label="Tails", style=discord.ButtonStyle.secondary, emoji="🐍")
    async def tails(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_flip(interaction, "tails")