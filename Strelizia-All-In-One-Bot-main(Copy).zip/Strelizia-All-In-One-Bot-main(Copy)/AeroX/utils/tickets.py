import discord
from discord import app_commands
from discord.ext import commands
import aiosqlite
import time
import io
import ticket_tts  # Import the file above

# --- CONSTANTS ---
WELCOME_CHANNELS = {
    "channel1": 1445673305590857799,
    "channel2": 1445635607249551431,
    "channel3": 1445382624163139634
}

class TicketSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        # Initialize Database Tables for Tickets
        if self.bot.db:
            await self.bot.db.execute("""
                CREATE TABLE IF NOT EXISTS ticket_settings (
                    guild_id INTEGER PRIMARY KEY,
                    category_id INTEGER,
                    log_channel_id INTEGER,
                    ticket_counter INTEGER DEFAULT 0
                )
            """)
            await self.bot.db.execute("""
                CREATE TABLE IF NOT EXISTS active_tickets (
                    channel_id INTEGER PRIMARY KEY,
                    guild_id INTEGER,
                    user_id INTEGER,
                    ticket_id INTEGER,
                    status TEXT
                )
            """)
            await self.bot.db.commit()

    # --- HELPERS ---

    def create_container(self, title, description, color, thumbnail_url=None, footer="Mandhi Spot Support"):
        embed = discord.Embed(title=title, description=description, color=color)
        if thumbnail_url:
            embed.set_thumbnail(url=thumbnail_url)
        embed.set_footer(text=footer)
        return embed

    async def get_settings(self, guild_id):
        async with self.bot.db.execute("SELECT category_id, log_channel_id, ticket_counter FROM ticket_settings WHERE guild_id = ?", (guild_id,)) as cursor:
            return await cursor.fetchone()

    # --- COMMANDS ---

    ticket_group = app_commands.Group(name="ticket", description="Ticket system commands")

    @ticket_group.command(name="setup", description="Set up the ticket system panel")
    @app_commands.describe(channel="Where to send the panel", category="Category for new tickets", logs="Channel for logs")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def setup(self, interaction: discord.Interaction, channel: discord.TextChannel, category: discord.CategoryChannel = None, logs: discord.TextChannel = None):
        # Save Settings
        cat_id = category.id if category else None
        log_id = logs.id if logs else None
        
        await self.bot.db.execute("""
            INSERT OR REPLACE INTO ticket_settings (guild_id, category_id, log_channel_id, ticket_counter)
            VALUES (?, ?, ?, COALESCE((SELECT ticket_counter FROM ticket_settings WHERE guild_id = ?), 0))
        """, (interaction.guild.id, cat_id, log_id, interaction.guild.id))
        await self.bot.db.commit()

        # Create Panel Embed (Container V2)
        embed = self.create_container(
            title="# 🎫 Need Help?",
            description="Click the button below to create a support ticket.",
            color=0x5865F2,
            thumbnail_url=interaction.guild.icon.url if interaction.guild.icon else None
        )
        embed.add_field(name="📋 What can we help with?", value="• General support\n• Technical issues\n• Reporting problems", inline=False)
        embed.add_field(name="Ready to get help?", value="Click **Create Ticket** below", inline=False)

        view = TicketPanelView()
        await channel.send(embed=embed, view=view)
        await interaction.response.send_message(f"✅ Ticket panel sent to {channel.mention}", ephemeral=True)

    @ticket_group.command(name="add", description="Add a user to the ticket")
    async def add_user(self, interaction: discord.Interaction, user: discord.User):
        # Verify this is a ticket channel
        async with self.bot.db.execute("SELECT * FROM active_tickets WHERE channel_id = ?", (interaction.channel.id,)) as cursor:
            ticket = await cursor.fetchone()
        
        if not ticket:
            return await interaction.response.send_message("❌ This is not a ticket channel!", ephemeral=True)

        await interaction.channel.set_permissions(user, view_channel=True, send_messages=True)
        await interaction.response.send_message(f"✅ Added {user.mention} to the ticket.")

    @ticket_group.command(name="remove", description="Remove a user from the ticket")
    async def remove_user(self, interaction: discord.Interaction, user: discord.User):
        async with self.bot.db.execute("SELECT * FROM active_tickets WHERE channel_id = ?", (interaction.channel.id,)) as cursor:
            ticket = await cursor.fetchone()
        
        if not ticket:
            return await interaction.response.send_message("❌ This is not a ticket channel!", ephemeral=True)

        await interaction.channel.set_permissions(user, overwrite=None)
        await interaction.response.send_message(f"✅ Removed {user.mention} from the ticket.")

# --- VIEWS (BUTTONS) ---

class TicketPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None) # Persistent view

    @discord.ui.button(label="Create Ticket", style=discord.ButtonStyle.success, custom_id="ticket_create")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        db = interaction.client.db

        # 1. Check for existing open ticket
        async with db.execute("SELECT channel_id FROM active_tickets WHERE user_id = ? AND guild_id = ?", (interaction.user.id, guild.id)) as cursor:
            if await cursor.fetchone():
                return await interaction.response.send_message("❌ You already have an open ticket!", ephemeral=True)

        # 2. Get Config & Increment Counter
        settings = await interaction.client.get_cog("TicketSystem").get_settings(guild.id)
        if not settings:
            return await interaction.response.send_message("❌ Ticket system not setup yet.", ephemeral=True)
        
        category_id, log_channel_id, counter = settings
        new_counter = counter + 1
        
        await db.execute("UPDATE ticket_settings SET ticket_counter = ? WHERE guild_id = ?", (new_counter, guild.id))
        
        # 3. Create Channel
        category = guild.get_channel(category_id) if category_id else None
        
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True)
        }

        # Add Admin/Owner Roles to overwrites
        for role in guild.roles:
            if role.name.lower() in ['admin', 'administrator', 'owner']:
                overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

        channel = await guild.create_text_channel(
            name=f"ticket-{new_counter}",
            category=category,
            overwrites=overwrites
        )

        # 4. Save to DB
        await db.execute("INSERT INTO active_tickets VALUES (?, ?, ?, ?, ?)", 
                         (channel.id, guild.id, interaction.user.id, new_counter, 'open'))
        await db.commit()

        # 5. Send Welcome Embed
        embed = discord.Embed(
            title=f"🎫 Ticket #{new_counter}",
            description=f"Hello {interaction.user.mention}! Welcome to **{guild.name}** Support.\n\nPlease describe your issue. Our staff will be with you shortly.",
            color=0x5865F2
        )
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        embed.add_field(name="📝 Guidelines", value="• Be patient\n• Provide details", inline=False)
        embed.add_field(name="🔗 Useful Channels", value=f"<#{WELCOME_CHANNELS['channel1']}>", inline=False)
        
        view = TicketControlView()
        await channel.send(embed=embed, view=view, content=f"{interaction.user.mention} 🔔")

        # 6. TTS & Announcement
        # Non-blocking calls
        asyncio.create_task(ticket_tts.send_ticket_voice_message(channel, guild, interaction.user))
        asyncio.create_task(ticket_tts.announce_ticket_to_admin_vc(guild, new_counter))

        # 7. Logs
        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = discord.Embed(title="Ticket Created", color=0x00FF00, description=f"**Ticket:** #{new_counter}\n**User:** {interaction.user.mention}\n**Channel:** {channel.mention}")
                await log_channel.send(embed=log_embed)

        await interaction.response.send_message(f"✅ Ticket created: {channel.mention}", ephemeral=True)

class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, custom_id="ticket_close_confirm")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("🔒 Closing ticket, generating transcript...", ephemeral=False)
        
        db = interaction.client.db
        
        # Get Ticket Info
        async with db.execute("SELECT ticket_id, user_id FROM active_tickets WHERE channel_id = ?", (interaction.channel.id,)) as cursor:
            data = await cursor.fetchone()
        
        if not data:
            return await interaction.channel.delete() # Fallback

        ticket_id, user_id = data
        ticket_user = interaction.guild.get_member(user_id)

        # Generate Transcript
        transcript_file = await generate_transcript(interaction.channel, ticket_id, interaction.guild)
        
        # Remove from DB
        await db.execute("DELETE FROM active_tickets WHERE channel_id = ?", (interaction.channel.id,))
        await db.commit()

        # Send Log
        settings = await interaction.client.get_cog("TicketSystem").get_settings(interaction.guild.id)
        if settings and settings[1]: # log_channel_id
            log_channel = interaction.guild.get_channel(settings[1])
            if log_channel:
                embed = discord.Embed(title="Ticket Closed", color=0xFF0000, description=f"**Ticket:** #{ticket_id}\n**Closed By:** {interaction.user.mention}")
                await log_channel.send(embed=embed, file=transcript_file)

        # DM User
        if ticket_user:
            try:
                transcript_file.seek(0) # Reset file pointer for re-sending
                dm_embed = discord.Embed(title="Ticket Closed", description=f"Your ticket #{ticket_id} has been closed.", color=0x5865F2)
                await ticket_user.send(embed=dm_embed, file=transcript_file)
            except:
                pass

        await asyncio.sleep(5)
        await interaction.channel.delete()

# --- TRANSCRIPT GENERATOR (HTML) ---
async def generate_transcript(channel, ticket_id, guild):
    messages = [message async for message in channel.history(limit=100)]
    messages.reverse()
    
    # HTML Header
    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Transcript #{ticket_id}</title>
        <style>
            body {{ background-color: #0a0a0f; color: #e0e0e0; font-family: sans-serif; padding: 20px; }}
            .container {{ max-width: 800px; margin: 0 auto; background: #1a1a28; border-radius: 10px; padding: 20px; }}
            .header {{ text-align: center; border-bottom: 2px solid #00ff88; margin-bottom: 20px; padding-bottom: 10px; }}
            .message {{ margin-bottom: 15px; padding: 10px; border-radius: 5px; }}
            .user {{ background: rgba(139, 92, 246, 0.1); border-left: 3px solid #8b5cf6; }}
            .bot {{ background: rgba(0, 255, 136, 0.1); border-left: 3px solid #00ff88; }}
            .meta {{ font-size: 0.8em; color: #888; margin-bottom: 5px; }}
            .content {{ font-size: 1em; line-height: 1.4; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Ticket #{ticket_id}</h1>
                <p>Server: {guild.name}</p>
            </div>
    """

    for msg in messages:
        msg_class = "bot" if msg.author.bot else "user"
        content = msg.clean_content.replace('\n', '<br>')
        
        # Handle Embeds in transcript roughly
        if msg.embeds:
            content += "<br><em>[Embedded Message Content]</em>"

        html += f"""
            <div class="message {msg_class}">
                <div class="meta"><strong>{msg.author.name}</strong> - {msg.created_at.strftime('%Y-%m-%d %H:%M:%S')}</div>
                <div class="content">{content}</div>
            </div>
        """

    html += "</div></body></html>"
    
    return discord.File(io.BytesIO(html.encode('utf-8')), filename=f"transcript-{ticket_id}.html")

async def setup(bot):
    await bot.add_cog(TicketSystem(bot))