import discord
import os
import time
import asyncio
from gtts import gTTS
from pydub import AudioSegment

# Configuration paths
TEMP_DIR = "./temp_audio"
CUSTOM_ANNOUNCEMENT_AUDIO = "./assets/ticket_announcement.mp3" 

if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)

# --- 1. SEND VOICE MESSAGE TO TICKET ---
async def send_ticket_voice_message(ticket_channel: discord.TextChannel, guild: discord.Guild, user: discord.User):
    timestamp = int(time.time() * 1000)
    english_tts_path = os.path.join(TEMP_DIR, f"english_{timestamp}.mp3")
    name_tts_path = os.path.join(TEMP_DIR, f"name_{timestamp}.mp3")
    final_output_path = os.path.join(TEMP_DIR, f"ticket_welcome_{timestamp}.mp3")
    
    member = guild.get_member(user.id)
    # Simple name cleaner
    raw_user_name = member.display_name if member else user.name
    clean_name = ''.join(e for e in raw_user_name if e.isalnum() or e.isspace())

    try:
        # Generate Text
        tts_text = f"This ticket was created by {clean_name}."
        tts = gTTS(text=tts_text, lang='en', slow=False)
        tts.save(name_tts_path)
        
        # Merge if custom audio exists
        if os.path.exists(CUSTOM_ANNOUNCEMENT_AUDIO):
            intro_audio = AudioSegment.from_mp3(CUSTOM_ANNOUNCEMENT_AUDIO)
            name_audio = AudioSegment.from_mp3(name_tts_path)
            combined = intro_audio + name_audio
            combined.export(final_output_path, format="mp3")
            file_to_send = final_output_path
        else:
            # Fallback if no custom audio
            fallback_text = f"Welcome to the ticket section. Support will be here soon. {tts_text}"
            tts_fallback = gTTS(text=fallback_text, lang='en')
            tts_fallback.save(final_output_path)
            file_to_send = final_output_path

        # Send
        file = discord.File(file_to_send, filename="welcome_message.mp3")
        await ticket_channel.send(content="🔊 **Voice Welcome Message:**", file=file)
        print(f"[TTS] Sent voice message for {clean_name}")

    except Exception as e:
        print(f"[TTS] Error: {e}")
    finally:
        cleanup_files([english_tts_path, name_tts_path, final_output_path])

# --- 2. ANNOUNCE TO ADMIN VC ---
async def announce_ticket_to_admin_vc(guild: discord.Guild, ticket_id: int):
    """
    Finds an admin in a voice channel, joins, plays the announcement sound, and leaves.
    """
    if not os.path.exists(CUSTOM_ANNOUNCEMENT_AUDIO):
        print("[VC] Custom announcement file not found.")
        return

    # Find Admin Role
    admin_role = discord.utils.find(lambda r: r.name.lower() in ['admin', 'administrator'], guild.roles)
    if not admin_role:
        return

    # Find an Admin currently in a Voice Channel
    target_channel = None
    for member in guild.members:
        if member.voice and member.voice.channel and admin_role in member.roles and not member.bot:
            target_channel = member.voice.channel
            break
    
    if not target_channel:
        print("[VC] No admins found in voice channels.")
        return

    print(f"[VC] Announcing ticket #{ticket_id} in {target_channel.name}")

    try:
        # Connect
        vc_client = await target_channel.connect()
        
        # Play Audio
        # We use FFmpegPCMAudio. Make sure ffmpeg is installed on your server/PC.
        source = discord.FFmpegPCMAudio(CUSTOM_ANNOUNCEMENT_AUDIO)
        vc_client.play(source)

        # Wait until audio finishes
        while vc_client.is_playing():
            await asyncio.sleep(1)
        
        # Disconnect
        await vc_client.disconnect()
        
    except Exception as e:
        print(f"[VC] Failed to announce: {e}")
        # Force cleanup if stuck
        if guild.voice_client:
            await guild.voice_client.disconnect()

def cleanup_files(file_paths):
    for path in file_paths:
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass